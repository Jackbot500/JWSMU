/*    */ package nonamecrackers2.crackerslib.common.data;
/*    */ 
/*    */ import net.minecraft.data.PackOutput;
/*    */ import net.minecraftforge.common.data.LanguageProvider;
/*    */ import nonamecrackers2.crackerslib.common.config.CrackersLibConfig;
/*    */ import nonamecrackers2.crackerslib.common.util.data.ConfigLangGeneratorHelper;
/*    */ 
/*    */ 
/*    */ public class CrackersLibLangProvider
/*    */   extends LanguageProvider
/*    */ {
/*    */   public CrackersLibLangProvider(PackOutput output) {
/* 13 */     super(output, "crackerslib", "en_us");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void addTranslations() {
/* 19 */     ConfigLangGeneratorHelper.langForSpec("crackerslib", CrackersLibConfig.CLIENT_SPEC, this, ConfigLangGeneratorHelper.Info.ONLY_RANGE);
/* 20 */     add("config.crackerslib.preset.note", "NOTE: Changing the preset may override other values, make backups!");
/* 21 */     add("config.crackerslib.preset.custom.title", "Custom");
/* 22 */     add("config.crackerslib.preset.default.title", "Default");
/* 23 */     add("config.crackerslib.preset.default.description", "Default settings.");
/* 24 */     add("config.crackerslib.preset.custom.description", "Custom values defined by the user. Changing any value defaulted by a preset will change it to custom.");
/* 25 */     add("gui.crackerslib.button.preset.title", "Preset");
/* 26 */     add("gui.crackerslib.button.preset.holdShift", "Hold SHIFT to see a description");
/* 27 */     add("gui.crackerslib.button.reset.title", "Reset");
/* 28 */     add("gui.crackerslib.button.exit.title", "Exit");
/* 29 */     add("gui.crackerslib.button.exitAndSave.title", "Save and Exit");
/* 30 */     add("gui.crackerslib.button.sorting.title", "Sorting");
/* 31 */     add("gui.crackerslib.button.sorting.a-z.tooltip", "A-Z");
/* 32 */     add("gui.crackerslib.button.sorting.z-a.tooltip", "Z-A");
/* 33 */     add("gui.crackerslib.button.collapse.title", "Collapse");
/* 34 */     add("gui.crackerslib.button.collapse.description", "Collapse all categories");
/* 35 */     add("gui.crackerslib.screen.config.home.title", "CrackersLib Config");
/* 36 */     add("gui.crackerslib.screen.config.discord", "Discord Server");
/* 37 */     add("gui.crackerslib.screen.config.discord.info", "Join the official Discord server!");
/* 38 */     add("gui.crackerslib.screen.config.patreon", "Patreon");
/* 39 */     add("gui.crackerslib.screen.config.patreon.info", "Support us on Patreon!");
/* 40 */     add("gui.crackerslib.screen.config.github", "GitHub");
/* 41 */     add("gui.crackerslib.screen.config.github.info", "Report bugs/provide feedback here!");
/* 42 */     add("gui.crackerslib.screen.config.search", "Search");
/* 43 */     add("gui.crackerslib.screen.config.requiresRestart", "Requires restart");
/* 44 */     add("gui.crackerslib.screen.clientOptions.title", "Client Options");
/* 45 */     add("gui.crackerslib.screen.clientOptions.info", "Includes various config options for the client with varying purposes, such as performance and personal preference.");
/* 46 */     add("gui.crackerslib.screen.commonOptions.title", "Common Options");
/* 47 */     add("gui.crackerslib.screen.commonOptions.info", "Includes config options across all worlds.");
/* 48 */     add("gui.crackerslib.screen.serverOptions.title", "World Options");
/* 49 */     add("gui.crackerslib.screen.serverOptions.notInWorld.info", "Includes config options unique for each world. Can only be accessed while in a world.");
/* 50 */     add("gui.crackerslib.screen.serverOptions.inWorld.info", "Includes config options unique for this world.");
/* 51 */     add("gui.crackerslib.config.noAvailableOptions", "No config options found.");
/* 52 */     add("argument.crackerslib.config.invalidValue", "Could not find config value `%s`");
/* 53 */     add("commands.crackerslib.setConfig.set.fail", "Value did not change or is invalid.");
/* 54 */     add("commands.crackerslib.setConfig.set.success", "Successfully set '%s' to '%s'");
/* 55 */     add("commands.crackerslib.setConfig.set.note", "Note: '%s' requires a restart to take effect.");
/* 56 */     add("commands.crackerslib.getConfig.get", "The value of '%s' is '%s'");
/* 57 */     add("commands.crackerslib.setDefault.success", "Set '%s' to its default: '%s'");
/* 58 */     add("gui.popup.yes", "Yes");
/* 59 */     add("gui.popup.no", "No");
/* 60 */     add("gui.popup.submit", "Submit");
/* 61 */     add("gui.popup.cancel", "Cancel");
/* 62 */     add("gui.popup.select", "Select");
/* 63 */     add("gui.popup.close", "Close");
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\data\CrackersLibLangProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */