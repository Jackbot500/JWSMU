/*    */ package nonamecrackers2.crackerslib.common.config;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.List;
/*    */ import java.util.function.Function;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import org.apache.commons.lang3.tuple.Pair;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CrackersLibConfig
/*    */ {
/*    */   public static final ClientConfig CLIENT;
/*    */   public static final ForgeConfigSpec CLIENT_SPEC;
/*    */   
/*    */   static {
/* 17 */     Pair<ClientConfig, ForgeConfigSpec> clientPair = (new ForgeConfigSpec.Builder()).configure(ClientConfig::new);
/* 18 */     CLIENT = (ClientConfig)clientPair.getLeft();
/* 19 */     CLIENT_SPEC = (ForgeConfigSpec)clientPair.getRight();
/*    */   }
/*    */   
/*    */   public static class ClientConfig
/*    */     extends ConfigHelper
/*    */   {
/*    */     public final ForgeConfigSpec.ConfigValue<List<? extends String>> hiddenConfigMenuButtons;
/*    */     
/*    */     public ClientConfig(ForgeConfigSpec.Builder builder) {
/* 28 */       super(builder, "crackerslib");
/*    */       
/* 30 */       this.hiddenConfigMenuButtons = createListValue(String.class, () -> Lists.newArrayList((Object[])new String[] { "example_mod_id" }, ), v -> true, "hiddenConfigMenuButtons", false, "A list of mod ids that cannot have their registered config menu buttons appear in the options screen");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\config\CrackersLibConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */