/*     */ package nonamecrackers2.crackerslib.common.config;
/*     */ 
/*     */ import com.electronwill.nightconfig.core.UnmodifiableConfig;
/*     */ import com.google.common.base.Joiner;
/*     */ import com.google.common.base.Splitter;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConfigHelper
/*     */ {
/*  22 */   public static final Splitter DOT_SPLITTER = Splitter.on(".");
/*  23 */   public static final Joiner DOT_JOINER = Joiner.on('.');
/*     */   
/*     */   protected final ForgeConfigSpec.Builder builder;
/*     */   protected final String modid;
/*     */   
/*     */   protected ConfigHelper(ForgeConfigSpec.Builder builder, String modid) {
/*  29 */     this.builder = builder;
/*  30 */     this.modid = modid;
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T> ForgeConfigSpec.ConfigValue<T> createValue(T value, String name, boolean restart, String description) {
/*  35 */     return defaultProperties(name, description, restart, value).define(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForgeConfigSpec.ConfigValue<Double> createRangedDoubleValue(double value, double min, double max, String name, boolean restart, String description) {
/*  40 */     return (ForgeConfigSpec.ConfigValue<Double>)defaultProperties(name, description, restart, Double.valueOf(value)).defineInRange(name, value, min, max);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForgeConfigSpec.ConfigValue<Integer> createRangedIntValue(int value, int min, int max, String name, boolean restart, String description) {
/*  45 */     return (ForgeConfigSpec.ConfigValue<Integer>)defaultProperties(name, description, restart, Integer.valueOf(value)).defineInRange(name, value, min, max);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForgeConfigSpec.ConfigValue<Long> createRangedLongValue(long value, long min, long max, String name, boolean restart, String description) {
/*  50 */     return (ForgeConfigSpec.ConfigValue<Long>)defaultProperties(name, description, restart, Long.valueOf(value)).defineInRange(name, value, min, max);
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T extends Enum<T>> ForgeConfigSpec.ConfigValue<T> createEnumValue(T value, String name, boolean restart, String description) {
/*  55 */     return (ForgeConfigSpec.ConfigValue<T>)defaultProperties(name, description, restart, value).defineEnum(name, (Enum)value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> ForgeConfigSpec.ConfigValue<List<? extends T>> createListValue(Class<T> valueClass, Supplier<List<? extends T>> value, Predicate<T> validator, String name, boolean restart, String description) {
/*  61 */     return defaultProperties(name, description, restart, null).defineListAllowEmpty(split(name), value, obj -> 
/*  62 */         (valueClass.isAssignableFrom(obj.getClass()) && validator.test(obj)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> ForgeConfigSpec.Builder defaultProperties(String name, String desc, boolean restart, @Nullable T defaultValue) {
/*  68 */     if (restart) {
/*     */       
/*  70 */       this.builder.worldRestart().comment(desc);
/*  71 */       this.builder.comment("Requires restart.");
/*     */     }
/*     */     else {
/*     */       
/*  75 */       this.builder.comment(desc + ".");
/*     */     } 
/*  77 */     if (defaultValue != null)
/*  78 */       this.builder.comment("Default: " + defaultValue.toString()); 
/*  79 */     this.builder.translation("gui." + this.modid + ".config." + name + ".description");
/*  80 */     return this.builder;
/*     */   }
/*     */ 
/*     */   
/*     */   private static List<String> split(String path) {
/*  85 */     return Lists.newArrayList(DOT_SPLITTER.split(path));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map<String, ForgeConfigSpec.ConfigValue<?>> getAllValues(ForgeConfigSpec spec) {
/*  90 */     return (Map<String, ForgeConfigSpec.ConfigValue<?>>)searchForValues("", spec.getValues().valueMap()).entrySet().stream().map(e -> Map.entry(e.getKey(), e.getValue()))
/*     */       
/*  92 */       .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map<String, ForgeConfigSpec.ValueSpec> getAllSpecs(ForgeConfigSpec spec) {
/*  97 */     return (Map<String, ForgeConfigSpec.ValueSpec>)searchForValues("", spec.getSpec().valueMap()).entrySet().stream().map(e -> Map.entry(e.getKey(), e.getValue()))
/*     */       
/*  99 */       .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map<String, Object> searchForValues(String previousPath, Map<String, Object> values) {
/* 104 */     Map<String, Object> map = Maps.newHashMap();
/* 105 */     for (Map.Entry<String, Object> entry : values.entrySet()) {
/*     */       
/* 107 */       String path = entry.getKey();
/* 108 */       if (!previousPath.isEmpty())
/* 109 */         path = previousPath + "." + previousPath; 
/* 110 */       Object object = entry.getValue(); if (object instanceof UnmodifiableConfig) { UnmodifiableConfig next = (UnmodifiableConfig)object;
/* 111 */         map.putAll(searchForValues(path, next.valueMap())); continue; }
/*     */       
/* 113 */       map.put(path, entry.getValue());
/*     */     } 
/* 115 */     return map;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\config\ConfigHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */