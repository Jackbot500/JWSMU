/*     */ package nonamecrackers2.crackerslib.common.config.preset;
/*     */ 
/*     */ import com.google.common.collect.ImmutableMap;
/*     */ import com.google.common.collect.Maps;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ import nonamecrackers2.crackerslib.common.config.ConfigHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Builder
/*     */ {
/*  72 */   private final Map<String, Object> values = Maps.newHashMap();
/*     */   private final Component name;
/*     */   @Nullable
/*     */   private Component description;
/*     */   
/*     */   private Builder(Component name) {
/*  78 */     this.name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder setDescription(Component desc) {
/*  83 */     this.description = desc;
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Builder setPreset(ForgeConfigSpec.ConfigValue<T> config, T value) {
/*  89 */     return setPreset(ConfigHelper.DOT_JOINER.join(config.getPath()), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder setPreset(String path, Object value) {
/*  94 */     this.values.put(path, value);
/*  95 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigPreset build() {
/* 100 */     return new ConfigPreset((Map<String, Object>)ImmutableMap.copyOf(this.values), this.name, this.description);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\config\preset\ConfigPreset$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */