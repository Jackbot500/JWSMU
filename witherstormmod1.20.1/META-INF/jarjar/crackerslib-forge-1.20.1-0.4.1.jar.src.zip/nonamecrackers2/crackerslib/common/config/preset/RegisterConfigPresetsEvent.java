/*    */ package nonamecrackers2.crackerslib.common.config.preset;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import com.google.common.collect.ImmutableMultimap;
/*    */ import com.google.common.collect.Maps;
/*    */ import com.google.common.collect.Multimap;
/*    */ import com.google.common.collect.Multimaps;
/*    */ import com.google.common.collect.Sets;
/*    */ import java.util.List;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.eventbus.api.Event;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import net.minecraftforge.fml.event.IModBusEvent;
/*    */ import nonamecrackers2.crackerslib.common.config.ConfigHelper;
/*    */ 
/*    */ public class RegisterConfigPresetsEvent
/*    */   extends Event
/*    */   implements IModBusEvent
/*    */ {
/* 20 */   private final Multimap<ModConfig.Type, ConfigPreset> presets = (Multimap<ModConfig.Type, ConfigPreset>)Multimaps.newSetMultimap(Maps.newEnumMap(ModConfig.Type.class), Sets::newHashSet);
/* 21 */   private final ImmutableList.Builder<String> excludedConfigOptions = ImmutableList.builder();
/*    */   
/*    */   private final String modid;
/*    */   
/*    */   public RegisterConfigPresetsEvent(String modid) {
/* 26 */     this.modid = modid;
/*    */   }
/*    */ 
/*    */   
/*    */   public void registerPreset(ModConfig.Type type, ConfigPreset preset) {
/* 31 */     this.presets.put(type, preset);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Multimap<ModConfig.Type, ConfigPreset> buildPresets() {
/* 36 */     return (Multimap<ModConfig.Type, ConfigPreset>)ImmutableMultimap.copyOf(this.presets);
/*    */   }
/*    */ 
/*    */   
/*    */   protected List<String> buildExcludedConfigOptions() {
/* 41 */     return (List<String>)this.excludedConfigOptions.build();
/*    */   }
/*    */ 
/*    */   
/*    */   public RegisterConfigPresetsEvent exclude(String path) {
/* 46 */     this.excludedConfigOptions.add(path);
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public RegisterConfigPresetsEvent exclude(ForgeConfigSpec.ConfigValue<?> value) {
/* 52 */     return exclude(ConfigHelper.DOT_JOINER.join(value.getPath()));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModId() {
/* 57 */     return this.modid;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\config\preset\RegisterConfigPresetsEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */