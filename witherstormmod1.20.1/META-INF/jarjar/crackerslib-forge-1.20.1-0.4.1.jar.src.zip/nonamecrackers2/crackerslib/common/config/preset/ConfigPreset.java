/*     */ package nonamecrackers2.crackerslib.common.config.preset;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ 
/*     */ public final class ConfigPreset extends Record {
/*     */   private final Map<String, Object> values;
/*     */   private final Component name;
/*     */   @Nullable
/*     */   private final Component description;
/*     */   
/*  16 */   public ConfigPreset(Map<String, Object> values, Component name, @Nullable Component description) { this.values = values; this.name = name; this.description = description; } public final String toString() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lnonamecrackers2/crackerslib/common/config/preset/ConfigPreset;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #16	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*  16 */     //   0	7	0	this	Lnonamecrackers2/crackerslib/common/config/preset/ConfigPreset; } public Map<String, Object> values() { return this.values; } public final int hashCode() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lnonamecrackers2/crackerslib/common/config/preset/ConfigPreset;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #16	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lnonamecrackers2/crackerslib/common/config/preset/ConfigPreset; } public final boolean equals(Object o) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lnonamecrackers2/crackerslib/common/config/preset/ConfigPreset;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #16	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lnonamecrackers2/crackerslib/common/config/preset/ConfigPreset;
/*  16 */     //   0	8	1	o	Ljava/lang/Object; } public Component name() { return this.name; } @Nullable public Component description() { return this.description; }
/*     */ 
/*     */   
/*     */   public boolean hasValue(String path) {
/*  20 */     return this.values.containsKey(path);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T getValue(String path) {
/*  27 */     return (T)this.values.get(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefault() {
/*  32 */     return this.values.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Component getTooltip(boolean hasShiftDown) {
/*  37 */     MutableComponent tooltip = Component.m_237113_(name().getString());
/*  38 */     if (!hasShiftDown) {
/*     */       
/*  40 */       tooltip.m_130946_("\n");
/*  41 */       tooltip.m_7220_((Component)Component.m_237115_("gui.crackerslib.button.preset.holdShift").m_130940_(ChatFormatting.DARK_GRAY));
/*     */     }
/*     */     else {
/*     */       
/*  45 */       if (description() != null) {
/*     */         
/*  47 */         String[] components = description().getString().split("\n");
/*  48 */         for (int i = 0; i < components.length; i++) {
/*     */           
/*  50 */           tooltip.m_130946_("\n");
/*  51 */           tooltip.m_7220_((Component)Component.m_237113_(components[i].trim()).m_130940_(ChatFormatting.GRAY));
/*     */         } 
/*     */       } 
/*  54 */       tooltip.m_130946_("\n");
/*  55 */       tooltip.m_7220_((Component)Component.m_237115_("config.crackerslib.preset.note").m_130940_(ChatFormatting.GRAY));
/*     */     } 
/*  57 */     return (Component)tooltip;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Builder builder(Component name) {
/*  62 */     return new Builder(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ConfigPreset defaultPreset() {
/*  67 */     return new ConfigPreset((Map<String, Object>)ImmutableMap.of(), (Component)Component.m_237115_("config.crackerslib.preset.default.title"), (Component)Component.m_237115_("config.crackerslib.preset.default.description"));
/*     */   }
/*     */   
/*     */   public static class Builder
/*     */   {
/*  72 */     private final Map<String, Object> values = Maps.newHashMap();
/*     */     private final Component name;
/*     */     @Nullable
/*     */     private Component description;
/*     */     
/*     */     private Builder(Component name) {
/*  78 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setDescription(Component desc) {
/*  83 */       this.description = desc;
/*  84 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Builder setPreset(ForgeConfigSpec.ConfigValue<T> config, T value) {
/*  89 */       return setPreset(ConfigHelper.DOT_JOINER.join(config.getPath()), value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setPreset(String path, Object value) {
/*  94 */       this.values.put(path, value);
/*  95 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigPreset build() {
/* 100 */       return new ConfigPreset((Map<String, Object>)ImmutableMap.copyOf(this.values), this.name, this.description);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\config\preset\ConfigPreset.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */