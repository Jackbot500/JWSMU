/*    */ package nonamecrackers2.crackerslib.common.config.preset;
/*    */ 
/*    */ import com.google.common.collect.Multimap;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Presets
/*    */ {
/*    */   private final Multimap<ModConfig.Type, ConfigPreset> presetsByType;
/*    */   private final List<String> excludedConfigOptions;
/*    */   
/*    */   Presets(Multimap<ModConfig.Type, ConfigPreset> presetsByType, List<String> excludedConfigOptions) {
/* 59 */     this.presetsByType = presetsByType;
/* 60 */     this.excludedConfigOptions = excludedConfigOptions;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ConfigPreset> getPresetsForType(ModConfig.Type type) {
/* 65 */     return this.presetsByType.get(type);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getExcludedConfigOptions() {
/* 70 */     return this.excludedConfigOptions;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\config\preset\ConfigPresets$Presets.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */