/*    */ package nonamecrackers2.crackerslib.common.config.preset;
/*    */ 
/*    */ import com.google.common.collect.ImmutableMap;
/*    */ import com.google.common.collect.Lists;
/*    */ import com.google.common.collect.Multimap;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraftforge.fml.ModContainer;
/*    */ import net.minecraftforge.fml.ModLoader;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigPresets
/*    */ {
/*    */   @Nullable
/*    */   public static Map<String, Presets> presetsByMod;
/* 23 */   private static final Logger LOGGER = LogManager.getLogger("crackerslib/ConfigPresets");
/*    */   
/*    */   @Nullable
/*    */   public static Presets getPresetsForModId(String id) {
/* 27 */     Objects.requireNonNull(presetsByMod, "Presets have not yet been gathered!");
/* 28 */     return presetsByMod.get(id);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void gatherPresets() {
/* 33 */     if (presetsByMod != null)
/* 34 */       throw new IllegalStateException("Presets have already been gathered!"); 
/* 35 */     ImmutableMap.Builder<String, Presets> presetsBuilder = ImmutableMap.builder();
/* 36 */     List<RegisterConfigPresetsEvent> postedEvents = Lists.newArrayList();
/* 37 */     ModLoader.get().runEventGenerator(mod -> {
/*    */           RegisterConfigPresetsEvent event = new RegisterConfigPresetsEvent(mod.getModId());
/*    */           postedEvents.add(event);
/*    */           return event;
/*    */         });
/* 42 */     postedEvents.forEach(e -> {
/*    */           Multimap<ModConfig.Type, ConfigPreset> presets = e.buildPresets();
/*    */           List<String> excluded = e.buildExcludedConfigOptions();
/*    */           if (!presets.isEmpty())
/*    */             presetsBuilder.put(e.getModId(), new Presets(presets, excluded)); 
/*    */         });
/* 48 */     presetsByMod = (Map<String, Presets>)presetsBuilder.build();
/* 49 */     LOGGER.debug("Gathered presets for {} mod(s)", Integer.valueOf(presetsByMod.size()));
/*    */   }
/*    */ 
/*    */   
/*    */   public static class Presets
/*    */   {
/*    */     private final Multimap<ModConfig.Type, ConfigPreset> presetsByType;
/*    */     private final List<String> excludedConfigOptions;
/*    */     
/*    */     Presets(Multimap<ModConfig.Type, ConfigPreset> presetsByType, List<String> excludedConfigOptions) {
/* 59 */       this.presetsByType = presetsByType;
/* 60 */       this.excludedConfigOptions = excludedConfigOptions;
/*    */     }
/*    */ 
/*    */     
/*    */     public Collection<ConfigPreset> getPresetsForType(ModConfig.Type type) {
/* 65 */       return this.presetsByType.get(type);
/*    */     }
/*    */ 
/*    */     
/*    */     public List<String> getExcludedConfigOptions() {
/* 70 */       return this.excludedConfigOptions;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\config\preset\ConfigPresets.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */