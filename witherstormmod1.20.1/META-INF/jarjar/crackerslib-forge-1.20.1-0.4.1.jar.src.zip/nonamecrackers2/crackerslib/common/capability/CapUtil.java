/*    */ package nonamecrackers2.crackerslib.common.capability;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.core.Direction;
/*    */ import net.minecraft.nbt.CompoundTag;
/*    */ import net.minecraft.nbt.Tag;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraftforge.common.capabilities.Capability;
/*    */ import net.minecraftforge.common.capabilities.ICapabilityProvider;
/*    */ import net.minecraftforge.common.capabilities.ICapabilitySerializable;
/*    */ import net.minecraftforge.common.util.LazyOptional;
/*    */ import net.minecraftforge.common.util.NonNullSupplier;
/*    */ import net.minecraftforge.event.AttachCapabilitiesEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ public class CapUtil
/*    */ {
/*    */   public static void registerCap(AttachCapabilitiesEvent<?> event, ResourceLocation id, final Capability<?> cap, @Nullable NonNullSupplier<?> object) {
/* 21 */     final LazyOptional<?> optional = LazyOptional.of(object);
/* 22 */     event.addCapability(id, new ICapabilityProvider()
/*    */         {
/*    */           @NotNull
/*    */           public <M> LazyOptional<M> getCapability(@NotNull Capability<M> in, @Nullable Direction side)
/*    */           {
/* 27 */             return (in == cap) ? optional.cast() : LazyOptional.empty();
/*    */           }
/*    */         });
/* 30 */     Objects.requireNonNull(optional); event.addListener(optional::invalidate);
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends TagSerializable> void registerSerializableCap(AttachCapabilitiesEvent<?> event, ResourceLocation id, final Capability<?> cap, @Nullable NonNullSupplier<T> object) {
/* 35 */     final LazyOptional<T> optional = LazyOptional.of(object);
/* 36 */     event.addCapability(id, (ICapabilityProvider)new ICapabilitySerializable<CompoundTag>()
/*    */         {
/*    */           
/*    */           @NotNull
/*    */           public <M> LazyOptional<M> getCapability(@NotNull Capability<M> in, @Nullable Direction side)
/*    */           {
/* 42 */             return (in == cap) ? optional.cast() : LazyOptional.empty();
/*    */           }
/*    */ 
/*    */ 
/*    */           
/*    */           public CompoundTag serializeNBT() {
/* 48 */             return ((TagSerializable)optional.orElse(null)).write();
/*    */           }
/*    */ 
/*    */ 
/*    */           
/*    */           public void deserializeNBT(CompoundTag nbt) {
/* 54 */             ((TagSerializable)optional.orElse(null)).read(nbt);
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\capability\CapUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */