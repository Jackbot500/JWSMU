/*    */ package nonamecrackers2.crackerslib.common.capability;
/*    */ 
/*    */ import net.minecraft.nbt.CompoundTag;
/*    */ 
/*    */ 
/*    */ public interface TagSerializable
/*    */ {
/*    */   default CompoundTag write() {
/*  9 */     CompoundTag tag = new CompoundTag();
/* 10 */     write(tag);
/* 11 */     return tag;
/*    */   }
/*    */   
/*    */   void write(CompoundTag paramCompoundTag);
/*    */   
/*    */   void read(CompoundTag paramCompoundTag);
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\capability\TagSerializable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */