/*    */ package nonamecrackers2.crackerslib.common.capability;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.core.Direction;
/*    */ import net.minecraftforge.common.capabilities.Capability;
/*    */ import net.minecraftforge.common.capabilities.ICapabilityProvider;
/*    */ import net.minecraftforge.common.util.LazyOptional;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements ICapabilityProvider
/*    */ {
/*    */   @NotNull
/*    */   public <M> LazyOptional<M> getCapability(@NotNull Capability<M> in, @Nullable Direction side) {
/* 27 */     return (in == cap) ? optional.cast() : LazyOptional.empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\capability\CapUtil$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */