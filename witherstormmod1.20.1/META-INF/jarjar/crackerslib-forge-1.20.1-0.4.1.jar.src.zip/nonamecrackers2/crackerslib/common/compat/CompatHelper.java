/*     */ package nonamecrackers2.crackerslib.common.compat;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import net.minecraftforge.fml.ModList;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompatHelper
/*     */ {
/*  15 */   private static final Logger LOGGER = LogManager.getLogger("crackerslib/CompatHelper");
/*  16 */   private static final List<String> COMPAT_ERRORS = Lists.newArrayList();
/*     */   
/*     */   private static boolean optifineLoaded;
/*     */   
/*     */   private static boolean vivecraftStandaloneLoaded;
/*     */ 
/*     */   
/*     */   public static void checkForLoaded() {
/*     */     try {
/*  25 */       Class.forName("net.optifine.Config");
/*  26 */       optifineLoaded = true;
/*     */     }
/*  28 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  34 */       Class.forName("org.vivecraft.settings.VRSettings");
/*  35 */       vivecraftStandaloneLoaded = true;
/*     */     }
/*  37 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean areShadersRunning() {
/*     */     try {
/*  46 */       if (isOculusLoaded()) {
/*     */         
/*  48 */         Class<?> clazz = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
/*  49 */         Method instanceGetter = clazz.getMethod("getInstance", new Class[0]);
/*  50 */         Object irisApi = instanceGetter.invoke(null, new Object[0]);
/*  51 */         return ((Boolean)irisApi.getClass().getMethod("isShaderPackInUse", new Class[0]).invoke(irisApi, new Object[0])).booleanValue();
/*     */       } 
/*  53 */       if (isOptifineLoaded()) {
/*     */         
/*  55 */         Class<?> clazz = Class.forName("net.optifine.Config");
/*  56 */         Method method = clazz.getMethod("isShaders", new Class[0]);
/*  57 */         return ((Boolean)method.invoke(null, new Object[0])).booleanValue();
/*     */       } 
/*     */ 
/*     */       
/*  61 */       return false;
/*     */     
/*     */     }
/*  64 */     catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|ClassNotFoundException|NoSuchMethodException|SecurityException e) {
/*     */       
/*  66 */       doErrorFor("shaders", () -> {
/*     */             LOGGER.error("Failed to check if shaders are enabled:");
/*     */             e.printStackTrace();
/*     */           });
/*  70 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isVrActive() {
/*  76 */     if (ModList.get().isLoaded("vivecraft")) {
/*     */       
/*     */       try {
/*     */         
/*  80 */         Class<?> clazz = Class.forName("org.vivecraft.api_beta.client.VivecraftClientAPI");
/*  81 */         Method instanceGetter = clazz.getMethod("getInstance", new Class[0]);
/*  82 */         Object vivecraftApi = instanceGetter.invoke(null, new Object[0]);
/*  83 */         return ((Boolean)vivecraftApi.getClass().getMethod("isVrActive", new Class[0]).invoke(vivecraftApi, new Object[0])).booleanValue();
/*     */       }
/*  85 */       catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|ClassNotFoundException|NoSuchMethodException|SecurityException e) {
/*     */         
/*  87 */         doErrorFor("vr", () -> {
/*     */               LOGGER.error("Failed to check if VR is active:");
/*     */               e.printStackTrace();
/*     */             });
/*  91 */         return false;
/*     */       } 
/*     */     }
/*  94 */     return vivecraftStandaloneLoaded;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isVivecraftLoaded() {
/*  99 */     return (vivecraftStandaloneLoaded || ModList.get().isLoaded("vivecraft"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isOculusLoaded() {
/* 104 */     return ModList.get().isLoaded("oculus");
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isOptifineLoaded() {
/* 109 */     return optifineLoaded;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSodiumLoaded() {
/* 114 */     return ModList.get().isLoaded("rubidium");
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void doErrorFor(String mod, Runnable runnable) {
/* 119 */     if (!COMPAT_ERRORS.contains(mod)) {
/*     */       
/* 121 */       runnable.run();
/* 122 */       COMPAT_ERRORS.add(mod);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\compat\CompatHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */