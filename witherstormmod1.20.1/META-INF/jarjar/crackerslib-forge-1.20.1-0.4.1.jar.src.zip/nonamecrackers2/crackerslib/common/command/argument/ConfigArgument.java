/*     */ package nonamecrackers2.crackerslib.common.command.argument;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.mojang.brigadier.Message;
/*     */ import com.mojang.brigadier.StringReader;
/*     */ import com.mojang.brigadier.arguments.ArgumentType;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
/*     */ import com.mojang.brigadier.suggestion.Suggestions;
/*     */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import net.minecraft.commands.CommandBuildContext;
/*     */ import net.minecraft.commands.CommandSourceStack;
/*     */ import net.minecraft.commands.synchronization.ArgumentTypeInfo;
/*     */ import net.minecraft.network.FriendlyByteBuf;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ 
/*     */ public class ConfigArgument implements ArgumentType<String> {
/*     */   private static final DynamicCommandExceptionType INVALID_VALUE;
/*     */   private final List<String> availableOptions;
/*     */   
/*     */   static {
/*  27 */     INVALID_VALUE = new DynamicCommandExceptionType(o -> Component.m_237110_("argument.crackerslib.config.invalidValue", new Object[] { o }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigArgument(List<String> availableOptions) {
/*  34 */     this.availableOptions = availableOptions;
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<String> getAvailableOptions() {
/*  39 */     return this.availableOptions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String parse(StringReader reader) throws CommandSyntaxException {
/*  45 */     String name = reader.readUnquotedString();
/*  46 */     for (String option : getAvailableOptions()) {
/*     */       
/*  48 */       if (option.equals(name))
/*  49 */         return option; 
/*     */     } 
/*  51 */     throw INVALID_VALUE.create(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
/*  57 */     return SharedSuggestionProvider.m_82970_(getAvailableOptions(), builder);
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> ForgeConfigSpec.ConfigValue<T> get(CommandContext<CommandSourceStack> context, String argName, ForgeConfigSpec spec) {
/*  62 */     String path = (String)context.getArgument(argName, String.class);
/*  63 */     return (ForgeConfigSpec.ConfigValue<T>)spec.getValues().get(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ConfigArgument arg(Map<String, ForgeConfigSpec.ValueSpec> allValues, Class<?> arg) {
/*  68 */     return new ConfigArgument(allValues.entrySet().stream().filter(e -> {
/*     */             Object patt2477$temp = ((ForgeConfigSpec.ValueSpec)e.getValue()).getDefault(); Enum<?> enub = (Enum)patt2477$temp; return (patt2477$temp instanceof Enum) ? enub.getDeclaringClass().isAssignableFrom(arg) : ((ForgeConfigSpec.ValueSpec)e.getValue()).getDefault().getClass().isAssignableFrom(arg);
/*  70 */           }).map(Map.Entry::getKey).toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public static ConfigArgument any(Map<String, ForgeConfigSpec.ValueSpec> allValues) {
/*  75 */     return new ConfigArgument(allValues.entrySet().stream().map(Map.Entry::getKey).toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Serializer
/*     */     implements ArgumentTypeInfo<ConfigArgument, Serializer.Template>
/*     */   {
/*     */     public void serializeToNetwork(Template template, FriendlyByteBuf buffer) {
/*  83 */       buffer.m_236828_(template.availableOptions, FriendlyByteBuf::m_130070_);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Template deserializeFromNetwork(FriendlyByteBuf buffer) {
/*  89 */       return new Template(buffer.m_236845_(FriendlyByteBuf::m_130277_));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeToJson(Template template, JsonObject object) {
/*  95 */       JsonArray array = new JsonArray();
/*  96 */       for (String option : template.availableOptions)
/*  97 */         array.add(option); 
/*  98 */       object.add("available_options", (JsonElement)array);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Template unpack(ConfigArgument argument) {
/* 104 */       return new Template(argument.getAvailableOptions());
/*     */     }
/*     */     
/*     */     public final class Template
/*     */       implements ArgumentTypeInfo.Template<ConfigArgument>
/*     */     {
/*     */       public final List<String> availableOptions;
/*     */       
/*     */       private Template(List<String> availableOptions) {
/* 113 */         this.availableOptions = availableOptions;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public ConfigArgument instantiate(CommandBuildContext context) {
/* 119 */         return new ConfigArgument(this.availableOptions);
/*     */       }
/*     */ 
/*     */       
/*     */       public ArgumentTypeInfo<ConfigArgument, ?> m_213709_()
/*     */       {
/* 125 */         return ConfigArgument.Serializer.this; } } } public final class Template implements ArgumentTypeInfo.Template<ConfigArgument> { public ArgumentTypeInfo<ConfigArgument, ?> m_213709_() { return ConfigArgument.Serializer.this; }
/*     */ 
/*     */     
/*     */     public final List<String> availableOptions;
/*     */     
/*     */     private Template(List<String> availableOptions) {
/*     */       this.availableOptions = availableOptions;
/*     */     }
/*     */     
/*     */     public ConfigArgument instantiate(CommandBuildContext context) {
/*     */       return new ConfigArgument(this.availableOptions);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\command\argument\ConfigArgument.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */