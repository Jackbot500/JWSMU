/*     */ package nonamecrackers2.crackerslib.common.command.argument;
/*     */ 
/*     */ import com.mojang.brigadier.arguments.ArgumentType;
/*     */ import java.util.List;
/*     */ import net.minecraft.commands.CommandBuildContext;
/*     */ import net.minecraft.commands.synchronization.ArgumentTypeInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Template
/*     */   implements ArgumentTypeInfo.Template<ConfigArgument>
/*     */ {
/*     */   public final List<String> availableOptions;
/*     */   
/*     */   private Template(List<String> availableOptions) {
/* 113 */     this.availableOptions = availableOptions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigArgument instantiate(CommandBuildContext context) {
/* 119 */     return new ConfigArgument(this.availableOptions);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ArgumentTypeInfo<ConfigArgument, ?> m_213709_() {
/* 125 */     return ConfigArgument.Serializer.this;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\command\argument\ConfigArgument$Serializer$Template.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */