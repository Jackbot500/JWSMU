/*     */ package nonamecrackers2.crackerslib.common.command;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import com.mojang.brigadier.CommandDispatcher;
/*     */ import com.mojang.brigadier.arguments.ArgumentType;
/*     */ import com.mojang.brigadier.arguments.BoolArgumentType;
/*     */ import com.mojang.brigadier.arguments.DoubleArgumentType;
/*     */ import com.mojang.brigadier.arguments.IntegerArgumentType;
/*     */ import com.mojang.brigadier.arguments.StringArgumentType;
/*     */ import com.mojang.brigadier.builder.ArgumentBuilder;
/*     */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*     */ import com.mojang.brigadier.builder.RequiredArgumentBuilder;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.commands.CommandSourceStack;
/*     */ import net.minecraft.commands.Commands;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.eventbus.api.Event;
/*     */ import net.minecraftforge.fml.config.ModConfig;
/*     */ import net.minecraftforge.server.command.EnumArgument;
/*     */ import nonamecrackers2.crackerslib.common.command.argument.ConfigArgument;
/*     */ import nonamecrackers2.crackerslib.common.config.ConfigHelper;
/*     */ import nonamecrackers2.crackerslib.common.event.impl.OnConfigOptionSaved;
/*     */ 
/*     */ 
/*     */ public class ConfigCommandBuilder
/*     */ {
/*     */   private final String modid;
/*  38 */   private final Map<ModConfig.Type, ForgeConfigSpec> specs = Maps.newEnumMap(ModConfig.Type.class);
/*     */   
/*     */   private final LiteralArgumentBuilder<CommandSourceStack> argumentBuilder;
/*     */   private final CommandDispatcher<CommandSourceStack> dispatcher;
/*     */   
/*     */   public ConfigCommandBuilder(String modid, LiteralArgumentBuilder<CommandSourceStack> argumentBuilder, CommandDispatcher<CommandSourceStack> dispatcher) {
/*  44 */     this.modid = modid;
/*  45 */     this.argumentBuilder = argumentBuilder;
/*  46 */     this.dispatcher = dispatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ConfigCommandBuilder(LiteralArgumentBuilder<CommandSourceStack> argumentBuilder, CommandDispatcher<CommandSourceStack> dispatcher) {
/*  55 */     this("UNKNOWN", argumentBuilder, dispatcher);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ConfigCommandBuilder builder(CommandDispatcher<CommandSourceStack> dispatcher, String modid) {
/*  60 */     return new ConfigCommandBuilder(modid, (LiteralArgumentBuilder<CommandSourceStack>)Commands.m_82127_(modid).requires(src -> src.m_6761_(2)), dispatcher);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigCommandBuilder addSpec(ModConfig.Type type, ForgeConfigSpec spec) {
/*  65 */     if (this.specs.containsKey(type))
/*  66 */       throw new IllegalArgumentException("Spec '" + type + "' already registered."); 
/*  67 */     this.specs.put(type, spec);
/*  68 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void register() {
/*  73 */     LiteralArgumentBuilder<CommandSourceStack> root = Commands.m_82127_("config");
/*  74 */     for (Map.Entry<ModConfig.Type, ForgeConfigSpec> entry : this.specs.entrySet()) {
/*     */       
/*  76 */       ModConfig.Type type = entry.getKey();
/*  77 */       ForgeConfigSpec spec = entry.getValue();
/*  78 */       LiteralArgumentBuilder<CommandSourceStack> specArgument = Commands.m_82127_(type.extension());
/*  79 */       addArgumentsForSpec(spec, this.modid, type, specArgument);
/*  80 */       root.then((ArgumentBuilder)specArgument);
/*     */     } 
/*  82 */     this.argumentBuilder.then((ArgumentBuilder)root);
/*  83 */     this.dispatcher.register(this.argumentBuilder);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addArgumentsForSpec(ForgeConfigSpec spec, String modid, ModConfig.Type type, LiteralArgumentBuilder<CommandSourceStack> specArgument) {
/*  88 */     Map<String, ForgeConfigSpec.ValueSpec> allValues = ConfigHelper.getAllSpecs(spec);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     LiteralArgumentBuilder<CommandSourceStack> setArg = (LiteralArgumentBuilder<CommandSourceStack>)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.m_82127_("set").then(((RequiredArgumentBuilder)Commands.m_82129_("double", (ArgumentType)ConfigArgument.arg(allValues, Double.class)).then(Commands.m_82129_("value", (ArgumentType)DoubleArgumentType.doubleArg()).executes(ctx -> set(ctx, "double", DoubleArgumentType::getDouble, spec, modid, type)))).then(Commands.m_82127_("default").executes(ctx -> setDefault(ctx, "double", spec, modid, type))))).then(((RequiredArgumentBuilder)Commands.m_82129_("boolean", (ArgumentType)ConfigArgument.arg(allValues, Boolean.class)).then(Commands.m_82129_("value", (ArgumentType)BoolArgumentType.bool()).executes(ctx -> set(ctx, "boolean", BoolArgumentType::getBool, spec, modid, type)))).then(Commands.m_82127_("default").executes(ctx -> setDefault(ctx, "boolean", spec, modid, type))))).then(((RequiredArgumentBuilder)Commands.m_82129_("integer", (ArgumentType)ConfigArgument.arg(allValues, Integer.class)).then(Commands.m_82129_("value", (ArgumentType)IntegerArgumentType.integer()).executes(ctx -> set(ctx, "integer", IntegerArgumentType::getInteger, spec, modid, type)))).then(Commands.m_82127_("default").executes(ctx -> setDefault(ctx, "integer", spec, modid, type))))).then((
/* 124 */         (RequiredArgumentBuilder)Commands.m_82129_("string", (ArgumentType)ConfigArgument.arg(allValues, String.class))
/* 125 */         .then(
/* 126 */           Commands.m_82129_("value", (ArgumentType)StringArgumentType.greedyString())
/* 127 */           .executes(ctx -> set(ctx, "string", StringArgumentType::getString, spec, modid, type))))
/*     */         
/* 129 */         .then(
/* 130 */           Commands.m_82127_("default")
/* 131 */           .executes(ctx -> setDefault(ctx, "string", spec, modid, type))));
/*     */ 
/*     */ 
/*     */     
/* 135 */     for (Class<Enum> clazz : gatherEnumValueClasses(allValues)) {
/*     */       
/* 137 */       String name = clazz.getSimpleName();
/* 138 */       setArg.then((
/* 139 */           (RequiredArgumentBuilder)Commands.m_82129_(name, (ArgumentType)ConfigArgument.arg(allValues, clazz))
/* 140 */           .then(
/* 141 */             Commands.m_82129_("value", (ArgumentType)EnumArgument.enumArgument(clazz))
/* 142 */             .executes(ctx -> set(ctx, name, (), spec, modid, type))))
/*     */           
/* 144 */           .then(
/* 145 */             Commands.m_82127_("default")
/* 146 */             .executes(ctx -> setDefault(ctx, name, spec, modid, type))));
/*     */     } 
/*     */ 
/*     */     
/* 150 */     specArgument.then(
/* 151 */         Commands.m_82127_("get")
/* 152 */         .then(
/* 153 */           Commands.m_82129_("value", (ArgumentType)ConfigArgument.any(allValues))
/* 154 */           .executes(ctx -> get(ctx, spec))));
/*     */ 
/*     */     
/* 157 */     specArgument.then((ArgumentBuilder)setArg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<Class<Enum>> gatherEnumValueClasses(Map<String, ForgeConfigSpec.ValueSpec> allValues) {
/* 163 */     List<Class<Enum>> list = Lists.newArrayList();
/* 164 */     for (ForgeConfigSpec.ValueSpec value : allValues.values()) {
/*     */       
/* 166 */       Object obj = value.getDefault();
/* 167 */       if (obj instanceof Enum) { Enum<Enum> enu = (Enum)obj; if (!list.contains(enu.getDeclaringClass()))
/* 168 */           list.add(enu.getDeclaringClass());  }
/*     */     
/* 170 */     }  return list;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> int set(CommandContext<CommandSourceStack> context, String arg, BiFunction<CommandContext<CommandSourceStack>, String, T> valueGetter, ForgeConfigSpec spec, String modid, ModConfig.Type type) throws CommandSyntaxException {
/* 175 */     CommandSourceStack source = (CommandSourceStack)context.getSource();
/* 176 */     ForgeConfigSpec.ConfigValue<T> config = ConfigArgument.get(context, arg, spec);
/* 177 */     T value = valueGetter.apply(context, "value");
/* 178 */     ForgeConfigSpec.ValueSpec valueSpec = (ForgeConfigSpec.ValueSpec)spec.getRaw(config.getPath());
/* 179 */     if (!valueSpec.test(value))
/* 180 */       return 0; 
/* 181 */     OnConfigOptionSaved<T> event = new OnConfigOptionSaved(modid, type, OnConfigOptionSaved.Source.COMMAND, config, value, !Objects.equals(config.get(), value));
/* 182 */     MinecraftForge.EVENT_BUS.post((Event)event);
/* 183 */     if (event.getOverrideValue() != null)
/* 184 */       value = (T)event.getOverrideValue(); 
/* 185 */     if (!Objects.equals(config.get(), value) && valueSpec.test(value)) {
/*     */       
/* 187 */       config.set(value);
/* 188 */       String joinedPath = ConfigHelper.DOT_JOINER.join(config.getPath());
/* 189 */       MutableComponent mutableComponent = Component.m_237110_("commands.crackerslib.setConfig.set.success", new Object[] { joinedPath, value });
/* 190 */       source.m_288197_(() -> result, true);
/* 191 */       if (valueSpec.needsWorldRestart()) {
/*     */         
/* 193 */         source.m_288197_(() -> Component.m_237110_("commands.crackerslib.setConfig.set.note", new Object[] { joinedPath }).m_130940_(ChatFormatting.GRAY), false);
/* 194 */         return 2;
/*     */       } 
/*     */ 
/*     */       
/* 198 */       return 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 203 */     source.m_81352_((Component)Component.m_237115_("commands.crackerslib.setConfig.set.fail"));
/* 204 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int get(CommandContext<CommandSourceStack> context, ForgeConfigSpec spec) {
/* 210 */     ForgeConfigSpec.ConfigValue<Object> config = ConfigArgument.get(context, "value", spec);
/* 211 */     Object val = config.get();
/* 212 */     ((CommandSourceStack)context.getSource()).m_288197_(() -> Component.m_237110_("commands.crackerslib.getConfig.get", new Object[] { ConfigHelper.DOT_JOINER.join(config.getPath()), config.get() }), false);
/* 213 */     if (val instanceof Integer) { Integer integer = (Integer)val;
/* 214 */       return integer.intValue(); }
/* 215 */      if (val instanceof Boolean) { Boolean bool = (Boolean)val;
/* 216 */       return bool.booleanValue() ? 1 : 0; }
/* 217 */      if (val instanceof Double) { Double decimal = (Double)val;
/* 218 */       return (int)(decimal.doubleValue() * 10.0D); }
/* 219 */      if (val instanceof Enum) { Enum<?> enu = (Enum)val;
/* 220 */       return enu.ordinal(); }
/*     */     
/* 222 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int setDefault(CommandContext<CommandSourceStack> context, String arg, ForgeConfigSpec spec, String modid, ModConfig.Type type) {
/* 228 */     CommandSourceStack source = (CommandSourceStack)context.getSource();
/* 229 */     ForgeConfigSpec.ConfigValue<Object> config = ConfigArgument.get(context, arg, spec);
/* 230 */     ForgeConfigSpec.ValueSpec valueSpec = (ForgeConfigSpec.ValueSpec)spec.getRaw(config.getPath());
/* 231 */     boolean flag = !Objects.equals(config.get(), config.getDefault());
/* 232 */     MinecraftForge.EVENT_BUS.post((Event)new OnConfigOptionSaved(modid, type, OnConfigOptionSaved.Source.COMMAND, config, config.getDefault(), flag));
/* 233 */     if (flag) {
/*     */       
/* 235 */       config.set(config.getDefault());
/* 236 */       String name = ConfigHelper.DOT_JOINER.join(config.getPath());
/* 237 */       source.m_288197_(() -> Component.m_237110_("commands.crackerslib.setDefault.success", new Object[] { name, config.get() }), true);
/* 238 */       if (valueSpec.needsWorldRestart()) {
/*     */         
/* 240 */         source.m_288197_(() -> Component.m_237110_("commands.crackerslib.setConfig.set.note", new Object[] { name }).m_130940_(ChatFormatting.GRAY), false);
/* 241 */         return 2;
/*     */       } 
/*     */ 
/*     */       
/* 245 */       return 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 250 */     source.m_81352_((Component)Component.m_237115_("commands.crackerslib.setConfig.set.fail"));
/* 251 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\command\ConfigCommandBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */