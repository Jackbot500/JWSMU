/*    */ package nonamecrackers2.crackerslib.common.extending;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import net.minecraft.world.level.block.Block;
/*    */ import net.minecraft.world.level.block.entity.BlockEntityType;
/*    */ import nonamecrackers2.crackerslib.mixin.MixinBlockEntityType;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockEntityTypeExtender
/*    */ {
/*    */   public static void addToBlockEntityType(BlockEntityType<?> type, Block... blocks) {
/* 14 */     MixinBlockEntityType mixin = (MixinBlockEntityType)type;
/* 15 */     Set<Block> currentBlocks = new HashSet<>(mixin.crackerslib$getValidBlocks());
/* 16 */     for (Block block : blocks)
/* 17 */       currentBlocks.add(block); 
/* 18 */     mixin.crackerslib$setValidBlocks(currentBlocks);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\extending\BlockEntityTypeExtender.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */