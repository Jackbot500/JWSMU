/*    */ package nonamecrackers2.crackerslib.common.init;
/*    */ 
/*    */ import net.minecraft.commands.synchronization.ArgumentTypeInfo;
/*    */ import net.minecraft.commands.synchronization.ArgumentTypeInfos;
/*    */ import net.minecraftforge.eventbus.api.IEventBus;
/*    */ import net.minecraftforge.registries.DeferredRegister;
/*    */ import net.minecraftforge.registries.ForgeRegistries;
/*    */ import net.minecraftforge.registries.RegistryObject;
/*    */ import nonamecrackers2.crackerslib.common.command.argument.ConfigArgument;
/*    */ 
/*    */ 
/*    */ public class CrackersLibCommandArguments
/*    */ {
/* 14 */   private static final DeferredRegister<ArgumentTypeInfo<?, ?>> TYPES = DeferredRegister.create(ForgeRegistries.COMMAND_ARGUMENT_TYPES, "crackerslib");
/*    */   
/* 16 */   public static final RegistryObject<ConfigArgument.Serializer> CONFIG_ARGUMENT = TYPES.register("config", () -> (ConfigArgument.Serializer)ArgumentTypeInfos.registerByClass(ConfigArgument.class, (ArgumentTypeInfo)new ConfigArgument.Serializer()));
/*    */ 
/*    */   
/*    */   public static void register(IEventBus modBus) {
/* 20 */     TYPES.register(modBus);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\init\CrackersLibCommandArguments.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */