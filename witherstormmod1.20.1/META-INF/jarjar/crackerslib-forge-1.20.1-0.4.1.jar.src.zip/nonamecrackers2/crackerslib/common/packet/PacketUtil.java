/*     */ package nonamecrackers2.crackerslib.common.packet;
/*     */ 
/*     */ import com.google.common.collect.Maps;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.function.Supplier;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.network.FriendlyByteBuf;
/*     */ import net.minecraft.server.level.ServerPlayer;
/*     */ import net.minecraftforge.fml.LogicalSide;
/*     */ import net.minecraftforge.network.NetworkDirection;
/*     */ import net.minecraftforge.network.NetworkEvent;
/*     */ import net.minecraftforge.network.simple.SimpleChannel;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PacketUtil
/*     */ {
/*     */   @Nullable
/*     */   private static Throwable lastException;
/*  25 */   private static final Map<SimpleChannel, AtomicInteger> CURRENT_IDS = Maps.newHashMap();
/*  26 */   private static final Logger LOGGER = LogManager.getLogger();
/*     */ 
/*     */   
/*     */   public static <T extends Packet> void registerToClient(SimpleChannel channel, Class<T> clazz) {
/*  30 */     channel.registerMessage(((AtomicInteger)CURRENT_IDS
/*  31 */         .computeIfAbsent(channel, c -> new AtomicInteger())).incrementAndGet(), clazz, Packet::encodeCheck, buffer -> Packet.decode((), buffer), PacketUtil::receiveClientMessage, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  47 */         Optional.of(NetworkDirection.PLAY_TO_CLIENT));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Packet> void registerToServer(SimpleChannel channel, Class<T> clazz) {
/*  53 */     channel.registerMessage(((AtomicInteger)CURRENT_IDS
/*  54 */         .computeIfAbsent(channel, c -> new AtomicInteger())).incrementAndGet(), clazz, Packet::encodeCheck, buffer -> Packet.decode((), buffer), PacketUtil::receiveServerMessage, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  70 */         Optional.of(NetworkDirection.PLAY_TO_SERVER));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T extends Packet> void receiveClientMessage(T message, Supplier<NetworkEvent.Context> supplier) {
/*  76 */     NetworkEvent.Context context = supplier.get();
/*  77 */     LogicalSide sideReceived = context.getDirection().getReceptionSide();
/*  78 */     context.setPacketHandled(true);
/*     */     
/*  80 */     if (sideReceived != LogicalSide.CLIENT) {
/*     */       
/*  82 */       LOGGER.warn(message.toString() + " was received on the wrong side: " + message.toString());
/*     */       
/*     */       return;
/*     */     } 
/*  86 */     if (!message.isMessageValid()) {
/*     */       
/*  88 */       LOGGER.warn(message.toString() + " was invalid");
/*     */       
/*     */       return;
/*     */     } 
/*  92 */     context.enqueueWork(message.getProcessor(context)).handle((v, e) -> {
/*     */           if (e != null) {
/*     */             if (lastException == null || !lastException.getClass().equals(e.getClass())) {
/*     */               LOGGER.error("Failed to process packet {}: {}", message, e);
/*     */               e.printStackTrace();
/*     */             } 
/*     */             lastException = e;
/*     */           } 
/*     */           return v;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T extends Packet> void receiveServerMessage(T message, Supplier<NetworkEvent.Context> supplier) {
/* 109 */     NetworkEvent.Context context = supplier.get();
/* 110 */     LogicalSide sideReceived = context.getDirection().getReceptionSide();
/* 111 */     context.setPacketHandled(true);
/*     */     
/* 113 */     if (sideReceived != LogicalSide.SERVER) {
/*     */       
/* 115 */       LOGGER.warn(message.toString() + " was received on the wrong side: " + message.toString());
/*     */       
/*     */       return;
/*     */     } 
/* 119 */     if (!message.isMessageValid()) {
/*     */       
/* 121 */       LOGGER.warn(message.toString() + " was invalid");
/*     */       
/*     */       return;
/*     */     } 
/* 125 */     ServerPlayer player = context.getSender();
/* 126 */     if (player == null) {
/*     */       
/* 128 */       LOGGER.warn("The sending player is not present when " + message.toString() + " was received");
/*     */       
/*     */       return;
/*     */     } 
/* 132 */     context.enqueueWork(message.getProcessor(context)).handle((v, e) -> {
/*     */           if (e != null) {
/*     */             if (lastException == null || !lastException.getClass().equals(e.getClass())) {
/*     */               LOGGER.error("Failed to process packet {}: {}", message, e);
/*     */               e.printStackTrace();
/*     */             } 
/*     */             lastException = e;
/*     */           } 
/*     */           return v;
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\packet\PacketUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */