/*    */ package nonamecrackers2.crackerslib.common.packet;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.network.FriendlyByteBuf;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.fml.DistExecutor;
/*    */ import net.minecraftforge.network.NetworkEvent;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Packet
/*    */ {
/* 16 */   protected static final Logger LOGGER = LogManager.getLogger();
/*    */   
/*    */   protected boolean isValid;
/*    */ 
/*    */   
/*    */   public Packet(boolean valid) {
/* 22 */     this.isValid = valid;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isMessageValid() {
/* 27 */     return this.isValid;
/*    */   }
/*    */ 
/*    */   
/*    */   protected abstract void encode(FriendlyByteBuf paramFriendlyByteBuf);
/*    */   
/*    */   protected abstract void decode(FriendlyByteBuf paramFriendlyByteBuf);
/*    */   
/*    */   public static <T extends Packet> void encodeCheck(T packet, FriendlyByteBuf buffer) {
/* 36 */     if (!((Packet)packet).isValid)
/* 37 */       return;  packet.encode(buffer);
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends Packet> T decode(Supplier<T> blank, FriendlyByteBuf buffer) {
/* 42 */     Packet packet = (Packet)blank.get();
/*    */     
/*    */     try {
/* 45 */       packet.decode(buffer);
/*    */     }
/* 47 */     catch (IllegalArgumentException|IndexOutOfBoundsException|io.netty.handler.codec.DecoderException e) {
/*    */       
/* 49 */       LOGGER.warn("Exception while reading " + packet.toString() + "; " + e);
/* 50 */       e.printStackTrace();
/* 51 */       return (T)packet;
/*    */     } 
/* 53 */     packet.isValid = true;
/* 54 */     return (T)packet;
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract Runnable getProcessor(NetworkEvent.Context paramContext);
/*    */   
/*    */   protected static Runnable client(Runnable processor) {
/* 61 */     return () -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, ());
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\packet\Packet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */