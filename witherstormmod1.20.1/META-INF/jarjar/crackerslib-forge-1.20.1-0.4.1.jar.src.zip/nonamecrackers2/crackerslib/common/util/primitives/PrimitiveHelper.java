/*     */ package nonamecrackers2.crackerslib.common.util.primitives;
/*     */ 
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.network.FriendlyByteBuf;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.phys.Vec2;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ import org.joml.Quaternionf;
/*     */ import org.joml.Quaternionfc;
/*     */ import org.joml.Vector3f;
/*     */ 
/*     */ 
/*     */ public class PrimitiveHelper
/*     */ {
/*     */   public static CompoundTag quaternionToTag(Quaternionf quaternion) {
/*  16 */     CompoundTag tag = new CompoundTag();
/*  17 */     tag.m_128350_("x", quaternion.x());
/*  18 */     tag.m_128350_("y", quaternion.y());
/*  19 */     tag.m_128350_("z", quaternion.z());
/*  20 */     tag.m_128350_("w", quaternion.w());
/*  21 */     return tag;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Quaternionf quaternionFromTag(CompoundTag tag) {
/*  26 */     Quaternionf quaternion = (new Quaternionf()).identity();
/*  27 */     if (tag.m_128425_("x", 5))
/*  28 */       quaternion.x = tag.m_128457_("x"); 
/*  29 */     if (tag.m_128425_("y", 5))
/*  30 */       quaternion.y = tag.m_128457_("y"); 
/*  31 */     if (tag.m_128425_("z", 5))
/*  32 */       quaternion.z = tag.m_128457_("z"); 
/*  33 */     if (tag.m_128425_("w", 5))
/*  34 */       quaternion.w = tag.m_128457_("w"); 
/*  35 */     return quaternion;
/*     */   }
/*     */ 
/*     */   
/*     */   public static CompoundTag vector3fToTag(Vector3f vec) {
/*  40 */     CompoundTag tag = new CompoundTag();
/*  41 */     tag.m_128350_("x", vec.x);
/*  42 */     tag.m_128350_("y", vec.y);
/*  43 */     tag.m_128350_("z", vec.z);
/*  44 */     return tag;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vector3f vector3fFromTag(CompoundTag tag) {
/*  49 */     return new Vector3f(tag.m_128457_("x"), tag.m_128457_("y"), tag.m_128457_("z"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static CompoundTag vec3ToTag(Vec3 vec) {
/*  54 */     CompoundTag tag = new CompoundTag();
/*  55 */     tag.m_128347_("x", vec.f_82479_);
/*  56 */     tag.m_128347_("y", vec.f_82480_);
/*  57 */     tag.m_128347_("z", vec.f_82481_);
/*  58 */     return tag;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 vec3FromTag(CompoundTag tag) {
/*  63 */     return new Vec3(tag.m_128459_("x"), tag.m_128459_("y"), tag.m_128459_("z"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static CompoundTag chunkPosToTag(ChunkPos pos) {
/*  68 */     CompoundTag tag = new CompoundTag();
/*  69 */     tag.m_128405_("chunkX", pos.f_45578_);
/*  70 */     tag.m_128405_("chunkZ", pos.f_45579_);
/*  71 */     return tag;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ChunkPos chunkPosFromTag(CompoundTag tag) {
/*  76 */     int x = tag.m_128451_("chunkX");
/*  77 */     int z = tag.m_128451_("chunkZ");
/*  78 */     return new ChunkPos(x, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public static CompoundTag vec2ToTag(Vec2 vec) {
/*  83 */     CompoundTag tag = new CompoundTag();
/*  84 */     tag.m_128347_("x", vec.f_82470_);
/*  85 */     tag.m_128347_("y", vec.f_82471_);
/*  86 */     return tag;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec2 vec2FromTag(CompoundTag tag) {
/*  91 */     return new Vec2(tag.m_128457_("x"), tag.m_128457_("y"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void encodeVec3(FriendlyByteBuf buffer, Vec3 vec) {
/*  96 */     buffer.writeDouble(vec.f_82479_);
/*  97 */     buffer.writeDouble(vec.f_82480_);
/*  98 */     buffer.writeDouble(vec.f_82481_);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 decodeVec3(FriendlyByteBuf buffer) {
/* 103 */     return new Vec3(buffer.readDouble(), buffer.readDouble(), buffer.readDouble());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void saveEnum(Enum<?> enub, CompoundTag tag, String id) {
/* 108 */     tag.m_128405_(id, enub.ordinal());
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T extends Enum<T>> T readEnum(Class<T> clazz, CompoundTag tag, String id) {
/* 113 */     Enum[] arrayOfEnum = (Enum[])clazz.getEnumConstants();
/* 114 */     int ordinal = tag.m_128451_(id);
/* 115 */     if (ordinal < arrayOfEnum.length && ordinal >= 0) {
/* 116 */       return (T)arrayOfEnum[ordinal];
/*     */     }
/* 118 */     return (T)arrayOfEnum[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vector3f vec3ToVector3f(Vec3 vec) {
/* 123 */     return new Vector3f((float)vec.f_82479_, (float)vec.f_82480_, (float)vec.f_82481_);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 vector3fToVec3(Vector3f vec) {
/* 128 */     return new Vec3(vec);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3 rotate(Vec3 vec, Quaternionf rotation) {
/* 133 */     Vector3f vecF = vec3ToVector3f(vec);
/* 134 */     vecF.rotate((Quaternionfc)rotation);
/* 135 */     return vector3fToVec3(vecF);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\commo\\util\primitives\PrimitiveHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */