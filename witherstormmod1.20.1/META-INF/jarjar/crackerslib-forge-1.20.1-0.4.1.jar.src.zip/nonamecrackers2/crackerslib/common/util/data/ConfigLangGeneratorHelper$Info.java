/*     */ package nonamecrackers2.crackerslib.common.util.data;
/*     */ 
/*     */ import java.util.regex.Pattern;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Info
/*     */ {
/*  88 */   ALL(null),
/*  89 */   ONLY_RANGE("(?!\\nRange)\\n.*?(?=\\nRange|$)"),
/*  90 */   NONE_EXTRA("\\n.*");
/*     */   
/*     */   private final Pattern pattern;
/*     */ 
/*     */   
/*     */   Info(String regex) {
/*  96 */     if (regex != null) {
/*  97 */       this.pattern = Pattern.compile(regex, 8);
/*     */     } else {
/*  99 */       this.pattern = null;
/*     */     } 
/*     */   }
/*     */   @Nullable
/*     */   public Pattern getPattern() {
/* 104 */     return this.pattern;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\commo\\util\data\ConfigLangGeneratorHelper$Info.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */