/*     */ package nonamecrackers2.crackerslib.common.util.data;
/*     */ 
/*     */ import com.electronwill.nightconfig.core.UnmodifiableConfig;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ import net.minecraftforge.common.data.LanguageProvider;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLangGeneratorHelper
/*     */ {
/*     */   public static void langForSpec(String modid, ForgeConfigSpec spec, LanguageProvider provider, Info infoType) {
/*  33 */     forValues(modid, spec.getSpec().valueMap(), provider, infoType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void langForSpec(String modid, ForgeConfigSpec spec, LanguageProvider provider) {
/*  48 */     langForSpec(modid, spec, provider, Info.ALL);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void forValues(String modid, Map<String, Object> values, LanguageProvider provider, Info infoType) {
/*  53 */     for (Map.Entry<String, Object> entry : values.entrySet()) {
/*     */       
/*  55 */       String name = entry.getKey();
/*  56 */       Object object = entry.getValue(); if (object instanceof ForgeConfigSpec.ValueSpec) { ForgeConfigSpec.ValueSpec spec = (ForgeConfigSpec.ValueSpec)object;
/*     */         
/*  58 */         String properTitle = StringUtils.capitalize(StringUtils.join((Object[])StringUtils.splitByCharacterTypeCamelCase(name), " "));
/*  59 */         tryAdd("gui." + modid + ".config." + name + ".title", properTitle, provider);
/*  60 */         String desc = spec.getComment();
/*  61 */         String finalDesc = desc;
/*  62 */         Pattern pattern = infoType.getPattern();
/*  63 */         if (pattern != null)
/*  64 */           finalDesc = pattern.matcher(desc).replaceAll(""); 
/*  65 */         tryAdd(spec.getTranslationKey(), finalDesc, provider); continue; }
/*     */       
/*  67 */       object = entry.getValue(); if (object instanceof UnmodifiableConfig) { UnmodifiableConfig category = (UnmodifiableConfig)object;
/*     */         
/*  69 */         String[] split = name.split("_");
/*  70 */         for (int i = 0; i < split.length; i++)
/*  71 */           split[i] = StringUtils.capitalize(split[i]); 
/*  72 */         String properTitle = StringUtils.join((Object[])split, " ");
/*  73 */         tryAdd("gui." + modid + ".config.category." + name + ".title", properTitle, provider);
/*  74 */         forValues(modid, category.valueMap(), provider, infoType); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void tryAdd(String key, String entry, LanguageProvider provider) {
/*     */     try {
/*  82 */       provider.add(key, entry);
/*  83 */     } catch (IllegalStateException illegalStateException) {}
/*     */   }
/*     */   
/*     */   public enum Info
/*     */   {
/*  88 */     ALL(null),
/*  89 */     ONLY_RANGE("(?!\\nRange)\\n.*?(?=\\nRange|$)"),
/*  90 */     NONE_EXTRA("\\n.*");
/*     */     
/*     */     private final Pattern pattern;
/*     */ 
/*     */     
/*     */     Info(String regex) {
/*  96 */       if (regex != null) {
/*  97 */         this.pattern = Pattern.compile(regex, 8);
/*     */       } else {
/*  99 */         this.pattern = null;
/*     */       } 
/*     */     }
/*     */     @Nullable
/*     */     public Pattern getPattern() {
/* 104 */       return this.pattern;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\commo\\util\data\ConfigLangGeneratorHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */