/*    */ package nonamecrackers2.crackerslib.common.event;
/*    */ 
/*    */ import net.minecraft.data.DataGenerator;
/*    */ import net.minecraft.data.DataProvider;
/*    */ import net.minecraftforge.data.event.GatherDataEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CrackersLibDataEvents
/*    */ {
/*    */   public static void gatherData(GatherDataEvent event) {
/* 12 */     DataGenerator generator = event.getGenerator();
/* 13 */     generator.addProvider(event.includeClient(), nonamecrackers2.crackerslib.common.data.CrackersLibLangProvider::new);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\event\CrackersLibDataEvents.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */