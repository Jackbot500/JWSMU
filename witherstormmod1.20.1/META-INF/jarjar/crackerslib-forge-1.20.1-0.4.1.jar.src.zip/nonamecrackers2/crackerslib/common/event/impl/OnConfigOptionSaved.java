/*    */ package nonamecrackers2.crackerslib.common.event.impl;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.eventbus.api.Event;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OnConfigOptionSaved<T>
/*    */   extends Event
/*    */ {
/*    */   private final String modid;
/*    */   private final ModConfig.Type type;
/*    */   private final Source source;
/*    */   private final ForgeConfigSpec.ConfigValue<T> config;
/*    */   private final T newValue;
/*    */   private final boolean didValueChange;
/*    */   @Nullable
/*    */   private T override;
/*    */   
/*    */   public OnConfigOptionSaved(String modid, ModConfig.Type type, Source source, ForgeConfigSpec.ConfigValue<T> config, T newValue, boolean didValueChange) {
/* 24 */     this.modid = modid;
/* 25 */     this.type = type;
/* 26 */     this.source = source;
/* 27 */     this.config = config;
/* 28 */     this.newValue = newValue;
/* 29 */     this.didValueChange = didValueChange;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModId() {
/* 34 */     return this.modid;
/*    */   }
/*    */ 
/*    */   
/*    */   public ModConfig.Type getType() {
/* 39 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public Source getSource() {
/* 44 */     return this.source;
/*    */   }
/*    */ 
/*    */   
/*    */   public T getNewValue() {
/* 49 */     return this.newValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public ForgeConfigSpec.ConfigValue<T> getConfigOption() {
/* 54 */     return this.config;
/*    */   }
/*    */ 
/*    */   
/*    */   public void overrideValue(T value) {
/* 59 */     this.override = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public T getOverrideValue() {
/* 64 */     return this.override;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean didValueChange() {
/* 69 */     return this.didValueChange;
/*    */   }
/*    */   
/*    */   public enum Source
/*    */   {
/* 74 */     CONFIG_SCREEN,
/* 75 */     COMMAND;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\common\event\impl\OnConfigOptionSaved.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */