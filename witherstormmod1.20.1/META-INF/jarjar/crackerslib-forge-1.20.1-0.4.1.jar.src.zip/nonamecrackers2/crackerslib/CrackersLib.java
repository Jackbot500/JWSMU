/*    */ package nonamecrackers2.crackerslib;
/*    */ 
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraft.world.level.block.Block;
/*    */ import net.minecraft.world.level.block.Blocks;
/*    */ import net.minecraft.world.level.block.entity.BlockEntityType;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.eventbus.api.IEventBus;
/*    */ import net.minecraftforge.fml.ModContainer;
/*    */ import net.minecraftforge.fml.ModLoader;
/*    */ import net.minecraftforge.fml.ModLoadingContext;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.config.IConfigSpec;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
/*    */ import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
/*    */ import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
/*    */ import nonamecrackers2.crackerslib.client.event.CrackersLibClientEvents;
/*    */ import nonamecrackers2.crackerslib.client.event.impl.RegisterConfigScreensEvent;
/*    */ import nonamecrackers2.crackerslib.client.gui.ConfigMenuButtons;
/*    */ import nonamecrackers2.crackerslib.common.compat.CompatHelper;
/*    */ import nonamecrackers2.crackerslib.common.config.CrackersLibConfig;
/*    */ import nonamecrackers2.crackerslib.common.config.preset.ConfigPresets;
/*    */ import nonamecrackers2.crackerslib.common.event.CrackersLibDataEvents;
/*    */ import nonamecrackers2.crackerslib.common.extending.BlockEntityTypeExtender;
/*    */ import nonamecrackers2.crackerslib.common.init.CrackersLibCommandArguments;
/*    */ 
/*    */ @Mod("crackerslib")
/*    */ public class CrackersLib
/*    */ {
/*    */   public CrackersLib() {
/* 32 */     IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
/* 33 */     modBus.addListener(this::commonSetup);
/* 34 */     modBus.addListener(this::clientSetup);
/* 35 */     modBus.addListener(CrackersLibDataEvents::gatherData);
/* 36 */     ModLoadingContext context = ModLoadingContext.get();
/* 37 */     context.registerConfig(ModConfig.Type.CLIENT, (IConfigSpec)CrackersLibConfig.CLIENT_SPEC);
/*    */     
/* 39 */     CrackersLibCommandArguments.register(modBus);
/*    */   }
/*    */   public static final String MODID = "crackerslib";
/*    */   
/*    */   public void clientSetup(FMLClientSetupEvent event) {
/* 44 */     IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
/* 45 */     modBus.addListener(CrackersLibClientEvents::registerConfigScreen);
/*    */     
/* 47 */     IEventBus forgeBus = MinecraftForge.EVENT_BUS;
/* 48 */     forgeBus.register(CrackersLibClientEvents.class);
/* 49 */     event.enqueueWork(() -> {
/*    */           ModLoader.get().runEventGenerator(());
/*    */           ConfigMenuButtons.gatherButtonFactories();
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void commonSetup(FMLCommonSetupEvent event) {
/* 63 */     event.enqueueWork(() -> {
/*    */           ConfigPresets.gatherPresets();
/*    */           CompatHelper.checkForLoaded();
/*    */           BlockEntityTypeExtender.addToBlockEntityType(BlockEntityType.f_58930_, new Block[] { Blocks.f_50618_ });
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   public static ResourceLocation id(String path) {
/* 72 */     return new ResourceLocation("crackerslib", path);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\CrackersLib.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */