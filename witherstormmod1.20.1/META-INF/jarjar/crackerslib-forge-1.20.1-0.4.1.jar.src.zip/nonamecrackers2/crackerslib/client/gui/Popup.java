/*     */ package nonamecrackers2.crackerslib.client.gui;
/*     */ 
/*     */ import com.google.common.collect.Queues;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.EditBox;
/*     */ import net.minecraft.client.gui.components.MultiLineLabel;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.layouts.FrameLayout;
/*     */ import net.minecraft.client.gui.layouts.GridLayout;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.navigation.ScreenRectangle;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.network.chat.CommonComponents;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.SelectableNamedObjectList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Popup
/*     */   extends Screen
/*     */ {
/*  33 */   private static final Queue<Popup> POPUP_QUEUE = Queues.newArrayDeque();
/*     */   private static final int BUTTON_WIDTH = 80;
/*     */   @Nullable
/*     */   private final Screen previous;
/*     */   private final Initializer onInitialized;
/*     */   private final MultiLineLabel text;
/*     */   private final int boxWidth;
/*     */   private final int widgetsHeight;
/*     */   private int x;
/*     */   private int y;
/*     */   private int boxHeight;
/*     */   
/*     */   public Popup(@Nullable Screen previous, Initializer onInitialized, int width, int widgetsHeight, Component pMessage) {
/*  46 */     super(pMessage);
/*  47 */     this.text = MultiLineLabel.m_94341_((Minecraft.m_91087_()).f_91062_, (FormattedText)pMessage, width - 20);
/*  48 */     this.previous = previous;
/*  49 */     this.onInitialized = onInitialized;
/*  50 */     this.boxWidth = width;
/*  51 */     this.widgetsHeight = widgetsHeight;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Popup createYesNoPopupWithCancel(@Nullable Screen screen, Runnable onAccepted, Runnable onNotAccepted, int width, Component message) {
/*  56 */     return (new Popup(screen, (p, r) -> { GridLayout layout = (new GridLayout()).m_267750_(5); GridLayout.RowHelper row = layout.m_264606_(1); GridLayout yesNoLayout = (GridLayout)row.m_264139_((LayoutElement)(new GridLayout()).m_267749_(10)); GridLayout.RowHelper yesNoRow = yesNoLayout.m_264606_(2); Button yes = (Button)yesNoRow.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.popup.yes"), ()).m_252780_(80).m_253136_()); Button no = (Button)yesNoRow.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.popup.no"), ()).m_252780_(80).m_253136_()); GridLayout cancelLayout = (GridLayout)row.m_264139_((LayoutElement)new GridLayout()); GridLayout.RowHelper cancelRow = cancelLayout.m_264606_(1); Button cancel = (Button)cancelRow.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.popup.cancel"), ()).m_252780_(170).m_253136_()); layout.m_264036_(); FrameLayout.m_267781_((LayoutElement)layout, r); p.m_142416_(yes); p.m_142416_(no); p.m_142416_(cancel); }width, 45, message))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  83 */       .open();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Popup createYesNoPopup(@Nullable Screen screen, Runnable onAccepted, Runnable onNotAccepted, int width, Component message) {
/*  88 */     return (new Popup(screen, (p, r) -> { GridLayout layout = (new GridLayout()).m_267749_(10); GridLayout.RowHelper row = layout.m_264606_(2); Button yes = (Button)row.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.popup.yes"), ()).m_252780_(80).m_253136_()); Button no = (Button)row.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.popup.no"), ()).m_252780_(80).m_253136_()); layout.m_264036_(); FrameLayout.m_267781_((LayoutElement)layout, r); p.m_142416_(yes); p.m_142416_(no); }width, 20, message))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 103 */       .open();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Popup createYesNoPopup(@Nullable Screen screen, Runnable onAccepted, int width, Component message) {
/* 108 */     return createYesNoPopup(screen, onAccepted, () -> {  }width, message);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Popup createTextFieldPopup(@Nullable Screen screen, Consumer<String> onAccepted, int width, Component message, Predicate<String> filter) {
/* 113 */     Minecraft mc = Minecraft.m_91087_();
/* 114 */     return (new Popup(screen, (p, r) -> { GridLayout layout = new GridLayout(); layout.m_264211_().m_264356_().m_264623_().m_264174_(5); GridLayout.RowHelper row = layout.m_264606_(1); GridLayout textLayout = (GridLayout)row.m_264139_((LayoutElement)new GridLayout()); GridLayout.RowHelper textSubmit = textLayout.m_264606_(1); EditBox box = (EditBox)textSubmit.m_264139_((LayoutElement)new EditBox(mc.f_91062_, 0, 0, width / 2, 20, CommonComponents.f_237098_)); box.m_94153_(filter); GridLayout buttonLayout = (GridLayout)row.m_264139_((LayoutElement)new GridLayout()); buttonLayout.m_264211_().m_264215_(5); GridLayout.RowHelper buttonRow = buttonLayout.m_264606_(2); Button submit = (Button)buttonRow.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.popup.submit"), ()).m_252780_(80).m_253136_()); Button cancel = (Button)buttonRow.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.popup.cancel"), ()).m_252780_(80).m_253136_()); layout.m_264036_(); FrameLayout.m_267781_((LayoutElement)layout, r); p.m_142416_(box); p.m_142416_(submit); p.m_142416_(cancel); }width, 45, message))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 142 */       .open();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Popup createTextFieldPopup(@Nullable Screen screen, Consumer<String> onAccepted, int width, Component message) {
/* 147 */     return createTextFieldPopup(screen, onAccepted, width, message, str -> true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> Popup createOptionListPopup(@Nullable Screen screen, Consumer<SelectableNamedObjectList<T>> valueApplier, Consumer<T> onAccepted, int width, int listHeight, Component message) {
/* 152 */     Minecraft mc = Minecraft.m_91087_();
/* 153 */     return (new Popup(screen, (p, r) -> { GridLayout layout = new GridLayout(); layout.m_264211_().m_264356_().m_264623_().m_264174_(5); GridLayout.RowHelper row = layout.m_264606_(2); int listWidth = (int)(width / 1.2F); int listY = r.m_274449_(); SelectableNamedObjectList<T> list = new SelectableNamedObjectList(mc, listWidth, listHeight, listY, listY + listHeight); list.m_93507_(p.boxX() + p.boxWidth() / 2 - list.getWidth() / 2); valueApplier.accept(list); Button select = (Button)row.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.popup.select"), ()).m_252780_(80).m_253136_()); select.f_93623_ = false; list.setOnObjectSelectedCallback(()); Button cancel = (Button)row.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.popup.cancel"), ()).m_252780_(80).m_253136_()); layout.m_264036_(); FrameLayout.m_264159_((LayoutElement)layout, r.m_274563_(), list.getBottom() + 5, r.f_263770_(), 30); p.m_142416_(select); p.m_142416_(cancel); p.m_142416_(list); }width, listHeight + 30, message))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 181 */       .open();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Popup createInfoPopup(@Nullable Screen screen, int width, Component message) {
/* 186 */     return (new Popup(screen, (p, r) -> { int buttonWidth = 100; Button close = Button.m_253074_((Component)Component.m_237115_("gui.popup.close"), ()).m_252794_(p.boxX() + width / 2 - buttonWidth / 2, p.boxY() + p.boxHeight() - 30).m_252780_(buttonWidth).m_253136_(); p.m_142416_(close); }width, 20, message))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 192 */       .open();
/*     */   }
/*     */ 
/*     */   
/*     */   public int boxX() {
/* 197 */     return this.x;
/*     */   }
/*     */ 
/*     */   
/*     */   public int boxY() {
/* 202 */     return this.y;
/*     */   }
/*     */ 
/*     */   
/*     */   public int boxWidth() {
/* 207 */     return this.boxWidth;
/*     */   }
/*     */ 
/*     */   
/*     */   public int boxHeight() {
/* 212 */     return this.boxHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void m_7856_() {
/* 218 */     this.boxHeight = 40 + messageHeight() + this.widgetsHeight;
/* 219 */     this.x = this.f_96543_ / 2 - this.boxWidth / 2;
/* 220 */     this.y = this.f_96544_ / 2 - this.boxHeight / 2;
/* 221 */     ScreenRectangle widgetsRectangle = new ScreenRectangle(this.x, messageTop() + messageHeight() + 10, this.boxWidth, this.widgetsHeight);
/* 222 */     this.onInitialized.init(this, widgetsRectangle);
/* 223 */     if (this.previous != null) {
/* 224 */       this.previous.m_6575_(this.f_96541_, this.f_96543_, this.f_96544_);
/*     */     }
/*     */   }
/*     */   
/*     */   private int messageTop() {
/* 229 */     return this.y + 20;
/*     */   }
/*     */ 
/*     */   
/*     */   private int messageHeight() {
/* 234 */     Objects.requireNonNull(this.f_96547_); return this.text.m_5770_() * 9;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends GuiEventListener & net.minecraft.client.gui.components.Renderable & net.minecraft.client.gui.narration.NarratableEntry> T m_142416_(T pWidget) {
/* 240 */     return (T)super.m_142416_((GuiEventListener)pWidget);
/*     */   }
/*     */ 
/*     */   
/*     */   private void close() {
/* 245 */     if (!POPUP_QUEUE.isEmpty()) {
/* 246 */       this.f_96541_.m_91152_(POPUP_QUEUE.poll());
/* 247 */     } else if (this.previous != null) {
/* 248 */       this.f_96541_.m_91152_(this.previous);
/*     */     } else {
/* 250 */       this.f_96541_.popGuiLayer();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Popup open() {
/* 255 */     Minecraft mc = Minecraft.m_91087_();
/* 256 */     if (mc.f_91080_ instanceof Popup) {
/* 257 */       POPUP_QUEUE.add(this);
/*     */     } else {
/* 259 */       mc.m_91152_(this);
/* 260 */     }  return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_86600_() {
/* 266 */     if (this.previous != null) {
/* 267 */       this.previous.m_86600_();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void m_88315_(GuiGraphics stack, int mouseX, int mouseY, float partialTicks) {
/* 273 */     if (this.previous != null)
/* 274 */       this.previous.m_88315_(stack, mouseX, mouseY, partialTicks); 
/* 275 */     RenderSystem.clear(256, Minecraft.f_91002_);
/* 276 */     stack.m_280024_(0, 0, this.f_96543_, this.f_96544_, -1072689136, -804253680);
/* 277 */     stack.m_280509_(this.x, this.y, this.x + this.boxWidth, this.y + this.boxHeight, 1426063360);
/* 278 */     Objects.requireNonNull(this.f_96547_); this.text.m_6514_(stack, this.x + this.boxWidth / 2, messageTop(), 9, -1);
/* 279 */     super.m_88315_(stack, mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_7379_() {
/* 285 */     close();
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface Initializer {
/*     */     void init(Popup param1Popup, ScreenRectangle param1ScreenRectangle);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\Popup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */