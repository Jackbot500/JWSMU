/*    */ package nonamecrackers2.crackerslib.client.gui.title;public final class ImageTitle extends Record implements TitleLogo { private final ResourceLocation location;
/*    */   private final int imageWidth;
/*    */   private final int imageHeight;
/*    */   private final int width;
/*    */   private final int height;
/*    */   
/*  7 */   public ImageTitle(ResourceLocation location, int imageWidth, int imageHeight, int width, int height) { this.location = location; this.imageWidth = imageWidth; this.imageHeight = imageHeight; this.width = width; this.height = height; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lnonamecrackers2/crackerslib/client/gui/title/ImageTitle;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #7	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*  7 */     //   0	7	0	this	Lnonamecrackers2/crackerslib/client/gui/title/ImageTitle; } public ResourceLocation location() { return this.location; } public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lnonamecrackers2/crackerslib/client/gui/title/ImageTitle;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #7	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnonamecrackers2/crackerslib/client/gui/title/ImageTitle; } public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lnonamecrackers2/crackerslib/client/gui/title/ImageTitle;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #7	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lnonamecrackers2/crackerslib/client/gui/title/ImageTitle;
/*  7 */     //   0	8	1	o	Ljava/lang/Object; } public int imageWidth() { return this.imageWidth; } public int imageHeight() { return this.imageHeight; } public int width() { return this.width; } public int height() { return this.height; }
/*    */ 
/*    */   
/*    */   public static ImageTitle ofMod(String modid, int imageWidth, int imageHeight, int width, int height) {
/* 11 */     ResourceLocation location = new ResourceLocation(modid, "textures/gui/config/title/title.png");
/* 12 */     return new ImageTitle(location, imageWidth, imageHeight, width, height);
/*    */   }
/*    */ 
/*    */   
/*    */   public static ImageTitle ofMod(String modid, int imageWidth, int imageHeight, float scale) {
/* 17 */     int width = Mth.m_14143_(imageWidth * scale);
/* 18 */     int height = Mth.m_14143_(imageHeight * scale);
/* 19 */     return ofMod(modid, width, height, width, height);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void blit(GuiGraphics stack, int x, int y, float partialTicks) {
/* 25 */     stack.m_280411_(this.location, x, y, this.width, this.height, 0.0F, 0.0F, this.width, this.height, this.imageWidth, this.imageHeight);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getWidth() {
/* 31 */     return this.width;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getHeight() {
/* 37 */     return this.height;
/*    */   } }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\title\ImageTitle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */