/*    */ package nonamecrackers2.crackerslib.client.gui.widget.config.entry;
/*    */ 
/*    */ import com.google.common.base.Joiner;
/*    */ import com.google.common.base.Splitter;
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.List;
/*    */ import net.minecraft.ChatFormatting;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.components.AbstractWidget;
/*    */ import net.minecraft.client.gui.components.EditBox;
/*    */ import net.minecraft.network.chat.CommonComponents;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ 
/*    */ public class ListConfigEntry
/*    */   extends ConfigEntry<List<?>, EditBox>
/*    */ {
/*    */   protected static final String PATH_SPLITTER = ", ";
/* 20 */   protected static final Joiner JOINER = Joiner.on(", ");
/* 21 */   protected static final Splitter SPLITTER = Splitter.on(", ");
/*    */   
/*    */   private final ValueParser<?> parser;
/*    */   
/*    */   public ListConfigEntry(Minecraft mc, String modid, ModConfig.Type type, String path, ForgeConfigSpec spec, Runnable onValueUpdated, ValueParser<?> parser) {
/* 26 */     super(mc, modid, type, path, spec, onValueUpdated);
/* 27 */     this.parser = parser;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected EditBox buildWidget(int x, int y, int width, int height) {
/* 33 */     EditBox box = new EditBox(this.mc.f_91062_, x + 6, y + height / 2 - 10, 200, 20, CommonComponents.f_237098_);
/* 34 */     if (((List)this.value.getDefault()).size() > 0)
/* 35 */       box.m_257771_((Component)Component.m_237113_(String.valueOf(((List)this.value.getDefault()).get(0))).m_130940_(ChatFormatting.DARK_GRAY)); 
/* 36 */     box.m_94199_(500);
/* 37 */     box.m_94144_(compileListToString((List)this.value.get()));
/* 38 */     box.m_94151_(value -> {
/*    */           try {
/*    */             getValueUpdatedResponder().run();
/*    */             
/*    */             List<?> val = compileValuesFromString(value);
/*    */             if (this.valueSpec.test(val)) {
/*    */               this.widget.m_94202_(-1);
/*    */             } else {
/*    */               this.widget.m_94202_(ChatFormatting.RED.m_126665_().intValue());
/*    */             } 
/* 48 */           } catch (NumberFormatException e) {
/*    */             this.widget.m_94202_(ChatFormatting.RED.m_126665_().intValue());
/*    */           } 
/*    */         });
/*    */     
/* 53 */     return box;
/*    */   }
/*    */ 
/*    */   
/*    */   protected String compileListToString(List<?> values) {
/* 58 */     return JOINER.join(values);
/*    */   }
/*    */ 
/*    */   
/*    */   protected List<?> compileValuesFromString(String values) throws NumberFormatException {
/* 63 */     List<Object> valuesList = Lists.newArrayList();
/* 64 */     for (String val : SPLITTER.split(values))
/* 65 */       valuesList.add(this.parser.parse(val)); 
/* 66 */     return valuesList;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected List<?> getCurrentValue() {
/*    */     try {
/* 73 */       return compileValuesFromString(this.widget.m_94155_());
/* 74 */     } catch (NumberFormatException e) {
/* 75 */       return (List)this.value.get();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setCurrentValue(List<?> value) {
/* 82 */     this.widget.m_94144_(compileListToString(value));
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface ValueParser<T> {
/*    */     T parse(String param1String) throws NumberFormatException;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\entry\ListConfigEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */