/*    */ package nonamecrackers2.crackerslib.client.gui.widget.config.entry;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.components.AbstractWidget;
/*    */ import net.minecraft.client.gui.components.EditBox;
/*    */ import net.minecraft.network.chat.CommonComponents;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ 
/*    */ public class StringConfigEntry
/*    */   extends ConfigEntry<String, EditBox> {
/*    */   public StringConfigEntry(Minecraft mc, String modid, ModConfig.Type type, String path, ForgeConfigSpec spec, Runnable onValueUpdated) {
/* 13 */     super(mc, modid, type, path, spec, onValueUpdated);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected EditBox buildWidget(int x, int y, int width, int height) {
/* 19 */     EditBox box = new EditBox(this.mc.f_91062_, x + 6, y + height / 2 - 10, 60, 20, CommonComponents.f_237098_);
/* 20 */     box.m_94144_((String)this.value.get());
/* 21 */     box.m_94151_(value -> getValueUpdatedResponder().run());
/*    */ 
/*    */     
/* 24 */     return box;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getCurrentValue() {
/* 30 */     return this.widget.m_94155_();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setCurrentValue(String value) {
/* 36 */     this.widget.m_94144_(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\entry\StringConfigEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */