/*     */ package nonamecrackers2.crackerslib.client.gui.widget.config;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.Tooltip;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ import net.minecraft.network.chat.Style;
/*     */ import nonamecrackers2.crackerslib.client.util.SortType;
/*     */ import nonamecrackers2.crackerslib.common.config.preset.ConfigPreset;
/*     */ 
/*     */ public class ConfigCategory
/*     */   implements ConfigListItem {
/*     */   private final Minecraft mc;
/*  22 */   private final List<ConfigListItem> children = Lists.newArrayList();
/*  23 */   private final List<ConfigCategory> categories = Lists.newArrayList();
/*     */   private final String path;
/*     */   private final ConfigOptionList list;
/*     */   private final String modid;
/*     */   private final Component name;
/*     */   private Component displayName;
/*     */   private Button expand;
/*     */   private boolean isExpanded;
/*     */   private int x;
/*  32 */   private SortType sortType = SortType.A_TO_Z;
/*     */ 
/*     */   
/*     */   public ConfigCategory(Minecraft mc, String modid, String path, ConfigOptionList list) {
/*  36 */     this.mc = mc;
/*  37 */     this.modid = modid;
/*  38 */     this.path = path;
/*  39 */     this.list = list;
/*  40 */     this.name = (Component)Component.m_237115_("gui." + this.modid + ".config.category." + ConfigListItem.extractNameFromPath(path) + ".title").m_130948_(Style.f_131099_.m_131136_(Boolean.valueOf(true)).m_131140_(ChatFormatting.YELLOW));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSorting(SortType sorting) {
/*  45 */     this.sortType = sorting;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addChild(ConfigListItem item) {
/*  50 */     if (!this.children.contains(item)) {
/*  51 */       this.children.add(item);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(List<AbstractWidget> widgets, int x, int y, int width, int height) {
/*     */     MutableComponent mutableComponent;
/*  58 */     if (this.isExpanded) {
/*  59 */       mutableComponent = Component.m_237113_("-").m_130940_(ChatFormatting.RED);
/*     */     } else {
/*  61 */       mutableComponent = Component.m_237113_("+").m_130940_(ChatFormatting.GREEN);
/*  62 */     }  this
/*     */ 
/*     */ 
/*     */       
/*  66 */       .expand = Button.m_253074_((Component)mutableComponent, b -> { this.isExpanded = !this.isExpanded; this.list.rebuildList(); }).m_252987_(x + 6, y, 20, 20).m_253136_();
/*  67 */     widgets.add(this.expand);
/*     */     
/*  69 */     if (!this.isExpanded)
/*  70 */       this.children.forEach(child -> child.init(Lists.newArrayList(), x + 20, y, width, height)); 
/*  71 */     this.x = x;
/*     */     
/*  73 */     this.displayName = ConfigListItem.shortenText(this.name, width - this.expand.m_5711_() - x - 5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics stack, int x, int y, int width, int height, int mouseX, int mouseY, float partialTicks) {
/*  79 */     this.expand.m_253211_(y + height / 2 - this.expand.m_93694_() / 2);
/*  80 */     this.expand.m_88315_(stack, mouseX, mouseY, partialTicks);
/*  81 */     Objects.requireNonNull(this.mc.f_91062_); stack.m_280430_(this.mc.f_91062_, this.displayName, x + 5 + this.expand.m_252754_() - x + this.expand.m_5711_(), y + height / 2 - 9 / 2, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onSavedAndClosed() {
/*  87 */     this.children.forEach(child -> child.onSavedAndClosed());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetValue() {
/*  93 */     this.children.forEach(child -> child.resetValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueReset() {
/*  99 */     return this.children.stream().allMatch(ConfigListItem::isValueReset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesPreset(ConfigPreset preset, Predicate<String> excluded) {
/* 105 */     return this.children.stream().allMatch(child -> child.matchesPreset(preset, excluded));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFromPreset(ConfigPreset preset, Predicate<String> excluded) {
/* 111 */     this.children.forEach(child -> child.setFromPreset(preset, excluded));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Tooltip getTooltip(ConfigPreset preset) {
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPath() {
/* 122 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isExpanded() {
/* 127 */     return this.isExpanded;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExpanded(boolean flag) {
/* 132 */     this.isExpanded = flag;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ConfigListItem> gatherChildren(String search, boolean expandOrContractCategories) {
/* 137 */     this.sortType.sortList(this.children);
/* 138 */     List<ConfigListItem> items = Lists.newArrayList();
/* 139 */     for (ConfigListItem item : this.children) {
/*     */       
/* 141 */       if (search.isEmpty() || item.matchesSearch(search)) {
/*     */         
/* 143 */         items.add(item);
/* 144 */         if (item instanceof ConfigCategory) { ConfigCategory category = (ConfigCategory)item; if (category.isExpanded())
/* 145 */             items.addAll(category.gatherChildren(search, expandOrContractCategories));  }
/*     */       
/*     */       } 
/* 148 */     }  return items;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ConfigListItem> getImmediateChildren() {
/* 153 */     return this.children;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getX() {
/* 158 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ConfigListItem item) {
/* 164 */     if (item instanceof ConfigCategory) { ConfigCategory category = (ConfigCategory)item;
/* 165 */       return this.path.compareTo(category.path); }
/*     */     
/* 167 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesSearch(String text) {
/* 173 */     return this.children.stream().anyMatch(c -> c.matchesSearch(text));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCategory(ConfigCategory category) {
/* 178 */     this.categories.add(category);
/* 179 */     this.children.add(category);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\ConfigCategory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */