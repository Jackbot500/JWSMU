/*    */ package nonamecrackers2.crackerslib.client.gui;
/*    */ 
/*    */ import com.google.common.collect.ImmutableMap;
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.gui.components.AbstractButton;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraftforge.fml.ModContainer;
/*    */ import net.minecraftforge.fml.ModLoader;
/*    */ import nonamecrackers2.crackerslib.client.event.impl.ConfigMenuButtonEvent;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigMenuButtons
/*    */ {
/*    */   @Nullable
/*    */   private static Map<String, Factory> factoriesByModId;
/* 23 */   private static final Logger LOGGER = LogManager.getLogger("crackerslib/ConfigPresets");
/*    */   
/*    */   @Nullable
/*    */   public static Factory getButtonFactory(String modid) {
/* 27 */     Objects.requireNonNull(factoriesByModId, "Button factories have not been registered yet!");
/* 28 */     return factoriesByModId.get(modid);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void gatherButtonFactories() {
/* 33 */     if (factoriesByModId != null)
/* 34 */       throw new IllegalStateException("Config menu button factories have already been gathered!"); 
/* 35 */     ImmutableMap.Builder<String, Factory> factories = ImmutableMap.builder();
/* 36 */     List<ConfigMenuButtonEvent> postedEvents = Lists.newArrayList();
/* 37 */     ModLoader.get().runEventGenerator(mod -> {
/*    */           ConfigMenuButtonEvent event = new ConfigMenuButtonEvent(mod.getModId());
/*    */           postedEvents.add(event);
/*    */           return event;
/*    */         });
/* 42 */     postedEvents.forEach(e -> {
/*    */           if (e.getFactory() != null)
/*    */             factories.put(e.getModId(), e.getFactory()); 
/*    */         });
/* 46 */     factoriesByModId = (Map<String, Factory>)factories.build();
/* 47 */     LOGGER.debug("Registered {} config menu buttons", Integer.valueOf(factoriesByModId.size()));
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface Factory {
/*    */     AbstractButton makeButton(Button.OnPress param1OnPress);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\ConfigMenuButtons.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */