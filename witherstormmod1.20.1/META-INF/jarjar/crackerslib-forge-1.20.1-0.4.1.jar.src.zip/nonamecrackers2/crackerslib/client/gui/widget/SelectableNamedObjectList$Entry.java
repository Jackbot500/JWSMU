/*     */ package nonamecrackers2.crackerslib.client.gui.widget;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.ObjectSelectionList;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Entry<T>
/*     */   extends ObjectSelectionList.Entry<SelectableNamedObjectList.Entry<T>>
/*     */ {
/*     */   private final SelectableNamedObjectList<T> list;
/*     */   private final Component text;
/*     */   private final T object;
/*     */   
/*     */   public Entry(SelectableNamedObjectList<T> list, Component text, T object) {
/*  77 */     this.list = list;
/*  78 */     this.text = text;
/*  79 */     this.object = object;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Component m_142172_() {
/*  85 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_6311_(GuiGraphics stack, int pIndex, int pTop, int pLeft, int pWidth, int pHeight, int pMouseX, int pMouseY, boolean pIsMouseOver, float pPartialTick) {
/*  91 */     Font font = (SelectableNamedObjectList.access$000(this.list)).f_91062_;
/*  92 */     Objects.requireNonNull(font); stack.m_280430_(font, this.text, pLeft + 2, pTop + pHeight / 2 - 9 / 2, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_6375_(double pMouseX, double pMouseY, int pButton) {
/*  98 */     if (pButton == 0) {
/*     */       
/* 100 */       this.list.setSelected(this);
/* 101 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 105 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\SelectableNamedObjectList$Entry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */