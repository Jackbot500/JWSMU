/*    */ package nonamecrackers2.crackerslib.client.gui.title;
/*    */ 
/*    */ 
/*    */ public final class TextTitle extends Record implements TitleLogo {
/*    */   private final Component title;
/*    */   private final int width;
/*    */   private final int height;
/*    */   
/*  9 */   public TextTitle(Component title, int width, int height) { this.title = title; this.width = width; this.height = height; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lnonamecrackers2/crackerslib/client/gui/title/TextTitle;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #9	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*  9 */     //   0	7	0	this	Lnonamecrackers2/crackerslib/client/gui/title/TextTitle; } public Component title() { return this.title; } public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lnonamecrackers2/crackerslib/client/gui/title/TextTitle;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #9	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lnonamecrackers2/crackerslib/client/gui/title/TextTitle; } public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lnonamecrackers2/crackerslib/client/gui/title/TextTitle;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #9	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lnonamecrackers2/crackerslib/client/gui/title/TextTitle;
/*  9 */     //   0	8	1	o	Ljava/lang/Object; } public int width() { return this.width; } public int height() { return this.height; }
/*    */ 
/*    */   
/*    */   public static TextTitle ofModDisplayName(String modid, Style style) {
/* 13 */     Minecraft mc = Minecraft.m_91087_();
/* 14 */     return (TextTitle)ModList.get().getModContainerById(modid).map(container -> {
/*    */           MutableComponent mutableComponent = Component.m_237113_(container.getModInfo().getDisplayName()).m_130948_(style); Objects.requireNonNull(mc.f_91062_);
/*    */           return new TextTitle((Component)mutableComponent, mc.f_91062_.m_92852_((FormattedText)mutableComponent), 9);
/* 17 */         }).orElseThrow(() -> new NullPointerException("Could not find mod with id '" + modid + "'"));
/*    */   }
/*    */ 
/*    */   
/*    */   public static TextTitle ofModDisplayName(String modid) {
/* 22 */     return ofModDisplayName(modid, Style.f_131099_.m_131136_(Boolean.valueOf(true)).m_131162_(Boolean.valueOf(true)));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void blit(GuiGraphics stack, int x, int y, float partialTicks) {
/* 28 */     Minecraft mc = Minecraft.m_91087_();
/* 29 */     stack.m_280430_(mc.f_91062_, this.title, x, y, -1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getWidth() {
/* 35 */     return this.width;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getHeight() {
/* 41 */     return this.height;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\title\TextTitle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */