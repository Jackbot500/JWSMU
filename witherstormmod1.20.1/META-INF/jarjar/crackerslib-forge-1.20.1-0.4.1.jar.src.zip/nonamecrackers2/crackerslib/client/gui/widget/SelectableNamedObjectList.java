/*     */ package nonamecrackers2.crackerslib.client.gui.widget;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*     */ import net.minecraft.client.gui.components.ObjectSelectionList;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ public class SelectableNamedObjectList<T>
/*     */   extends ObjectSelectionList<SelectableNamedObjectList.Entry<T>>
/*     */ {
/*     */   @Nullable
/*     */   private Consumer<T> onObjectSelected;
/*     */   
/*     */   public SelectableNamedObjectList(Minecraft pMinecraft, int pWidth, int pHeight, int pY0, int pY1) {
/*  20 */     super(pMinecraft, pWidth, pHeight, pY0, pY1, 9 + 5);
/*  21 */     m_93488_(false);
/*  22 */     m_93496_(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOnObjectSelectedCallback(Consumer<T> callback) {
/*  27 */     this.onObjectSelected = callback;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addObject(Component name, T object) {
/*  32 */     m_7085_((AbstractSelectionList.Entry)new Entry<>(this, name, object));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int m_5759_() {
/*  38 */     return getWidth();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public T getSelectedObject() {
/*  43 */     if (m_93511_() != null) {
/*  44 */       return ((Entry)m_93511_()).object;
/*     */     }
/*  46 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int m_5756_() {
/*  52 */     return getLeft() + getWidth() - 5;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void m_7733_(GuiGraphics stack) {
/*  58 */     stack.m_280509_(this.f_93393_, this.f_93390_, this.f_93392_, this.f_93391_, 1426063360);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelected(Entry<T> pSelected) {
/*  64 */     if (this.onObjectSelected != null && pSelected != null)
/*  65 */       this.onObjectSelected.accept(pSelected.object); 
/*  66 */     super.m_6987_((AbstractSelectionList.Entry)pSelected);
/*     */   }
/*     */   
/*     */   public static class Entry<T>
/*     */     extends ObjectSelectionList.Entry<Entry<T>>
/*     */   {
/*     */     private final SelectableNamedObjectList<T> list;
/*     */     private final Component text;
/*     */     private final T object;
/*     */     
/*     */     public Entry(SelectableNamedObjectList<T> list, Component text, T object) {
/*  77 */       this.list = list;
/*  78 */       this.text = text;
/*  79 */       this.object = object;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Component m_142172_() {
/*  85 */       return this.text;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void m_6311_(GuiGraphics stack, int pIndex, int pTop, int pLeft, int pWidth, int pHeight, int pMouseX, int pMouseY, boolean pIsMouseOver, float pPartialTick) {
/*  91 */       Font font = this.list.f_93386_.f_91062_;
/*  92 */       Objects.requireNonNull(font); stack.m_280430_(font, this.text, pLeft + 2, pTop + pHeight / 2 - 9 / 2, -1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean m_6375_(double pMouseX, double pMouseY, int pButton) {
/*  98 */       if (pButton == 0) {
/*     */         
/* 100 */         this.list.setSelected(this);
/* 101 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 105 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\SelectableNamedObjectList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */