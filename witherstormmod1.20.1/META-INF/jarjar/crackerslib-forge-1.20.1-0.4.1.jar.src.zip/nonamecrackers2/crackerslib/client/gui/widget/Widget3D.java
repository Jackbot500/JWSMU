/*    */ package nonamecrackers2.crackerslib.client.gui.widget;
/*    */ 
/*    */ import com.mojang.blaze3d.systems.RenderSystem;
/*    */ import com.mojang.blaze3d.vertex.BufferBuilder;
/*    */ import com.mojang.blaze3d.vertex.BufferUploader;
/*    */ import com.mojang.blaze3d.vertex.DefaultVertexFormat;
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import com.mojang.blaze3d.vertex.Tesselator;
/*    */ import com.mojang.blaze3d.vertex.VertexFormat;
/*    */ import java.util.Objects;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.gui.components.AbstractWidget;
/*    */ import net.minecraft.client.renderer.GameRenderer;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import nonamecrackers2.crackerslib.client.util.RenderUtil;
/*    */ import org.joml.Matrix4f;
/*    */ import org.joml.Vector2f;
/*    */ import org.joml.Vector3f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Widget3D
/*    */   extends AbstractWidget
/*    */ {
/*    */   @Nullable
/*    */   protected Matrix4f poseMatrix;
/*    */   protected Vector2f screenPos;
/*    */   protected Vector3f pos;
/*    */   
/*    */   public Widget3D(Vector3f pos, int screenX, int screenY, int width, int height, Component name) {
/* 33 */     super(screenX, screenY, width, height, name);
/* 34 */     this.pos = pos;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPos(Vector3f pos) {
/* 39 */     this.pos = pos;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePoseMatrix(Matrix4f poseMatrix) {
/* 44 */     this.poseMatrix = poseMatrix;
/*    */   }
/*    */ 
/*    */   
/*    */   protected final Vector2f convertPosToScreenCoord(Vector3f pos) {
/* 49 */     Objects.requireNonNull(this.poseMatrix, "Previous 3D pose matrix is null!");
/* 50 */     return RenderUtil.getScreenCoordinatesFromWorldPos(this.poseMatrix, pos);
/*    */   }
/*    */ 
/*    */   
/*    */   protected final Vector3f convertPosToScreenCordWithZDist(Vector3f pos) {
/* 55 */     Objects.requireNonNull(this.poseMatrix, "Previous 3D pose matrix is null!");
/* 56 */     return RenderUtil.getScreenCoordinatesFromWorldPosWithZDist(this.poseMatrix, pos);
/*    */   }
/*    */ 
/*    */   
/*    */   public void renderAs3D(PoseStack stack, MultiBufferSource buffers, int mouseX, int mouseY, float partialTick) {
/* 61 */     updatePoseMatrix(stack.m_85850_().m_252922_());
/* 62 */     this.screenPos = convertPosToScreenCoord(this.pos);
/* 63 */     updatePos();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePos() {
/* 68 */     m_252865_((int)this.screenPos.x);
/* 69 */     m_253211_((int)this.screenPos.y);
/*    */   }
/*    */ 
/*    */   
/*    */   protected static void blit(PoseStack stack, float x, float y, int blitOffset, float width, float height, float u1, float v1, float u2, float v2) {
/* 74 */     Matrix4f matrix4f = stack.m_85850_().m_252922_();
/* 75 */     RenderSystem.setShader(GameRenderer::m_172817_);
/* 76 */     BufferBuilder bufferbuilder = Tesselator.m_85913_().m_85915_();
/* 77 */     bufferbuilder.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85817_);
/* 78 */     bufferbuilder.m_252986_(matrix4f, x, y, blitOffset).m_7421_(u1, v1).m_5752_();
/* 79 */     bufferbuilder.m_252986_(matrix4f, x, y + height, blitOffset).m_7421_(u1, v2).m_5752_();
/* 80 */     bufferbuilder.m_252986_(matrix4f, x + width, y + height, blitOffset).m_7421_(u2, v2).m_5752_();
/* 81 */     bufferbuilder.m_252986_(matrix4f, x + width, y, blitOffset).m_7421_(u2, v1).m_5752_();
/* 82 */     BufferUploader.m_231202_(bufferbuilder.m_231175_());
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\Widget3D.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */