/*    */ package nonamecrackers2.crackerslib.client.gui.widget;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.client.gui.Font;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.AbstractButton;
/*    */ import net.minecraft.client.gui.components.Tooltip;
/*    */ import net.minecraft.client.gui.narration.NarrationElementOutput;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.network.chat.MutableComponent;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import nonamecrackers2.crackerslib.CrackersLib;
/*    */ import nonamecrackers2.crackerslib.client.util.SortType;
/*    */ 
/*    */ public class SortButton
/*    */   extends AbstractButton {
/* 17 */   private static final ResourceLocation SORT_ICONS = CrackersLib.id("textures/gui/config/sort.png");
/* 18 */   private static final Component NAME = (Component)Component.m_237115_("gui.crackerslib.button.sorting.title");
/*    */   private final Consumer<SortType> onPressed;
/* 20 */   private SortType type = SortType.A_TO_Z;
/*    */ 
/*    */   
/*    */   public SortButton(int x, int y, Consumer<SortType> onPressed) {
/* 24 */     super(x, y, 20, 20, NAME);
/* 25 */     this.onPressed = onPressed;
/* 26 */     m_257544_(buildTooltip());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_5691_() {
/* 32 */     int next = this.type.ordinal() + 1;
/* 33 */     if (next >= (SortType.values()).length)
/* 34 */       next = 0; 
/* 35 */     this.type = SortType.values()[next];
/* 36 */     this.onPressed.accept(this.type);
/* 37 */     m_257544_(buildTooltip());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_87963_(GuiGraphics stack, int mouseX, int mouseY, float partialTick) {
/* 43 */     super.m_87963_(stack, mouseX, mouseY, partialTick);
/* 44 */     float texY = 0.0F;
/* 45 */     if (this.type == SortType.Z_TO_A)
/* 46 */       texY = 20.0F; 
/* 47 */     stack.m_280411_(SORT_ICONS, m_252754_(), m_252907_(), m_5711_(), m_93694_(), 0.0F, texY, m_5711_(), m_93694_(), 256, 256);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_280139_(GuiGraphics stack, Font pFont, int pColor) {}
/*    */ 
/*    */   
/*    */   protected void m_168797_(NarrationElementOutput pNarrationElementOutput) {
/* 56 */     m_168802_(pNarrationElementOutput);
/*    */   }
/*    */ 
/*    */   
/*    */   public Tooltip buildTooltip() {
/* 61 */     MutableComponent mutableComponent = NAME.m_6881_().m_130946_(" ").m_7220_(this.type.getName());
/* 62 */     return Tooltip.m_257550_((Component)mutableComponent);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\SortButton.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */