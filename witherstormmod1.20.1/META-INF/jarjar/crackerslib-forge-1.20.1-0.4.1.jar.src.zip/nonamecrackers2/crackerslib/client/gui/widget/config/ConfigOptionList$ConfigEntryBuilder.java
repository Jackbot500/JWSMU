package nonamecrackers2.crackerslib.client.gui.widget.config;

import net.minecraft.client.Minecraft;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.config.ModConfig;
import nonamecrackers2.crackerslib.client.gui.widget.config.entry.ConfigEntry;

@FunctionalInterface
public interface ConfigEntryBuilder {
  ConfigEntry<?, ?> build(Minecraft paramMinecraft, String paramString1, ModConfig.Type paramType, String paramString2, ForgeConfigSpec paramForgeConfigSpec, Runnable paramRunnable);
}


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\ConfigOptionList$ConfigEntryBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */