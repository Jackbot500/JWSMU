/*    */ package nonamecrackers2.crackerslib.client.gui.widget.config.entry;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.components.AbstractWidget;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import nonamecrackers2.crackerslib.client.gui.widget.CyclableButton;
/*    */ 
/*    */ public class EnumConfigEntry<T extends Enum<T>>
/*    */   extends ConfigEntry<T, CyclableButton<T>>
/*    */ {
/*    */   private final Class<T> enumClass;
/*    */   
/*    */   public EnumConfigEntry(Minecraft mc, String modid, ModConfig.Type type, String path, ForgeConfigSpec spec, Runnable onValueUpdated) {
/* 16 */     super(mc, modid, type, path, spec, onValueUpdated);
/* 17 */     this.enumClass = ((Enum<T>)this.value.getDefault()).getDeclaringClass();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected CyclableButton<T> buildWidget(int x, int y, int width, int height) {
/* 23 */     CyclableButton<T> button = new CyclableButton(x + 6, y, 100, Arrays.asList((Enum[])this.enumClass.getEnumConstants()), this.value.get());
/* 24 */     button.setResponder(val -> getValueUpdatedResponder().run());
/* 25 */     return button;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected T getCurrentValue() {
/* 31 */     return (T)this.widget.getValue();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setCurrentValue(T value) {
/* 37 */     this.widget.setValue(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\entry\EnumConfigEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */