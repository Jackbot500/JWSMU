/*    */ package nonamecrackers2.crackerslib.client.gui.widget.config.entry;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import net.minecraft.ChatFormatting;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.components.AbstractWidget;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.network.chat.MutableComponent;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import nonamecrackers2.crackerslib.client.gui.widget.CyclableButton;
/*    */ 
/*    */ public class BooleanConfigEntry
/*    */   extends ConfigEntry<Boolean, CyclableButton<Boolean>> {
/*    */   public BooleanConfigEntry(Minecraft mc, String modid, ModConfig.Type type, String path, ForgeConfigSpec spec, Runnable onValueUpdated) {
/* 16 */     super(mc, modid, type, path, spec, onValueUpdated);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected CyclableButton<Boolean> buildWidget(int x, int y, int width, int height) {
/* 22 */     CyclableButton<Boolean> button = new CyclableButton(x + 6, y, 60, Lists.newArrayList((Object[])new Boolean[] { Boolean.FALSE, Boolean.TRUE }, ), this.value.get(), value -> {
/*    */           MutableComponent mutableComponent;
/*    */           if (value.booleanValue()) {
/*    */             mutableComponent = Component.m_237113_("ON").m_130940_(ChatFormatting.GREEN);
/*    */           } else {
/*    */             mutableComponent = Component.m_237113_("OFF").m_130940_(ChatFormatting.RED);
/*    */           } 
/*    */           return (Component)mutableComponent;
/*    */         });
/* 31 */     button.setResponder(val -> getValueUpdatedResponder().run());
/* 32 */     return button;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Boolean getCurrentValue() {
/* 38 */     return (Boolean)this.widget.getValue();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setCurrentValue(Boolean value) {
/* 44 */     this.widget.setValue(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\entry\BooleanConfigEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */