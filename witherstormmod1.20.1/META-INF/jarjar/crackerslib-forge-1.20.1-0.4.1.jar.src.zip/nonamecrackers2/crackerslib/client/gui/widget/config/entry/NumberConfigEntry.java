/*    */ package nonamecrackers2.crackerslib.client.gui.widget.config.entry;
/*    */ 
/*    */ import net.minecraft.ChatFormatting;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.components.AbstractWidget;
/*    */ import net.minecraft.client.gui.components.EditBox;
/*    */ import net.minecraft.network.chat.CommonComponents;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ 
/*    */ public abstract class NumberConfigEntry<T extends Number>
/*    */   extends ConfigEntry<T, EditBox> {
/*    */   public NumberConfigEntry(Minecraft mc, String modid, ModConfig.Type type, String path, ForgeConfigSpec spec, Runnable onValueUpdated) {
/* 14 */     super(mc, modid, type, path, spec, onValueUpdated);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected EditBox buildWidget(int x, int y, int width, int height) {
/* 20 */     EditBox box = new EditBox(this.mc.f_91062_, x + 6, y + height / 2 - 10, 60, 20, CommonComponents.f_237098_);
/* 21 */     box.m_94144_(String.valueOf(this.value.get()));
/* 22 */     box.m_94151_(value -> {
/*    */           try {
/*    */             getValueUpdatedResponder().run();
/*    */             
/*    */             T val = parseValue(value);
/*    */             if (this.valueSpec.test(val)) {
/*    */               this.widget.m_94202_(-1);
/*    */             } else {
/*    */               this.widget.m_94202_(ChatFormatting.RED.m_126665_().intValue());
/*    */             } 
/* 32 */           } catch (NumberFormatException e) {
/*    */             this.widget.m_94202_(ChatFormatting.RED.m_126665_().intValue());
/*    */           } 
/*    */         });
/*    */     
/* 37 */     return box;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected T getCurrentValue() {
/*    */     try {
/* 44 */       return parseValue(this.widget.m_94155_());
/* 45 */     } catch (NumberFormatException e) {
/* 46 */       return (T)this.value.get();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setCurrentValue(T value) {
/* 53 */     this.widget.m_94144_(String.valueOf(value));
/*    */   }
/*    */   
/*    */   protected abstract T parseValue(String paramString) throws NumberFormatException;
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\entry\NumberConfigEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */