/*     */ package nonamecrackers2.crackerslib.client.gui;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.Lighting;
/*     */ import com.mojang.blaze3d.platform.Window;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import com.mojang.blaze3d.vertex.VertexSorting;
/*     */ import com.mojang.math.Axis;
/*     */ import java.util.function.Supplier;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Renderable;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.renderer.MultiBufferSource;
/*     */ import net.minecraft.client.renderer.RenderType;
/*     */ import net.minecraft.client.renderer.texture.OverlayTexture;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.util.Mth;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.Widget3D;
/*     */ import org.joml.Matrix3f;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Quaternionf;
/*     */ import org.joml.Quaternionfc;
/*     */ import org.joml.Vector3f;
/*     */ import org.joml.Vector3fc;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Screen3D
/*     */   extends Screen
/*     */ {
/*     */   protected final float farPlane;
/*     */   protected final float zoomConstant;
/*  37 */   protected float camRotX = 225.0F;
/*  38 */   protected float camRotY = 45.0F;
/*  39 */   protected float zoom = 1.0F;
/*  40 */   protected Vector3f offset = new Vector3f(0.0F, 0.0F, 0.0F);
/*     */   
/*     */   @Nullable
/*     */   protected Matrix4f poseMatrix;
/*     */   
/*     */   @Nullable
/*     */   protected Vector3f hitPos;
/*     */   
/*     */   @Nullable
/*     */   protected Vector3f lastDragPos;
/*     */   protected boolean renderOrigin;
/*     */   protected int moveForTime;
/*     */   
/*     */   protected Screen3D(Component title, float zoomConstant, float farPlane) {
/*  54 */     super(title);
/*  55 */     this.farPlane = farPlane;
/*  56 */     this.zoomConstant = zoomConstant;
/*     */   } protected float moveFor; @Nullable
/*     */   protected Vector3f moveFrom; @Nullable
/*     */   protected Supplier<Vector3f> moveTo; protected float initialZoom; protected float finalZoom;
/*     */   protected void renderOrigin(boolean flag) {
/*  61 */     this.renderOrigin = flag;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_7979_(double pMouseX, double pMouseY, int pButton, double pDragX, double pDragY) {
/*  67 */     if (!super.m_7979_(pMouseX, pMouseY, pButton, pDragX, pDragY)) {
/*     */       
/*  69 */       if (pButton == 1) {
/*     */         
/*  71 */         if (canRotate())
/*     */         {
/*  73 */           this.camRotX = Mth.m_14036_(this.camRotX + (float)pDragY, 90.0F, 270.0F);
/*  74 */           this.camRotY = (float)Mth.m_14175_(this.camRotY + pDragX);
/*  75 */           onRotate();
/*     */         }
/*     */       
/*  78 */       } else if (pButton == 0) {
/*     */         
/*  80 */         if (canMove()) {
/*     */           
/*  82 */           Vector3f move = new Vector3f((float)-pDragX / this.zoom * this.zoomConstant, (float)pDragY / this.zoom * this.zoomConstant, 0.0F);
/*  83 */           move.rotate((Quaternionfc)Axis.f_252529_.m_252977_(this.camRotX));
/*  84 */           move.rotate((Quaternionfc)Axis.f_252392_.m_252977_(this.camRotY));
/*  85 */           this.offset.add((Vector3fc)move);
/*  86 */           onMove();
/*     */         } 
/*     */       } 
/*  89 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_6050_(double pMouseX, double pMouseY, double pDelta) {
/* 100 */     if (!super.m_6050_(pMouseX, pMouseY, pDelta)) {
/*     */       
/* 102 */       if (canZoom()) {
/*     */         
/* 104 */         this.zoom = Math.max(this.zoom + (float)pDelta * this.zoom / 10.0F, 1.0F);
/* 105 */         onZoom();
/*     */       } 
/* 107 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 111 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_88315_(GuiGraphics stack, int pMouseX, int pMouseY, float pPartialTick) {
/* 118 */     if (this.moveFor > 0.0F) {
/*     */       
/* 120 */       this.moveFor -= pPartialTick * Math.max(this.moveFor / this.moveForTime, 1.0E-4F);
/* 121 */       if (this.moveForTime > 0 && this.moveTo != null && this.moveFrom != null) {
/*     */         
/* 123 */         Vector3f finalPos = this.moveTo.get();
/* 124 */         if (finalPos != null) {
/*     */           
/* 126 */           float transition = this.moveFor / this.moveForTime;
/* 127 */           float x = Mth.m_14179_(transition, finalPos.x, this.moveFrom.x);
/* 128 */           float y = Mth.m_14179_(transition, finalPos.y, this.moveFrom.y);
/* 129 */           float z = Mth.m_14179_(transition, finalPos.z, this.moveFrom.z);
/* 130 */           this.offset = new Vector3f(x, y, z);
/* 131 */           this.zoom = Mth.m_14179_(transition, this.finalZoom, this.initialZoom);
/*     */         } 
/*     */       } 
/* 134 */       if (this.moveFor <= 0.0F)
/*     */       {
/* 136 */         this.moveFrom = null;
/* 137 */         this.moveForTime = 0;
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 142 */     else if (this.moveTo != null) {
/* 143 */       this.offset = this.moveTo.get();
/*     */     } 
/*     */     
/* 146 */     Quaternionf rot = (new Quaternionf()).rotateX(this.camRotX * 0.017453292F).rotateY(3.1415927F + this.camRotY * 0.017453292F);
/*     */     
/* 148 */     Matrix4f prevProjMat = RenderSystem.getProjectionMatrix();
/* 149 */     Window window = this.f_96541_.m_91268_();
/* 150 */     Matrix4f matrix4f = (new Matrix4f()).setOrtho(0.0F, (float)(window.m_85441_() / window.m_85449_()), (float)(window.m_85442_() / window.m_85449_()), 0.0F, 0.0F, this.farPlane);
/* 151 */     RenderSystem.setProjectionMatrix(matrix4f, VertexSorting.f_276633_);
/* 152 */     PoseStack modelViewStack = RenderSystem.getModelViewStack();
/* 153 */     modelViewStack.m_85836_();
/* 154 */     modelViewStack.m_166856_();
/* 155 */     RenderSystem.applyModelViewMatrix();
/*     */     
/* 157 */     stack.m_280168_().m_85836_();
/* 158 */     stack.m_280168_().m_85837_((this.f_96543_ / 2), (this.f_96544_ / 2), 0.0D);
/* 159 */     stack.m_280168_().m_252931_((new Matrix4f()).scaling(this.zoom * this.zoomConstant, this.zoom * this.zoomConstant, -1.0F));
/* 160 */     stack.m_280168_().m_85837_(0.0D, 0.0D, (this.farPlane / 2.0F));
/* 161 */     stack.m_280168_().m_252781_(rot);
/* 162 */     stack.m_280168_().m_252880_(this.offset.x, this.offset.y, this.offset.z);
/*     */     
/* 164 */     Lighting.m_166384_();
/*     */     
/* 166 */     MultiBufferSource.BufferSource bufferSource = this.f_96541_.m_91269_().m_110104_();
/*     */     
/* 168 */     if (this.renderOrigin) {
/*     */       
/* 170 */       VertexConsumer consumer = bufferSource.m_6299_(RenderType.m_110504_());
/* 171 */       Matrix4f pose = stack.m_280168_().m_85850_().m_252922_();
/* 172 */       Matrix3f normal = stack.m_280168_().m_85850_().m_252943_();
/* 173 */       consumer.m_252986_(pose, 0.0F, 0.0F, 0.0F).m_85950_(0.0F, 1.0F, 0.0F, 1.0F).m_252939_(normal, 0.0F, 1.0F, 0.0F).m_5752_();
/* 174 */       consumer.m_252986_(pose, 0.0F, 1.0F, 0.0F).m_85950_(0.0F, 1.0F, 0.0F, 1.0F).m_252939_(normal, 0.0F, 1.0F, 0.0F).m_5752_();
/*     */       
/* 176 */       consumer.m_252986_(pose, 0.0F, 0.0F, 0.0F).m_85950_(1.0F, 0.0F, 0.0F, 1.0F).m_252939_(normal, 1.0F, 0.0F, 0.0F).m_5752_();
/* 177 */       consumer.m_252986_(pose, 1.0F, 0.0F, 0.0F).m_85950_(1.0F, 0.0F, 0.0F, 1.0F).m_252939_(normal, 1.0F, 0.0F, 0.0F).m_5752_();
/*     */       
/* 179 */       consumer.m_252986_(pose, 0.0F, 0.0F, 0.0F).m_85950_(0.0F, 0.0F, 1.0F, 1.0F).m_252939_(normal, 0.0F, 0.0F, 1.0F).m_5752_();
/* 180 */       consumer.m_252986_(pose, 0.0F, 0.0F, 1.0F).m_85950_(0.0F, 0.0F, 1.0F, 1.0F).m_252939_(normal, 0.0F, 0.0F, 1.0F).m_5752_();
/*     */     } 
/*     */     
/* 183 */     this.poseMatrix = stack.m_280168_().m_85850_().m_252922_();
/* 184 */     render3D(stack.m_280168_(), (MultiBufferSource)bufferSource, pMouseX, pMouseY, this.f_96541_.getPartialTick());
/*     */     
/* 186 */     bufferSource.m_109911_();
/*     */     
/* 188 */     for (Renderable renderable : this.f_169369_) {
/*     */       
/* 190 */       if (renderable instanceof Widget3D) { Widget3D widget = (Widget3D)renderable;
/* 191 */         widget.renderAs3D(stack.m_280168_(), (MultiBufferSource)bufferSource, pMouseX, pMouseY, this.f_96541_.getPartialTick()); }
/*     */     
/*     */     } 
/* 194 */     RenderSystem.clear(256, Minecraft.f_91002_);
/* 195 */     bufferSource.m_109911_();
/*     */     
/* 197 */     stack.m_280168_().m_85849_();
/*     */     
/* 199 */     RenderSystem.clear(256, Minecraft.f_91002_);
/*     */     
/* 201 */     RenderSystem.setProjectionMatrix(prevProjMat, VertexSorting.f_276633_);
/* 202 */     modelViewStack.m_85849_();
/* 203 */     RenderSystem.applyModelViewMatrix();
/*     */     
/* 205 */     super.m_88315_(stack, pMouseX, pMouseY, pPartialTick);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void render3D(PoseStack stack, MultiBufferSource buffers, int mouseX, int mouseY, float partialTick) {}
/*     */   
/*     */   protected boolean canZoom() {
/* 212 */     return (this.moveFor <= 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean canMove() {
/* 217 */     return (this.moveFor <= 0.0F);
/*     */   }
/*     */   protected boolean canRotate() {
/* 220 */     return true;
/*     */   }
/*     */   
/*     */   protected void onZoom() {}
/*     */   
/*     */   protected void onMove() {
/* 226 */     this.moveTo = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onRotate() {}
/*     */   
/*     */   protected void lerpTo(int time, Supplier<Vector3f> pos, float zoom) {
/* 233 */     this.moveFor = time;
/* 234 */     this.moveForTime = time;
/* 235 */     this.moveTo = pos;
/* 236 */     this.moveFrom = this.offset;
/* 237 */     this.initialZoom = this.zoom;
/* 238 */     this.finalZoom = zoom;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderIcon(PoseStack stack, Vector3f pos, MultiBufferSource buffer, ResourceLocation tex, float camRotX, float camRotY, float zoom, float size, float r, float g, float b) {
/* 243 */     stack.m_85836_();
/* 244 */     stack.m_252880_(pos.x, pos.y, pos.z);
/* 245 */     stack.m_85841_(1.0F / zoom, 1.0F / zoom, 1.0F / zoom);
/* 246 */     stack.m_252781_(Axis.f_252392_.m_252977_(camRotY));
/* 247 */     stack.m_252781_(Axis.f_252529_.m_252977_(camRotX));
/* 248 */     stack.m_85841_(1.0F, -1.0F, 1.0F);
/* 249 */     stack.m_85837_(0.0D, 0.0D, 10.0D);
/* 250 */     Matrix4f pose = stack.m_85850_().m_252922_();
/* 251 */     Matrix3f normal = stack.m_85850_().m_252943_();
/* 252 */     VertexConsumer consumer = buffer.m_6299_(RenderType.m_110452_(tex));
/* 253 */     consumer.m_252986_(pose, size, -size, size).m_85950_(r, g, b, 1.0F).m_7421_(0.0F, 1.0F).m_86008_(OverlayTexture.f_118083_).m_85969_(15728880).m_252939_(normal, 0.0F, 1.0F, 0.0F).m_5752_();
/* 254 */     consumer.m_252986_(pose, -size, -size, size).m_85950_(r, g, b, 1.0F).m_7421_(1.0F, 1.0F).m_86008_(OverlayTexture.f_118083_).m_85969_(15728880).m_252939_(normal, 0.0F, 1.0F, 0.0F).m_5752_();
/* 255 */     consumer.m_252986_(pose, -size, size, size).m_85950_(r, g, b, 1.0F).m_7421_(1.0F, 0.0F).m_86008_(OverlayTexture.f_118083_).m_85969_(15728880).m_252939_(normal, 0.0F, 1.0F, 0.0F).m_5752_();
/* 256 */     consumer.m_252986_(pose, size, size, size).m_85950_(r, g, b, 1.0F).m_7421_(0.0F, 0.0F).m_86008_(OverlayTexture.f_118083_).m_85969_(15728880).m_252939_(normal, 0.0F, 1.0F, 0.0F).m_5752_();
/* 257 */     stack.m_85849_();
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\Screen3D.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */