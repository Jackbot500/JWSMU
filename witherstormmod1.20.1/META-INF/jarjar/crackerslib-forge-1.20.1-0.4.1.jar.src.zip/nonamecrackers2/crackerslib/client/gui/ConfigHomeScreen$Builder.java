/*     */ package nonamecrackers2.crackerslib.client.gui;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.gui.components.AbstractButton;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.Tooltip;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.Style;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ import net.minecraftforge.fml.config.ModConfig;
/*     */ import nonamecrackers2.crackerslib.client.config.ConfigHomeScreenFactory;
/*     */ import nonamecrackers2.crackerslib.client.gui.title.TitleLogo;
/*     */ import nonamecrackers2.crackerslib.client.util.GUIUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Builder
/*     */ {
/* 198 */   private final List<Supplier<AbstractButton>> extraButtons = Lists.newArrayList();
/*     */   private final TitleLogo title;
/* 200 */   private int totalColumns = 2;
/*     */ 
/*     */   
/*     */   private Builder(TitleLogo title) {
/* 204 */     this.title = title;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder totalColumns(int columns) {
/* 209 */     this.totalColumns = columns;
/* 210 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder addExtraButton(Supplier<AbstractButton> supplier) {
/* 215 */     this.extraButtons.add(supplier);
/* 216 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder addLinkButton(Component title, String link, @Nullable Tooltip tooltip) {
/* 221 */     return addExtraButton(() -> Button.m_253074_(title, ()).m_253046_(200, 20).m_257505_(tooltip).m_253136_());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder addLinkButton(Component title, String link) {
/* 232 */     return addLinkButton(title, link, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder standardLinks(@Nullable String discordLink, @Nullable String patreonLink, @Nullable String githubLink) {
/* 237 */     if (discordLink != null)
/* 238 */       addLinkButton((Component)Component.m_237115_("gui.crackerslib.screen.config.discord").m_130948_(Style.f_131099_.m_178520_(-10983950)), discordLink, Tooltip.m_257550_((Component)Component.m_237115_("gui.crackerslib.screen.config.discord.info"))); 
/* 239 */     if (githubLink != null)
/* 240 */       addLinkButton((Component)Component.m_237115_("gui.crackerslib.screen.config.github").m_130948_(Style.f_131099_.m_178520_(-5526613)), githubLink, Tooltip.m_257550_((Component)Component.m_237115_("gui.crackerslib.screen.config.github.info"))); 
/* 241 */     if (patreonLink != null)
/* 242 */       addLinkButton((Component)Component.m_237115_("gui.crackerslib.screen.config.patreon").m_130940_(ChatFormatting.RED), patreonLink, Tooltip.m_257550_((Component)Component.m_237115_("gui.crackerslib.screen.config.patreon.info"))); 
/* 243 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder crackersDefault(@Nullable String github) {
/* 248 */     return standardLinks("https://discord.com/invite/cracker-s-modded-community-987817685293355028", "https://www.patreon.com/nonamecrackers2", github);
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder crackersDefault() {
/* 253 */     return crackersDefault(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigHomeScreenFactory build() {
/* 258 */     return build(ConfigHomeScreen::new);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigHomeScreenFactory build(CustomHomeScreen constructor) {
/* 263 */     return (modid, specs, isWorldLoaded, hasSinglePlayerServer, previous) -> constructor.build(modid, specs, this.title, isWorldLoaded, hasSinglePlayerServer, previous, this.extraButtons, this.totalColumns);
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface CustomHomeScreen {
/*     */     ConfigHomeScreen build(String param2String, Map<ModConfig.Type, ForgeConfigSpec> param2Map, TitleLogo param2TitleLogo, boolean param2Boolean1, boolean param2Boolean2, @Nullable Screen param2Screen, List<Supplier<AbstractButton>> param2List, int param2Int);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\ConfigHomeScreen$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */