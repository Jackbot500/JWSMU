/*    */ package nonamecrackers2.crackerslib.client.gui.widget.config;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.AbstractWidget;
/*    */ import net.minecraft.client.gui.components.Tooltip;
/*    */ import net.minecraft.network.chat.CommonComponents;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.network.chat.FormattedText;
/*    */ import nonamecrackers2.crackerslib.common.config.preset.ConfigPreset;
/*    */ 
/*    */ 
/*    */ public interface ConfigListItem
/*    */   extends Comparable<ConfigListItem>
/*    */ {
/*    */   void init(List<AbstractWidget> paramList, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*    */   
/*    */   void render(GuiGraphics paramGuiGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat);
/*    */   
/*    */   void onSavedAndClosed();
/*    */   
/*    */   void resetValue();
/*    */   
/*    */   boolean isValueReset();
/*    */   
/*    */   boolean matchesPreset(ConfigPreset paramConfigPreset, Predicate<String> paramPredicate);
/*    */   
/*    */   void setFromPreset(ConfigPreset paramConfigPreset, Predicate<String> paramPredicate);
/*    */   
/*    */   @Nullable
/*    */   Tooltip getTooltip(@Nullable ConfigPreset paramConfigPreset);
/*    */   
/*    */   boolean matchesSearch(String paramString);
/*    */   
/*    */   static Component shortenText(Component name, int allowedWidth) {
/* 39 */     Minecraft mc = Minecraft.m_91087_();
/* 40 */     String text = name.getString();
/* 41 */     int currentSize = 0;
/* 42 */     int lastIndex = -1;
/* 43 */     for (int i = 0; i < text.length(); i++) {
/*    */       
/* 45 */       currentSize += mc.f_91062_.m_92852_(FormattedText.m_130762_(String.valueOf(text.charAt(i)), name.m_7383_()));
/* 46 */       lastIndex = i;
/* 47 */       if (currentSize > allowedWidth)
/*    */         break; 
/*    */     } 
/* 50 */     if (lastIndex > 0) {
/*    */       
/* 52 */       String newText = text.substring(0, lastIndex + 1);
/* 53 */       if (currentSize > allowedWidth)
/* 54 */         newText = newText + "..."; 
/* 55 */       return (Component)Component.m_237113_(newText).m_130948_(name.m_7383_());
/*    */     } 
/*    */ 
/*    */     
/* 59 */     return CommonComponents.f_237098_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static String extractNameFromPath(String path) {
/* 65 */     String name = path;
/* 66 */     int index = path.lastIndexOf('.');
/* 67 */     if (index > 0 && index + 1 < name.length())
/* 68 */       name = path.substring(index + 1); 
/* 69 */     return name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\ConfigListItem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */