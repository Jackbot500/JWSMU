/*     */ package nonamecrackers2.crackerslib.client.gui;
/*     */ 
/*     */ import com.electronwill.nightconfig.core.UnmodifiableConfig;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.EditBox;
/*     */ import net.minecraft.client.gui.components.Tooltip;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.layouts.FrameLayout;
/*     */ import net.minecraft.client.gui.layouts.GridLayout;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.eventbus.api.Event;
/*     */ import net.minecraftforge.fml.config.ModConfig;
/*     */ import net.minecraftforge.fml.loading.FMLEnvironment;
/*     */ import nonamecrackers2.crackerslib.client.event.impl.AddConfigEntryToMenuEvent;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.CollapseButton;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.SortButton;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.config.ConfigCategory;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.config.ConfigListItem;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.config.ConfigOptionList;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.config.entry.ConfigEntry;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.config.entry.ListConfigEntry;
/*     */ import nonamecrackers2.crackerslib.client.util.SortType;
/*     */ import nonamecrackers2.crackerslib.common.config.preset.ConfigPreset;
/*     */ import nonamecrackers2.crackerslib.common.config.preset.ConfigPresets;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ public class ConfigScreen
/*     */   extends Screen
/*     */ {
/*  51 */   private static final Logger LOGGER = LogManager.getLogger("crackerslib/ConfigScreen");
/*  52 */   private static final Component CUSTOM_PRESET_TITLE = (Component)Component.m_237115_("config.crackerslib.preset.custom.title");
/*  53 */   private static final Component CUSTOM_PRESET_DESCRIPTION = (Component)Component.m_237115_("config.crackerslib.preset.custom.description").m_130940_(ChatFormatting.GRAY);
/*  54 */   private static final Component HOLD_SHIFT = (Component)Component.m_237115_("gui.crackerslib.button.preset.holdShift").m_130940_(ChatFormatting.DARK_GRAY);
/*     */   private static final int TITLE_HEIGHT = 12;
/*     */   private static final int BUTTON_WIDTH = 200;
/*     */   private static final int BUTTON_HEIGHT = 20;
/*     */   private static final int EXIT_BUTTON_OFFSET = 26;
/*     */   private final String modid;
/*     */   private final ModConfig.Type type;
/*     */   private final ForgeConfigSpec spec;
/*     */   private final Consumer<ConfigOptionList> itemGenerator;
/*     */   private final Screen homeScreen;
/*     */   private final List<ConfigPreset> presets;
/*  65 */   private Collection<String> presetExcluded = (Collection<String>)ImmutableList.of();
/*     */   private ConfigOptionList list;
/*     */   private Button exit;
/*     */   private Button changePreset;
/*     */   private Button reset;
/*     */   @Nullable
/*     */   private ConfigPreset preset;
/*     */   private ConfigListItem currentHovered;
/*     */   private Tooltip currentHoveredTooltip;
/*     */   private EditBox searchBox;
/*     */   
/*     */   public ConfigScreen(String modid, ForgeConfigSpec spec, ModConfig.Type type, Consumer<ConfigOptionList> itemGenerator, Screen homeScreen) {
/*  77 */     super((Component)Component.m_237115_("gui.crackerslib.screen." + type.extension() + "Options.title"));
/*  78 */     this.modid = modid;
/*  79 */     this.type = type;
/*  80 */     this.spec = spec;
/*  81 */     this.itemGenerator = itemGenerator;
/*  82 */     this.homeScreen = homeScreen;
/*  83 */     this.presets = Lists.newArrayList((Object[])new ConfigPreset[] { ConfigPreset.defaultPreset() });
/*  84 */     ConfigPresets.Presets presets = ConfigPresets.getPresetsForModId(this.modid);
/*  85 */     if (presets != null) {
/*     */       
/*  87 */       this.presetExcluded = presets.getExcludedConfigOptions();
/*  88 */       for (ConfigPreset preset : presets.getPresetsForType(type)) {
/*  89 */         this.presets.add(preset);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ConfigScreen makeScreen(String modid, ForgeConfigSpec spec, ModConfig.Type type, Screen homeScreen, String startingPath) {
/*  95 */     return new ConfigScreen(modid, spec, type, list -> { if (spec.isLoaded()) { Map<String, Object> values; if (startingPath.isEmpty()) { values = spec.getValues().valueMap(); } else { values = ((UnmodifiableConfig)spec.getValues().get(startingPath)).valueMap(); }  buildConfigList(modid, type, list, filterValues(modid, type, startingPath, values), startingPath, Optional.empty()); } else { if (!FMLEnvironment.production) throw new IllegalStateException("Config spec " + type + " is not loaded! Have you registered it?");  LOGGER.error("Config spec {} is not loaded for mod {}", type, modid); }  }homeScreen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, Object> filterValues(String modid, ModConfig.Type type, String previousPath, Map<String, Object> values) {
/* 118 */     return (Map<String, Object>)values.entrySet().stream().map(entry -> {
/*     */           String path = (String)entry.getKey();
/*     */           if (!previousPath.isEmpty())
/*     */             path = previousPath + "." + previousPath; 
/*     */           return Map.entry(path, entry.getValue());
/* 123 */         }).filter(entry -> !MinecraftForge.EVENT_BUS.post((Event)new AddConfigEntryToMenuEvent(modid, type, (String)entry.getKey())))
/*     */       
/* 125 */       .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
/*     */   }
/*     */ 
/*     */   
/*     */   private static void buildConfigList(String modid, ModConfig.Type type, ConfigOptionList list, Map<String, Object> values, String previousPath, Optional<ConfigCategory> category) {
/* 130 */     for (Map.Entry<String, Object> entry : values.entrySet()) {
/*     */       
/* 132 */       String path = entry.getKey();
/* 133 */       Object obj = entry.getValue();
/* 134 */       if (obj instanceof UnmodifiableConfig) { UnmodifiableConfig next = (UnmodifiableConfig)obj;
/*     */         
/* 136 */         Map<String, Object> nextValues = filterValues(modid, type, path, next.valueMap());
/* 137 */         if (!nextValues.isEmpty()) {
/*     */           
/* 139 */           ConfigCategory nextCategory = list.makeCategory(path, category);
/* 140 */           buildConfigList(modid, type, list, nextValues, path, Optional.of(nextCategory));
/*     */         }  continue; }
/*     */       
/* 143 */       if (obj instanceof ForgeConfigSpec.ConfigValue) { ForgeConfigSpec.ConfigValue<?> value = (ForgeConfigSpec.ConfigValue)obj;
/*     */         
/* 145 */         Class<?> clazz = value.getDefault().getClass();
/* 146 */         if (Integer.class.isAssignableFrom(clazz)) {
/* 147 */           list.addConfigValue(path, nonamecrackers2.crackerslib.client.gui.widget.config.entry.IntegerConfigEntry::new, category); continue;
/* 148 */         }  if (Long.class.isAssignableFrom(clazz)) {
/* 149 */           list.addConfigValue(path, nonamecrackers2.crackerslib.client.gui.widget.config.entry.LongConfigEntry::new, category); continue;
/* 150 */         }  if (Double.class.isAssignableFrom(clazz)) {
/* 151 */           list.addConfigValue(path, nonamecrackers2.crackerslib.client.gui.widget.config.entry.DoubleConfigEntry::new, category); continue;
/* 152 */         }  if (Boolean.class.isAssignableFrom(clazz)) {
/* 153 */           list.addConfigValue(path, nonamecrackers2.crackerslib.client.gui.widget.config.entry.BooleanConfigEntry::new, category); continue;
/* 154 */         }  if (Enum.class.isAssignableFrom(clazz)) {
/* 155 */           list.addConfigValue(path, nonamecrackers2.crackerslib.client.gui.widget.config.entry.EnumConfigEntry::new, category); continue;
/* 156 */         }  if (String.class.isAssignableFrom(clazz)) {
/* 157 */           list.addConfigValue(path, nonamecrackers2.crackerslib.client.gui.widget.config.entry.StringConfigEntry::new, category); continue;
/* 158 */         }  if (tryToAddListEntry(list, clazz, path, value, category))
/*     */           continue; 
/* 160 */         LOGGER.warn("Unknown config GUI entry for type '{}'", clazz); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected static boolean tryToAddListEntry(ConfigOptionList list, Class<?> valueClass, String path, ForgeConfigSpec.ConfigValue<?> value, Optional<ConfigCategory> category) {
/* 167 */     if (List.class.isAssignableFrom(valueClass)) {
/*     */       
/* 169 */       List<?> listValue = (List)value.getDefault();
/* 170 */       if (listValue.size() > 0) {
/*     */         
/* 172 */         Class<?> clazz = listValue.get(0).getClass();
/* 173 */         if (String.class.isAssignableFrom(clazz)) {
/* 174 */           putListEntry(list, path, category, v -> v);
/* 175 */         } else if (Double.class.isAssignableFrom(clazz)) {
/* 176 */           putListEntry(list, path, category, Double::parseDouble);
/* 177 */         } else if (Float.class.isAssignableFrom(clazz)) {
/* 178 */           putListEntry(list, path, category, Float::parseFloat);
/* 179 */         } else if (Integer.class.isAssignableFrom(clazz)) {
/* 180 */           putListEntry(list, path, category, Integer::parseInt);
/*     */         } else {
/* 182 */           return false;
/* 183 */         }  return true;
/*     */       } 
/*     */ 
/*     */       
/* 187 */       LOGGER.info("Could not determine generic type for empty list config value");
/* 188 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 193 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void putListEntry(ConfigOptionList list, String path, Optional<ConfigCategory> category, ListConfigEntry.ValueParser<?> parser) {
/* 199 */     list.addConfigValue(path, (mc, modid, type, p, s, r) -> new ListConfigEntry(mc, modid, type, p, s, r, parser), category);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void m_7856_() {
/* 207 */     if (this.list == null) {
/*     */       
/* 209 */       this.list = new ConfigOptionList(this.f_96541_, this.modid, this.type, this.spec, this.f_96543_, this.f_96544_, 30, this.f_96544_ - 30, this::onValueChanged);
/* 210 */       this.itemGenerator.accept(this.list);
/*     */     } 
/* 212 */     this.list.buildList();
/* 213 */     this.list.m_93437_(this.f_96543_, this.f_96544_, 30, this.f_96544_ - 30);
/* 214 */     m_142416_((GuiEventListener)this.list);
/*     */     
/* 216 */     this
/*     */ 
/*     */       
/* 219 */       .exit = Button.m_253074_((Component)Component.m_237115_("gui.crackerslib.button.exitAndSave.title"), button -> closeMenu()).m_252794_((this.f_96543_ - 100) / 2, this.f_96544_ - 26).m_253046_(100, 20).m_253136_();
/*     */     
/* 221 */     Objects.requireNonNull(this.presetExcluded); this.preset = this.list.getMatchingPreset(this.presets, this.presetExcluded::contains);
/*     */     
/* 223 */     this
/*     */ 
/*     */ 
/*     */       
/* 227 */       .changePreset = Button.m_253074_((Component)Component.m_237115_("gui.crackerslib.button.preset.title").m_130946_(": ").m_7220_(getPresetName()), button -> changePreset()).m_252794_(10, this.f_96544_ - 26).m_253046_((int)Math.round(133.33333333333334D), 20).m_257505_(Tooltip.m_257550_(getPresetTooltip(false))).m_253136_();
/*     */     
/* 229 */     this
/*     */ 
/*     */       
/* 232 */       .reset = Button.m_253074_((Component)Component.m_237115_("gui.crackerslib.button.reset.title"), button -> resetValues()).m_252794_(this.f_96543_ - 133 - 10, this.f_96544_ - 26).m_253046_((int)Math.round(133.33333333333334D), 20).m_253136_();
/* 233 */     this.reset.f_93623_ = false;
/*     */     
/* 235 */     GridLayout layout = (new GridLayout()).m_267749_(5);
/* 236 */     GridLayout.RowHelper rows = layout.m_264606_(2);
/*     */     
/* 238 */     rows.m_264139_((LayoutElement)new SortButton(0, 0, type -> {
/*     */             this.list.setSorting(type);
/*     */             
/*     */             this.list.rebuildList();
/*     */           }));
/* 243 */     rows.m_264139_((LayoutElement)new CollapseButton(0, 0, () -> this.list.collapseAllCategories()));
/*     */ 
/*     */ 
/*     */     
/* 247 */     layout.m_264036_();
/* 248 */     FrameLayout.m_264460_((LayoutElement)layout, 5, 0, this.f_96543_ - 5, 30, 0.0F, 0.5F);
/* 249 */     layout.m_264134_(x$0 -> (AbstractWidget)rec$.m_142416_(x$0));
/*     */     
/* 251 */     MutableComponent mutableComponent = Component.m_237115_("gui.crackerslib.screen.config.search");
/* 252 */     this.searchBox = new EditBox(this.f_96547_, this.f_96543_ - this.f_96543_ / 3 - 5, 5, this.f_96543_ / 3, 20, (Component)mutableComponent);
/* 253 */     this.searchBox.m_257771_((Component)mutableComponent);
/* 254 */     this.searchBox.m_94151_(text -> {
/*     */           this.list.buildList(text, true);
/*     */           this.list.m_93410_(0.0D);
/*     */         });
/* 258 */     this.searchBox.m_94199_(100);
/* 259 */     m_264313_((GuiEventListener)this.searchBox);
/*     */     
/* 261 */     m_142416_((GuiEventListener)this.exit);
/* 262 */     m_142416_((GuiEventListener)this.changePreset);
/* 263 */     m_142416_((GuiEventListener)this.reset);
/* 264 */     m_142416_((GuiEventListener)this.searchBox);
/*     */   }
/*     */ 
/*     */   
/*     */   private void closeMenu() {
/* 269 */     this.list.onClosed();
/* 270 */     if (this.f_96541_.f_91080_ == this) {
/* 271 */       this.f_96541_.m_91152_(this.homeScreen);
/*     */     }
/*     */   }
/*     */   
/*     */   public Screen getHomeScreen() {
/* 276 */     return this.homeScreen;
/*     */   }
/*     */ 
/*     */   
/*     */   private void resetValues() {
/* 281 */     this.list.resetValues();
/* 282 */     Objects.requireNonNull(this.presetExcluded); this.preset = this.list.getMatchingPreset(this.presets, this.presetExcluded::contains);
/* 283 */     this.changePreset.m_93666_((Component)Component.m_237115_("gui.crackerslib.button.preset.title").m_130946_(": ").m_7220_(getPresetName()));
/* 284 */     this.reset.f_93623_ = false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void changePreset() {
/* 289 */     int next = this.presets.indexOf(this.preset) + 1;
/* 290 */     if (next >= this.presets.size())
/* 291 */       next = 0; 
/* 292 */     this.preset = this.presets.get(next);
/* 293 */     if (this.preset != null) {
/* 294 */       Objects.requireNonNull(this.presetExcluded); this.list.setFromPreset(this.preset, this.presetExcluded::contains);
/* 295 */     }  this.changePreset.m_93666_((Component)Component.m_237115_("gui.crackerslib.button.preset.title").m_130946_(": ").m_7220_(getPresetName()));
/* 296 */     this.reset.f_93623_ = !this.list.areValuesReset();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_88315_(GuiGraphics stack, int mouseX, int mouseY, float partialTicks) {
/* 302 */     super.m_88315_(stack, mouseX, mouseY, partialTicks);
/* 303 */     stack.m_280137_(this.f_96547_, this.f_96539_.getString(), this.f_96543_ / 2, 12, 16777215);
/* 304 */     this.changePreset.m_257544_(Tooltip.m_257550_(getPresetTooltip(m_96638_())));
/* 305 */     ConfigListItem item = this.list.getItemAt(mouseX, mouseY);
/* 306 */     if (this.currentHovered != item) {
/*     */       
/* 308 */       this.currentHovered = item;
/* 309 */       if (item != null) {
/* 310 */         this.currentHoveredTooltip = item.getTooltip(this.preset);
/*     */       } else {
/* 312 */         this.currentHoveredTooltip = null;
/*     */       } 
/* 314 */     }  if (!m_6702_().stream().anyMatch(c -> (!c.equals(this.list) && c.m_5953_(mouseX, mouseY))) && this.currentHoveredTooltip != null) {
/* 315 */       stack.m_280245_(this.f_96547_, this.currentHoveredTooltip.m_257408_(this.f_96541_), mouseX, mouseY);
/*     */     }
/*     */   }
/*     */   
/*     */   private void onValueChanged() {
/* 320 */     Objects.requireNonNull(this.presetExcluded); this.preset = this.list.getMatchingPreset(this.presets, this.presetExcluded::contains);
/* 321 */     this.changePreset.m_93666_((Component)Component.m_237115_("gui.crackerslib.button.preset.title").m_130946_(": ").m_7220_(getPresetName()));
/* 322 */     this.reset.f_93623_ = !this.list.areValuesReset();
/*     */   }
/*     */ 
/*     */   
/*     */   private Component getPresetTooltip(boolean shiftDown) {
/* 327 */     if (this.preset != null) {
/* 328 */       return this.preset.getTooltip(shiftDown);
/*     */     }
/* 330 */     return makeCustomPresetTooltip(shiftDown);
/*     */   }
/*     */ 
/*     */   
/*     */   private Component getPresetName() {
/* 335 */     if (this.preset != null) {
/* 336 */       return this.preset.name();
/*     */     }
/* 338 */     return CUSTOM_PRESET_TITLE;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Component makeCustomPresetTooltip(boolean shiftDown) {
/* 343 */     MutableComponent component = CUSTOM_PRESET_TITLE.m_6881_();
/* 344 */     component.m_130946_("\n");
/* 345 */     if (shiftDown) {
/* 346 */       component.m_7220_(CUSTOM_PRESET_DESCRIPTION);
/*     */     } else {
/* 348 */       component.m_7220_(HOLD_SHIFT);
/* 349 */     }  return (Component)component;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\ConfigScreen.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */