/*    */ package nonamecrackers2.crackerslib.client.gui.widget;
/*    */ 
/*    */ import net.minecraft.client.gui.Font;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.AbstractButton;
/*    */ import net.minecraft.client.gui.components.Tooltip;
/*    */ import net.minecraft.client.gui.narration.NarrationElementOutput;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import nonamecrackers2.crackerslib.CrackersLib;
/*    */ 
/*    */ public class CollapseButton
/*    */   extends AbstractButton {
/* 14 */   private static final ResourceLocation ICON = CrackersLib.id("textures/gui/config/collapse.png");
/* 15 */   private static final Component NAME = (Component)Component.m_237115_("gui.crackerslib.button.collapse.title");
/* 16 */   private static final Component TOOLTIP = (Component)Component.m_237115_("gui.crackerslib.button.collapse.description");
/*    */   
/*    */   private final Runnable onPressed;
/*    */   
/*    */   public CollapseButton(int x, int y, Runnable onPressed) {
/* 21 */     super(x, y, 20, 20, NAME);
/* 22 */     this.onPressed = onPressed;
/* 23 */     m_257544_(Tooltip.m_257550_(TOOLTIP));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_5691_() {
/* 29 */     this.onPressed.run();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_87963_(GuiGraphics stack, int mouseX, int mouseY, float partialTick) {
/* 35 */     super.m_87963_(stack, mouseX, mouseY, partialTick);
/* 36 */     stack.m_280411_(ICON, m_252754_(), m_252907_(), m_5711_(), m_93694_(), 0.0F, 0.0F, m_5711_(), m_93694_(), 256, 256);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_280139_(GuiGraphics stack, Font pFont, int pColor) {}
/*    */ 
/*    */   
/*    */   protected void m_168797_(NarrationElementOutput pNarrationElementOutput) {
/* 45 */     m_168802_(pNarrationElementOutput);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\CollapseButton.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */