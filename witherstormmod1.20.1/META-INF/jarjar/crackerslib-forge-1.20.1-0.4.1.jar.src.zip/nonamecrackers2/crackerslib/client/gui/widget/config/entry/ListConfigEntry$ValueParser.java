package nonamecrackers2.crackerslib.client.gui.widget.config.entry;

@FunctionalInterface
public interface ValueParser<T> {
  T parse(String paramString) throws NumberFormatException;
}


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\entry\ListConfigEntry$ValueParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */