/*     */ package nonamecrackers2.crackerslib.client.gui.widget.config;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Predicate;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.ContainerObjectSelectionList;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.narration.NarratableEntry;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ import net.minecraftforge.fml.config.ModConfig;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.config.entry.ConfigEntry;
/*     */ import nonamecrackers2.crackerslib.client.util.SortType;
/*     */ import nonamecrackers2.crackerslib.common.config.preset.ConfigPreset;
/*     */ 
/*     */ 
/*     */ public class ConfigOptionList
/*     */   extends ContainerObjectSelectionList<ConfigOptionList.Entry>
/*     */ {
/*  28 */   private static final Component NO_CONFIG_OPTIONS = (Component)Component.m_237115_("gui.crackerslib.config.noAvailableOptions");
/*     */   private static final int ROW_HEIGHT = 30;
/*  30 */   private final List<ConfigListItem> items = Lists.newArrayList();
/*  31 */   private final List<ConfigCategory> categories = Lists.newArrayList();
/*     */   private final ModConfig.Type type;
/*  33 */   private String lastSearch = "";
/*  34 */   private SortType sortType = SortType.A_TO_Z;
/*     */   
/*     */   private final Runnable valuesChangedResponder;
/*     */   private final String modid;
/*     */   private final ForgeConfigSpec spec;
/*     */   
/*     */   public ConfigOptionList(Minecraft mc, String modid, ModConfig.Type type, ForgeConfigSpec spec, int width, int height, int top, int bottom, Runnable valuesChangedResponder) {
/*  41 */     super(mc, width, height, top, bottom, 30);
/*  42 */     this.modid = modid;
/*  43 */     this.type = type;
/*  44 */     this.spec = spec;
/*  45 */     m_93488_(false);
/*  46 */     m_93496_(true);
/*  47 */     this.valuesChangedResponder = valuesChangedResponder;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getModid() {
/*  52 */     return this.modid;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void addConfigValue(String path, ConfigEntryBuilder itemBuilder, Optional<ConfigCategory> category) {
/*  57 */     category.ifPresentOrElse(c -> c.addChild((ConfigListItem)itemBuilder.build(this.f_93386_, this.modid, this.type, path, this.spec, this.valuesChangedResponder)), () -> this.items.add(itemBuilder.build(this.f_93386_, this.modid, this.type, path, this.spec, this.valuesChangedResponder)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigCategory makeCategory(String path, Optional<ConfigCategory> previousCategory) {
/*  66 */     ConfigCategory category = new ConfigCategory(this.f_93386_, this.modid, path, this);
/*  67 */     previousCategory.ifPresentOrElse(c -> c.addChild(category), () -> this.items.add(category));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     this.categories.add(category);
/*  73 */     return category;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private ConfigCategory getCategoryByPath(String path) {
/*  78 */     for (ConfigCategory category : this.categories) {
/*     */       
/*  80 */       if (path.equals(category.getPath()))
/*  81 */         return category; 
/*     */     } 
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSorting(SortType sorting) {
/*  88 */     this.sortType = sorting;
/*     */   }
/*     */ 
/*     */   
/*     */   public void collapseAllCategories() {
/*  93 */     for (ConfigCategory category : this.categories)
/*  94 */       category.setExpanded(false); 
/*  95 */     rebuildList();
/*     */   }
/*     */ 
/*     */   
/*     */   public void buildList() {
/* 100 */     buildList("", false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void rebuildList() {
/* 105 */     buildList(getLastSearchingFor(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void buildList(String text, boolean expandOrContractCategories) {
/* 110 */     m_93516_();
/* 111 */     this.sortType.sortList(this.items);
/* 112 */     List<ConfigListItem> items = Lists.newArrayList();
/* 113 */     for (ConfigCategory category : this.categories) {
/*     */       
/* 115 */       category.setSorting(this.sortType);
/* 116 */       if (expandOrContractCategories)
/* 117 */         category.setExpanded(!text.isBlank()); 
/*     */     } 
/* 119 */     for (ConfigListItem item : this.items) {
/*     */       
/* 121 */       if (text.isEmpty() || item.matchesSearch(text)) {
/*     */         
/* 123 */         items.add(item);
/* 124 */         if (item instanceof ConfigCategory) { ConfigCategory category = (ConfigCategory)item; if (category.isExpanded())
/* 125 */             items.addAll(category.gatherChildren(text, expandOrContractCategories));  }
/*     */       
/*     */       } 
/* 128 */     }  for (ConfigListItem item : items)
/* 129 */       m_7085_((AbstractSelectionList.Entry)new Entry(item)); 
/* 130 */     this.lastSearch = text;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClosed() {
/* 135 */     for (ConfigListItem item : this.items) {
/* 136 */       item.onSavedAndClosed();
/*     */     }
/*     */   }
/*     */   
/*     */   public void resetValues() {
/* 141 */     for (ConfigListItem item : this.items) {
/* 142 */       item.resetValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean areValuesReset() {
/* 147 */     for (ConfigListItem item : this.items) {
/*     */       
/* 149 */       if (!item.isValueReset())
/* 150 */         return false; 
/*     */     } 
/* 152 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ConfigPreset getMatchingPreset(List<ConfigPreset> presets, Predicate<String> excluded) {
/* 158 */     label13: for (ConfigPreset preset : presets) {
/*     */       
/* 160 */       for (ConfigListItem item : this.items) {
/*     */         
/* 162 */         if (!item.matchesPreset(preset, excluded))
/*     */           continue label13; 
/*     */       } 
/* 165 */       return preset;
/*     */     } 
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFromPreset(ConfigPreset preset, Predicate<String> excluded) {
/* 172 */     for (ConfigListItem item : this.items) {
/* 173 */       item.setFromPreset(preset, excluded);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int m_5759_() {
/* 179 */     return getWidth() - 40;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int m_5756_() {
/* 185 */     return getLeft() + getWidth() - 5;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void m_7733_(GuiGraphics stack) {
/* 191 */     if (this.f_93386_.f_91073_ != null) {
/*     */       
/* 193 */       stack.m_280024_(0, 0, this.f_93388_, this.f_93389_, -1072689136, -804253680);
/*     */     }
/*     */     else {
/*     */       
/* 197 */       RenderSystem.setShaderColor(0.15F, 0.15F, 0.15F, 1.0F);
/* 198 */       stack.m_280398_(Screen.f_279548_, 0, 0, 0, 0.0F, 0.0F, this.f_93388_, this.f_93389_, 32, 32);
/* 199 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_88315_(GuiGraphics stack, int mouseX, int mouseY, float partialTick) {
/* 206 */     super.m_88315_(stack, mouseX, mouseY, partialTick);
/* 207 */     if (m_6702_().isEmpty())
/* 208 */       stack.m_280653_(this.f_93386_.f_91062_, NO_CONFIG_OPTIONS, this.f_93388_ / 2, this.f_93389_ / 2, -1); 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public ConfigListItem getItemAt(int mouseX, int mouseY) {
/* 213 */     Entry entry = (Entry)m_93412_(mouseX, mouseY);
/* 214 */     if (entry != null && entry.children.stream().anyMatch(w -> !w.m_274382_())) {
/* 215 */       return entry.item;
/*     */     }
/* 217 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private ConfigCategory getCategoryFor(ConfigListItem item) {
/* 222 */     for (ConfigCategory category : this.categories) {
/*     */       
/* 224 */       if (category.getImmediateChildren().contains(item))
/* 225 */         return category; 
/*     */     } 
/* 227 */     return null;
/*     */   } @FunctionalInterface
/*     */   public static interface ConfigEntryBuilder {
/*     */     ConfigEntry<?, ?> build(Minecraft param1Minecraft, String param1String1, ModConfig.Type param1Type, String param1String2, ForgeConfigSpec param1ForgeConfigSpec, Runnable param1Runnable); }
/*     */   public String getLastSearchingFor() {
/* 232 */     return this.lastSearch;
/*     */   }
/*     */   
/*     */   public class Entry
/*     */     extends ContainerObjectSelectionList.Entry<Entry> {
/* 237 */     private final List<AbstractWidget> children = Lists.newArrayList();
/*     */     
/*     */     private final ConfigListItem item;
/*     */     private final int x;
/*     */     
/*     */     public Entry(ConfigListItem item) {
/* 243 */       this.item = item;
/* 244 */       ConfigCategory category = ConfigOptionList.this.getCategoryFor(item);
/* 245 */       int x = (ConfigOptionList.this.getWidth() - ConfigOptionList.this.m_5759_()) / 2;
/* 246 */       if (category != null)
/* 247 */         x = category.getX() + 20; 
/* 248 */       this.item.init(this.children, x, ConfigOptionList.this.getTop(), ConfigOptionList.this.m_5759_(), ConfigOptionList.this.f_93387_);
/* 249 */       this.x = x;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<? extends GuiEventListener> m_6702_() {
/* 255 */       return (List)this.children;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<? extends NarratableEntry> m_142437_() {
/* 261 */       return (List)this.children;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void m_6311_(GuiGraphics stack, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean selected, float partialTicks) {
/* 267 */       stack.m_280637_(this.x, top, width - this.x - left, height, -1426063361);
/* 268 */       if (this.x > left) {
/*     */         
/* 270 */         stack.m_280509_(this.x - 20, top + height / 2, this.x - 4, top + height / 2 + 1, 1442840575);
/* 271 */         stack.m_280509_(this.x - 20, top - height / 2 - 3, this.x - 19, top + height / 2, 1442840575);
/*     */       } 
/* 273 */       this.item.render(stack, left, top, width, height, mouseX, mouseY, partialTicks);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\ConfigOptionList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */