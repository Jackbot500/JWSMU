/*     */ package nonamecrackers2.crackerslib.client.gui;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractButton;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.Tooltip;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.layouts.FrameLayout;
/*     */ import net.minecraft.client.gui.layouts.GridLayout;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ import net.minecraft.network.chat.Style;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.eventbus.api.Event;
/*     */ import net.minecraftforge.fml.config.ModConfig;
/*     */ import nonamecrackers2.crackerslib.client.config.ConfigHomeScreenFactory;
/*     */ import nonamecrackers2.crackerslib.client.event.impl.OnConfigScreenOpened;
/*     */ import nonamecrackers2.crackerslib.client.gui.title.TitleLogo;
/*     */ import nonamecrackers2.crackerslib.client.util.GUIUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigHomeScreen
/*     */   extends Screen
/*     */ {
/*     */   private static final int BUTTON_WIDTH = 200;
/*     */   private static final int BUTTON_HEIGHT = 20;
/*     */   private static final int EXIT_BUTTON_OFFSET = 6;
/*     */   private static final int MAX_WIDTH = 200;
/*     */   private static final int COLUMN_SPACING = 4;
/*     */   private final String modid;
/*     */   private final Map<ModConfig.Type, ForgeConfigSpec> specs;
/*     */   private final TitleLogo title;
/*     */   
/*     */   public ConfigHomeScreen(String modid, Map<ModConfig.Type, ForgeConfigSpec> specs, TitleLogo title, boolean isWorldLoaded, boolean hasSinglePlayerServer, @Nullable Screen previous, List<Supplier<AbstractButton>> extraButtons, int totalColumns) {
/*  53 */     super((Component)Component.m_237115_("gui." + modid + ".screen.config.home.title"));
/*  54 */     this.title = title;
/*  55 */     this.modid = modid;
/*  56 */     this.specs = specs;
/*  57 */     this.isWorldLoaded = isWorldLoaded;
/*  58 */     this.hasSinglePlayerServer = hasSinglePlayerServer;
/*  59 */     this.previous = previous;
/*  60 */     this.extraButtons = extraButtons;
/*  61 */     this.totalColumns = totalColumns;
/*     */   } private final boolean isWorldLoaded; private final boolean hasSinglePlayerServer; @Nullable
/*     */   private final Screen previous; private final List<Supplier<AbstractButton>> extraButtons; private final int totalColumns; @Nullable
/*     */   private Button commonButton; @Nullable
/*     */   private Button worldButton; private Button exit; private int elementSpacing;
/*     */   protected void m_7856_() {
/*  67 */     GridLayout layout = (new GridLayout()).m_267750_(6);
/*  68 */     GridLayout.RowHelper rowHelper = layout.m_264606_(1);
/*     */     
/*  70 */     if (this.specs.containsKey(ModConfig.Type.CLIENT))
/*     */     {
/*  72 */       rowHelper.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.crackerslib.screen.clientOptions.title"), button -> openConfigMenu(ModConfig.Type.CLIENT))
/*  73 */           .m_253046_(200, 20)
/*  74 */           .m_257505_(Tooltip.m_257550_((Component)Component.m_237115_("gui.crackerslib.screen.clientOptions.info")))
/*  75 */           .m_253136_());
/*     */     }
/*     */     
/*  78 */     if (this.specs.containsKey(ModConfig.Type.COMMON))
/*     */     {
/*  80 */       this.commonButton = (Button)rowHelper.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.crackerslib.screen.commonOptions.title"), button -> openConfigMenu(ModConfig.Type.COMMON))
/*  81 */           .m_253046_(200, 20)
/*  82 */           .m_257505_(Tooltip.m_257550_((Component)Component.m_237115_("gui.crackerslib.screen.commonOptions.info")))
/*  83 */           .m_253136_());
/*     */     }
/*     */     
/*  86 */     if (this.specs.containsKey(ModConfig.Type.SERVER))
/*     */     {
/*  88 */       this.worldButton = (Button)rowHelper.m_264139_((LayoutElement)Button.m_253074_((Component)Component.m_237115_("gui.crackerslib.screen.serverOptions.title"), button -> openConfigMenu(ModConfig.Type.SERVER))
/*  89 */           .m_253046_(200, 20)
/*  90 */           .m_253136_());
/*     */     }
/*     */     
/*  93 */     initExtraButtons(rowHelper);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     this
/*     */ 
/*     */       
/* 103 */       .exit = Button.m_253074_((Component)Component.m_237115_("gui.crackerslib.button.exit.title"), button -> m_7379_()).m_252794_((this.f_96543_ - 200) / 2, this.f_96544_ - 6 - 20).m_253046_(200, 20).m_253136_();
/*     */     
/* 105 */     int exitButtonSpaceTaken = this.exit.m_93694_() + 20;
/* 106 */     int availableScreenHeight = this.f_96544_ - exitButtonSpaceTaken;
/*     */     
/* 108 */     layout.m_264036_();
/*     */     
/* 110 */     int layoutHeight = layout.m_93694_();
/* 111 */     int totalHeightTaken = layoutHeight + this.title.getHeight();
/* 112 */     int heightRemaining = availableScreenHeight - totalHeightTaken;
/* 113 */     this.elementSpacing = heightRemaining / 4;
/*     */     
/* 115 */     int top = this.elementSpacing * 2 + this.title.getHeight();
/* 116 */     FrameLayout.m_264159_((LayoutElement)layout, 0, top, this.f_96543_, availableScreenHeight - top - this.elementSpacing);
/* 117 */     layout.m_264134_(x$0 -> (AbstractWidget)rec$.m_142416_(x$0));
/*     */     
/* 119 */     if (this.commonButton != null)
/* 120 */       this.commonButton.f_93623_ = ((this.isWorldLoaded && this.hasSinglePlayerServer) || !this.isWorldLoaded); 
/* 121 */     if (this.worldButton != null)
/* 122 */       this.worldButton.f_93623_ = (this.isWorldLoaded && this.hasSinglePlayerServer); 
/* 123 */     m_142416_((GuiEventListener)this.exit);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initExtraButtons(GridLayout.RowHelper main) {
/* 128 */     if (!this.extraButtons.isEmpty()) {
/*     */       
/* 130 */       int totalButtons = this.extraButtons.size();
/* 131 */       int totalColumns = Math.min(totalButtons, this.totalColumns);
/*     */       
/* 133 */       GridLayout extraButtons = (GridLayout)main.m_264139_((LayoutElement)(new GridLayout()).m_267750_(6).m_267749_(4));
/* 134 */       GridLayout.RowHelper extraButtonsRowHelper = extraButtons.m_264606_(totalColumns);
/*     */       
/* 136 */       int currentRow = 0; int i;
/* 137 */       for (i = 0; i < totalButtons; i += totalColumns) {
/*     */         
/* 139 */         currentRow++;
/* 140 */         int totalButtonsInRow = totalColumns;
/* 141 */         if (currentRow * totalColumns >= totalButtons)
/* 142 */           totalButtonsInRow -= currentRow * totalColumns - totalButtons; 
/* 143 */         int occupiedColumns = totalColumns / totalButtonsInRow;
/* 144 */         int widthPerButton = (200 - 4 * (totalButtonsInRow - 1)) / totalButtonsInRow;
/* 145 */         for (int j = 0; j < totalButtonsInRow; j++) {
/*     */           
/* 147 */           int index = i + j;
/* 148 */           AbstractButton button = ((Supplier<AbstractButton>)this.extraButtons.get(index)).get();
/* 149 */           button.m_93674_(widthPerButton);
/* 150 */           extraButtonsRowHelper.m_264108_((LayoutElement)button, occupiedColumns);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_88315_(GuiGraphics stack, int mouseX, int mouseY, float partialTicks) {
/* 159 */     MutableComponent worldDesc = Component.m_237115_("gui.crackerslib.screen.serverOptions.notInWorld.info");
/* 160 */     if (this.isWorldLoaded)
/* 161 */       worldDesc = Component.m_237115_("gui.crackerslib.screen.serverOptions.inWorld.info"); 
/* 162 */     if (this.worldButton != null)
/* 163 */       this.worldButton.m_257544_(Tooltip.m_257550_((Component)worldDesc)); 
/* 164 */     m_280273_(stack);
/* 165 */     int titleX = this.f_96543_ / 2 - this.title.getWidth() / 2;
/* 166 */     int titleY = this.elementSpacing;
/* 167 */     this.title.blit(stack, titleX, titleY, partialTicks);
/* 168 */     super.m_88315_(stack, mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_7379_() {
/* 174 */     if (this.previous == null) {
/* 175 */       super.m_7379_();
/*     */     } else {
/* 177 */       this.f_96541_.m_91152_(this.previous);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void openConfigMenu(ModConfig.Type type) {
/* 182 */     ForgeConfigSpec spec = this.specs.get(type);
/* 183 */     if (spec != null) {
/*     */       
/* 185 */       OnConfigScreenOpened event = new OnConfigScreenOpened(this.modid, type);
/* 186 */       if (!MinecraftForge.EVENT_BUS.post((Event)event)) {
/* 187 */         this.f_96541_.m_91152_(ConfigScreen.makeScreen(this.modid, spec, type, this, (event.getInitialPath() != null) ? event.getInitialPath() : ""));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Builder builder(TitleLogo title) {
/* 193 */     return new Builder(title);
/*     */   }
/*     */   
/*     */   public static class Builder
/*     */   {
/* 198 */     private final List<Supplier<AbstractButton>> extraButtons = Lists.newArrayList();
/*     */     private final TitleLogo title;
/* 200 */     private int totalColumns = 2;
/*     */ 
/*     */     
/*     */     private Builder(TitleLogo title) {
/* 204 */       this.title = title;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder totalColumns(int columns) {
/* 209 */       this.totalColumns = columns;
/* 210 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder addExtraButton(Supplier<AbstractButton> supplier) {
/* 215 */       this.extraButtons.add(supplier);
/* 216 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder addLinkButton(Component title, String link, @Nullable Tooltip tooltip) {
/* 221 */       return addExtraButton(() -> Button.m_253074_(title, ()).m_253046_(200, 20).m_257505_(tooltip).m_253136_());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addLinkButton(Component title, String link) {
/* 232 */       return addLinkButton(title, link, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder standardLinks(@Nullable String discordLink, @Nullable String patreonLink, @Nullable String githubLink) {
/* 237 */       if (discordLink != null)
/* 238 */         addLinkButton((Component)Component.m_237115_("gui.crackerslib.screen.config.discord").m_130948_(Style.f_131099_.m_178520_(-10983950)), discordLink, Tooltip.m_257550_((Component)Component.m_237115_("gui.crackerslib.screen.config.discord.info"))); 
/* 239 */       if (githubLink != null)
/* 240 */         addLinkButton((Component)Component.m_237115_("gui.crackerslib.screen.config.github").m_130948_(Style.f_131099_.m_178520_(-5526613)), githubLink, Tooltip.m_257550_((Component)Component.m_237115_("gui.crackerslib.screen.config.github.info"))); 
/* 241 */       if (patreonLink != null)
/* 242 */         addLinkButton((Component)Component.m_237115_("gui.crackerslib.screen.config.patreon").m_130940_(ChatFormatting.RED), patreonLink, Tooltip.m_257550_((Component)Component.m_237115_("gui.crackerslib.screen.config.patreon.info"))); 
/* 243 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder crackersDefault(@Nullable String github) {
/* 248 */       return standardLinks("https://discord.com/invite/cracker-s-modded-community-987817685293355028", "https://www.patreon.com/nonamecrackers2", github);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder crackersDefault() {
/* 253 */       return crackersDefault(null);
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigHomeScreenFactory build() {
/* 258 */       return build(ConfigHomeScreen::new);
/*     */     }
/*     */ 
/*     */     
/*     */     public ConfigHomeScreenFactory build(CustomHomeScreen constructor) {
/* 263 */       return (modid, specs, isWorldLoaded, hasSinglePlayerServer, previous) -> constructor.build(modid, specs, this.title, isWorldLoaded, hasSinglePlayerServer, previous, this.extraButtons, this.totalColumns);
/*     */     }
/*     */     
/*     */     @FunctionalInterface
/*     */     public static interface CustomHomeScreen {
/*     */       ConfigHomeScreen build(String param2String, Map<ModConfig.Type, ForgeConfigSpec> param2Map, TitleLogo param2TitleLogo, boolean param2Boolean1, boolean param2Boolean2, @Nullable Screen param2Screen, List<Supplier<AbstractButton>> param2List, int param2Int);
/*     */     }
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface CustomHomeScreen {
/*     */     ConfigHomeScreen build(String param1String, Map<ModConfig.Type, ForgeConfigSpec> param1Map, TitleLogo param1TitleLogo, boolean param1Boolean1, boolean param1Boolean2, @Nullable Screen param1Screen, List<Supplier<AbstractButton>> param1List, int param1Int);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\ConfigHomeScreen.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */