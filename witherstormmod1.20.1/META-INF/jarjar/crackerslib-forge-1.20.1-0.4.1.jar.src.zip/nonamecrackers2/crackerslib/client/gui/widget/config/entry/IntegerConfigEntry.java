/*    */ package nonamecrackers2.crackerslib.client.gui.widget.config.entry;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ 
/*    */ public class IntegerConfigEntry
/*    */   extends NumberConfigEntry<Integer>
/*    */ {
/*    */   public IntegerConfigEntry(Minecraft mc, String modid, ModConfig.Type type, String path, ForgeConfigSpec spec, Runnable onValueUpdated) {
/* 11 */     super(mc, modid, type, path, spec, onValueUpdated);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Integer parseValue(String contents) throws NumberFormatException {
/* 17 */     return Integer.valueOf(Integer.parseInt(contents));
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\entry\IntegerConfigEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */