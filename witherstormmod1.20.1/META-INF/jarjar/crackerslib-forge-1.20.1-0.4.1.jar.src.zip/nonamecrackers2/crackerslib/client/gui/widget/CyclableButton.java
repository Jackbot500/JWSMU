/*    */ package nonamecrackers2.crackerslib.client.gui.widget;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Function;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.network.chat.Component;
/*    */ 
/*    */ 
/*    */ public class CyclableButton<T>
/*    */   extends Button
/*    */ {
/*    */   private final List<T> values;
/*    */   private final Function<T, Component> messageGetter;
/*    */   @Nullable
/*    */   private Consumer<T> responder;
/*    */   private int index;
/*    */   
/*    */   public CyclableButton(int x, int y, int width, List<T> values, T current, Function<T, Component> messageGetter) {
/* 21 */     super(x, y, width, 20, messageGetter.apply(current), b -> {  }Button.f_252438_);
/* 22 */     this.messageGetter = messageGetter;
/* 23 */     this.values = values;
/* 24 */     setValue(current);
/*    */   }
/*    */ 
/*    */   
/*    */   public CyclableButton(int x, int y, int width, List<T> values, T current) {
/* 29 */     this(x, y, width, values, current, val -> Component.m_237113_(val.toString()));
/*    */   }
/*    */ 
/*    */   
/*    */   public void setResponder(Consumer<T> responder) {
/* 34 */     this.responder = responder;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_5691_() {
/* 40 */     this.index++;
/* 41 */     if (this.index >= this.values.size())
/* 42 */       this.index = 0; 
/* 43 */     m_93666_(this.messageGetter.apply(getValue()));
/* 44 */     if (this.responder != null) {
/* 45 */       this.responder.accept(getValue());
/*    */     }
/*    */   }
/*    */   
/*    */   public T getValue() {
/* 50 */     return this.values.get(this.index);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(T value) {
/* 55 */     this.index = this.values.indexOf(value);
/* 56 */     if (this.index == -1)
/* 57 */       throw new IllegalArgumentException("'" + value + "' is not a valid value!"); 
/* 58 */     m_93666_(this.messageGetter.apply(value));
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\CyclableButton.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */