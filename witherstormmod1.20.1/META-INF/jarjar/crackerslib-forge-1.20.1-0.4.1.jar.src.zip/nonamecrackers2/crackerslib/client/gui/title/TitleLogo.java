package nonamecrackers2.crackerslib.client.gui.title;

import net.minecraft.client.gui.GuiGraphics;

public interface TitleLogo {
  void blit(GuiGraphics paramGuiGraphics, int paramInt1, int paramInt2, float paramFloat);
  
  int getWidth();
  
  int getHeight();
}


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\title\TitleLogo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */