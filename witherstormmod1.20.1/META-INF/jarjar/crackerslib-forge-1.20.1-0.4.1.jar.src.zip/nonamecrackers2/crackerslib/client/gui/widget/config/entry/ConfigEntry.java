/*     */ package nonamecrackers2.crackerslib.client.gui.widget.config.entry;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.Tooltip;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ import net.minecraft.network.chat.Style;
/*     */ import net.minecraftforge.common.ForgeConfigSpec;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.eventbus.api.Event;
/*     */ import net.minecraftforge.fml.config.ModConfig;
/*     */ import nonamecrackers2.crackerslib.client.gui.widget.config.ConfigListItem;
/*     */ import nonamecrackers2.crackerslib.common.config.preset.ConfigPreset;
/*     */ import nonamecrackers2.crackerslib.common.event.impl.OnConfigOptionSaved;
/*     */ 
/*     */ 
/*     */ public abstract class ConfigEntry<T, W extends AbstractWidget>
/*     */   implements ConfigListItem
/*     */ {
/*     */   protected final Minecraft mc;
/*     */   protected final String modid;
/*     */   protected final ModConfig.Type type;
/*     */   protected final ForgeConfigSpec.ConfigValue<T> value;
/*     */   protected final ForgeConfigSpec.ValueSpec valueSpec;
/*     */   protected final ForgeConfigSpec spec;
/*     */   protected final boolean requiresRestart;
/*     */   protected final String path;
/*     */   protected final Component name;
/*     */   protected final Component description;
/*     */   @Nullable
/*     */   protected final Component restartText;
/*     */   private final Runnable onValueUpdated;
/*     */   protected W widget;
/*     */   protected Component displayName;
/*     */   
/*     */   public ConfigEntry(Minecraft mc, String modid, ModConfig.Type type, String path, ForgeConfigSpec spec, Runnable onValueUpdated) {
/*  45 */     this.mc = mc;
/*  46 */     this.modid = modid;
/*  47 */     this.type = type;
/*  48 */     this.path = path;
/*  49 */     this.value = (ForgeConfigSpec.ConfigValue<T>)spec.getValues().getRaw(path);
/*  50 */     this.valueSpec = (ForgeConfigSpec.ValueSpec)spec.getRaw(path);
/*  51 */     this.requiresRestart = this.valueSpec.needsWorldRestart();
/*  52 */     this.spec = spec;
/*  53 */     this.name = (Component)Component.m_237115_("gui." + modid + ".config." + ConfigListItem.extractNameFromPath(path) + ".title");
/*  54 */     String key = this.valueSpec.getTranslationKey();
/*  55 */     if (key == null || key.isEmpty()) {
/*  56 */       this.description = (Component)Component.m_237113_(this.valueSpec.getComment());
/*     */     } else {
/*  58 */       this.description = (Component)Component.m_237115_(key);
/*  59 */     }  this.onValueUpdated = onValueUpdated;
/*  60 */     if (this.requiresRestart) {
/*  61 */       this.restartText = (Component)Component.m_237115_("gui.crackerslib.screen.config.requiresRestart").m_130940_(ChatFormatting.RED);
/*     */     } else {
/*  63 */       this.restartText = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Runnable getValueUpdatedResponder() {
/*  68 */     return this.onValueUpdated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getName() {
/*  78 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public Component getDescription() {
/*  83 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetValue() {
/*  95 */     setCurrentValue((T)this.value.get());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFromPreset(ConfigPreset preset, Predicate<String> excluded) {
/* 101 */     if (!excluded.test(this.path))
/*     */     {
/* 103 */       if (preset.hasValue(this.path)) {
/* 104 */         setCurrentValue((T)preset.getValue(this.path));
/*     */       } else {
/* 106 */         setCurrentValue((T)this.value.getDefault());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueReset() {
/* 113 */     return this.value.get().equals(getCurrentValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesPreset(ConfigPreset preset, Predicate<String> excluded) {
/* 119 */     if (!excluded.test(this.path)) {
/*     */       
/* 121 */       if (preset.hasValue(this.path)) {
/* 122 */         return preset.getValue(this.path).equals(getCurrentValue());
/*     */       }
/* 124 */       return this.value.getDefault().equals(getCurrentValue());
/*     */     } 
/*     */ 
/*     */     
/* 128 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onSavedAndClosed() {
/* 135 */     T current = getCurrentValue();
/* 136 */     if (this.valueSpec.test(current)) {
/*     */       
/* 138 */       OnConfigOptionSaved<T> event = new OnConfigOptionSaved(this.modid, this.type, OnConfigOptionSaved.Source.CONFIG_SCREEN, this.value, current, !Objects.equals(current, this.value.get()));
/* 139 */       MinecraftForge.EVENT_BUS.post((Event)event);
/* 140 */       if (event.getOverrideValue() != null && this.valueSpec.test(event.getOverrideValue()))
/* 141 */         current = (T)event.getOverrideValue(); 
/* 142 */       this.value.set(current);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(List<AbstractWidget> widgets, int x, int y, int width, int height) {
/* 149 */     if (this.widget == null)
/* 150 */       this.widget = buildWidget(x, y, width, height); 
/* 151 */     widgets.add((AbstractWidget)this.widget);
/* 152 */     int allowedWidth = width - this.widget.m_5711_() - x - 5;
/* 153 */     if (this.requiresRestart)
/* 154 */       allowedWidth -= this.mc.f_91062_.m_92852_((FormattedText)this.restartText); 
/* 155 */     this.displayName = ConfigListItem.shortenText(this.name, allowedWidth);
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics stack, int x, int y, int width, int height, int mouseX, int mouseY, float partialTicks) {
/*     */     MutableComponent mutableComponent;
/* 161 */     Component component = this.displayName;
/* 162 */     if (this.widget.m_93696_())
/* 163 */       mutableComponent = component.m_6881_().m_130948_(Style.f_131099_.m_131136_(Boolean.valueOf(true)).m_131140_(ChatFormatting.YELLOW)); 
/* 164 */     Objects.requireNonNull(this.mc.f_91062_); stack.m_280430_(this.mc.f_91062_, (Component)mutableComponent, x + 5 + this.widget.m_252754_() - x + this.widget.m_5711_(), y + height / 2 - 9 / 2, -1);
/* 165 */     this.widget.m_253211_(y + height / 2 - this.widget.m_93694_() / 2);
/* 166 */     this.widget.m_88315_(stack, mouseX, mouseY, partialTicks);
/* 167 */     if (this.restartText != null) {
/* 168 */       Objects.requireNonNull(this.mc.f_91062_); stack.m_280430_(this.mc.f_91062_, this.restartText, x + width - this.mc.f_91062_.m_92852_((FormattedText)this.restartText) - 5, y + height / 2 - 9 / 2, -1);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Tooltip getTooltip(ConfigPreset preset) {
/* 174 */     return createConfigTooltip(preset);
/*     */   }
/*     */   
/*     */   protected Tooltip createConfigTooltip(ConfigPreset preset) {
/*     */     T object;
/* 179 */     MutableComponent comment = this.description.m_6881_();
/* 180 */     comment.m_130946_("\n");
/* 181 */     comment.m_7220_((Component)Component.m_237113_(this.path).m_130940_(ChatFormatting.GRAY));
/* 182 */     String defaultName = "Default: ";
/*     */     
/* 184 */     if (preset != null && !preset.isDefault() && preset.hasValue(this.path)) {
/*     */       
/* 186 */       defaultName = "Default (" + preset.name().getString() + "): ";
/* 187 */       object = (T)preset.getValue(this.path);
/*     */     }
/*     */     else {
/*     */       
/* 191 */       object = (T)this.value.getDefault();
/*     */     } 
/* 193 */     comment.m_130946_("\n");
/* 194 */     comment.m_7220_((Component)Component.m_237113_(defaultName + defaultName).m_130940_(ChatFormatting.GREEN));
/* 195 */     if (this.requiresRestart) {
/*     */       
/* 197 */       comment.m_130946_("\n");
/* 198 */       comment.m_7220_((Component)Component.m_237115_("gui.crackerslib.screen.config.requiresRestart").m_130940_(ChatFormatting.YELLOW));
/*     */     } 
/* 200 */     return Tooltip.m_257550_((Component)comment);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ConfigListItem item) {
/* 206 */     if (item instanceof ConfigEntry) { ConfigEntry<?, ?> entry = (ConfigEntry<?, ?>)item;
/* 207 */       return this.path.compareTo(entry.path); }
/*     */     
/* 209 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesSearch(String text) {
/* 215 */     String lowerCase = text.toLowerCase();
/* 216 */     return (this.path.toLowerCase().replace("_", " ").contains(lowerCase) || getName().getString().toLowerCase().contains(lowerCase));
/*     */   }
/*     */   
/*     */   protected abstract W buildWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */   
/*     */   protected abstract T getCurrentValue();
/*     */   
/*     */   protected abstract void setCurrentValue(T paramT);
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\gui\widget\config\entry\ConfigEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */