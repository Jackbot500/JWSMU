/*    */ package nonamecrackers2.crackerslib.client.event.impl;
/*    */ 
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.eventbus.api.Cancelable;
/*    */ import net.minecraftforge.eventbus.api.Event;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import nonamecrackers2.crackerslib.common.config.ConfigHelper;
/*    */ 
/*    */ @Cancelable
/*    */ public class AddConfigEntryToMenuEvent
/*    */   extends Event
/*    */ {
/*    */   private final String modid;
/*    */   private final ModConfig.Type type;
/*    */   private final String path;
/*    */   
/*    */   public AddConfigEntryToMenuEvent(String modid, ModConfig.Type type, String path) {
/* 18 */     this.modid = modid;
/* 19 */     this.type = type;
/* 20 */     this.path = path;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModId() {
/* 25 */     return this.modid;
/*    */   }
/*    */ 
/*    */   
/*    */   public ModConfig.Type getType() {
/* 30 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValuePath() {
/* 35 */     return this.path;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isValue(ForgeConfigSpec.ConfigValue<?> value) {
/* 40 */     return this.path.equals(ConfigHelper.DOT_JOINER.join(value.getPath()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\event\impl\AddConfigEntryToMenuEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */