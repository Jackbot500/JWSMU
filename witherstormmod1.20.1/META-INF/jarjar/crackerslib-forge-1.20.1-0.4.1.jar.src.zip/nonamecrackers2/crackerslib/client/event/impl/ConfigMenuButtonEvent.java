/*    */ package nonamecrackers2.crackerslib.client.event.impl;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.gui.components.AbstractButton;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraftforge.eventbus.api.Event;
/*    */ import net.minecraftforge.fml.event.IModBusEvent;
/*    */ import nonamecrackers2.crackerslib.client.gui.ConfigMenuButtons;
/*    */ 
/*    */ public class ConfigMenuButtonEvent
/*    */   extends Event implements IModBusEvent {
/*    */   private final String modid;
/*    */   @Nullable
/*    */   private ConfigMenuButtons.Factory factory;
/*    */   
/*    */   public ConfigMenuButtonEvent(String modid) {
/* 18 */     this.modid = modid;
/*    */   }
/*    */ 
/*    */   
/*    */   public void registerFactory(ConfigMenuButtons.Factory factory) {
/* 23 */     this.factory = factory;
/*    */   }
/*    */ 
/*    */   
/*    */   public void defaultButtonWithSingleCharacter(char character, int color) {
/* 28 */     this.factory = (onPress -> {
/*    */         Button button = Button.m_253074_((Component)Component.m_237113_(String.valueOf(character)), onPress).m_253136_();
/*    */         button.setFGColor(color);
/*    */         return (AbstractButton)button;
/*    */       });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getModId() {
/* 38 */     return this.modid;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public ConfigMenuButtons.Factory getFactory() {
/* 43 */     return this.factory;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\event\impl\ConfigMenuButtonEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */