/*    */ package nonamecrackers2.crackerslib.client.event.impl;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import java.util.Map;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraftforge.client.ConfigScreenHandler;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import net.minecraftforge.fml.ModContainer;
/*    */ import net.minecraftforge.fml.ModList;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import nonamecrackers2.crackerslib.client.config.ConfigHomeScreenFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Builder
/*    */ {
/* 31 */   private final Map<ModConfig.Type, ForgeConfigSpec> specsByType = Maps.newEnumMap(ModConfig.Type.class);
/*    */   
/*    */   private final String modid;
/*    */   private final ConfigHomeScreenFactory factory;
/*    */   
/*    */   private Builder(String modid, ConfigHomeScreenFactory factory) {
/* 37 */     this.modid = modid;
/* 38 */     this.factory = factory;
/*    */   }
/*    */ 
/*    */   
/*    */   public Builder addSpec(ModConfig.Type type, ForgeConfigSpec spec) {
/* 43 */     if (this.specsByType.containsKey(type))
/* 44 */       throw new IllegalArgumentException("Type is already registered"); 
/* 45 */     this.specsByType.put(type, spec);
/* 46 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void register() {
/* 52 */     ModList.get().getModContainerById(this.modid).ifPresentOrElse(mod -> mod.registerExtensionPoint(ConfigScreenHandler.ConfigScreenFactory.class, ()), () -> {
/*    */           throw new IllegalArgumentException("Unknown mod with id '" + this.modid + "'");
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\event\impl\RegisterConfigScreensEvent$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */