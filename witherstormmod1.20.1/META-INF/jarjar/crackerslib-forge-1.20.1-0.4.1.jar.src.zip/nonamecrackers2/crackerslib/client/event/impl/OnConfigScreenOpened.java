/*    */ package nonamecrackers2.crackerslib.client.event.impl;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraftforge.eventbus.api.Cancelable;
/*    */ import net.minecraftforge.eventbus.api.Event;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ 
/*    */ @Cancelable
/*    */ public class OnConfigScreenOpened
/*    */   extends Event
/*    */ {
/*    */   private final String modid;
/*    */   private final ModConfig.Type type;
/*    */   @Nullable
/*    */   private String initialPath;
/*    */   
/*    */   public OnConfigScreenOpened(String modid, ModConfig.Type type) {
/* 18 */     this.modid = modid;
/* 19 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModId() {
/* 24 */     return this.modid;
/*    */   }
/*    */ 
/*    */   
/*    */   public ModConfig.Type getType() {
/* 29 */     return this.type;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String getInitialPath() {
/* 34 */     return this.initialPath;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setInitialPath(String path) {
/* 39 */     this.initialPath = path;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\event\impl\OnConfigScreenOpened.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */