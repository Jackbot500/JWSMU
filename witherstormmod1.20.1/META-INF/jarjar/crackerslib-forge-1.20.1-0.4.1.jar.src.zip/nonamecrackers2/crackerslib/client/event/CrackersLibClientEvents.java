/*    */ package nonamecrackers2.crackerslib.client.event;
/*    */ import java.util.List;
/*    */ import java.util.function.BiFunction;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.components.AbstractButton;
/*    */ import net.minecraft.client.gui.components.Tooltip;
/*    */ import net.minecraft.client.gui.layouts.FrameLayout;
/*    */ import net.minecraft.client.gui.layouts.GridLayout;
/*    */ import net.minecraft.client.gui.layouts.LayoutElement;
/*    */ import net.minecraft.client.gui.screens.OptionsScreen;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraftforge.client.ConfigScreenHandler;
/*    */ import net.minecraftforge.client.event.ScreenEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.ModContainer;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import nonamecrackers2.crackerslib.client.event.impl.RegisterConfigScreensEvent;
/*    */ import nonamecrackers2.crackerslib.client.gui.ConfigHomeScreen;
/*    */ import nonamecrackers2.crackerslib.client.gui.ConfigMenuButtons;
/*    */ import nonamecrackers2.crackerslib.common.config.CrackersLibConfig;
/*    */ 
/*    */ public class CrackersLibClientEvents {
/*    */   public static void registerConfigScreen(RegisterConfigScreensEvent event) {
/* 25 */     event.builder(ConfigHomeScreen.builder((TitleLogo)TextTitle.ofModDisplayName("crackerslib"))
/* 26 */         .crackersDefault().build())
/* 27 */       .addSpec(ModConfig.Type.CLIENT, CrackersLibConfig.CLIENT_SPEC).register();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void initGui(ScreenEvent.Init.Pre event) {
/* 44 */     Screen screen = event.getScreen(); if (screen instanceof OptionsScreen) { OptionsScreen optionsScreen = (OptionsScreen)screen;
/*    */       
/* 46 */       Minecraft mc = Minecraft.m_91087_();
/* 47 */       GridLayout layout = (new GridLayout()).m_267750_(4);
/* 48 */       GridLayout.RowHelper rowHelper = layout.m_264606_(1);
/* 49 */       ModList.get().forEachModInOrder(mod -> {
/*    */             if (!((List)CrackersLibConfig.CLIENT.hiddenConfigMenuButtons.get()).contains(mod.getModId())) {
/*    */               ConfigScreenHandler.getScreenFactoryFor(mod.getModInfo()).ifPresent(());
/*    */             }
/*    */           });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 68 */       layout.m_264036_();
/* 69 */       FrameLayout.m_264460_((LayoutElement)layout, optionsScreen.f_96543_ / 2 - 180, optionsScreen.f_96544_ / 6 + 42, 20, 200, 0.5F, 0.0F);
/* 70 */       Objects.requireNonNull(event); layout.m_264134_(event::addListener); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\event\CrackersLibClientEvents.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */