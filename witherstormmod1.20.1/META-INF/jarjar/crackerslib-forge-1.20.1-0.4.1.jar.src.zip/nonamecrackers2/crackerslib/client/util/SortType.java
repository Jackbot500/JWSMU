/*    */ package nonamecrackers2.crackerslib.client.util;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import nonamecrackers2.crackerslib.client.gui.widget.config.ConfigListItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SortType
/*    */ {
/* 13 */   A_TO_Z("gui.crackerslib.button.sorting.a-z.tooltip", Comparator.naturalOrder()),
/* 14 */   Z_TO_A("gui.crackerslib.button.sorting.z-a.tooltip", Comparator.reverseOrder());
/*    */   
/*    */   private final Component name;
/*    */   
/*    */   private final Comparator<ConfigListItem> sorter;
/*    */   
/*    */   SortType(String translationKey, Comparator<ConfigListItem> sorter) {
/* 21 */     this.name = (Component)Component.m_237115_(translationKey);
/* 22 */     this.sorter = sorter;
/*    */   }
/*    */ 
/*    */   
/*    */   public Component getName() {
/* 27 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public void sortList(List<ConfigListItem> list) {
/* 32 */     list.sort(this.sorter.thenComparing((first, second) -> 
/* 33 */           (first instanceof nonamecrackers2.crackerslib.client.gui.widget.config.ConfigCategory && second instanceof nonamecrackers2.crackerslib.client.gui.widget.config.entry.ConfigEntry) ? 1 : (
/*    */           
/* 35 */           (first instanceof nonamecrackers2.crackerslib.client.gui.widget.config.entry.ConfigEntry && second instanceof nonamecrackers2.crackerslib.client.gui.widget.config.ConfigCategory) ? -1 : 0)));
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\clien\\util\SortType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */