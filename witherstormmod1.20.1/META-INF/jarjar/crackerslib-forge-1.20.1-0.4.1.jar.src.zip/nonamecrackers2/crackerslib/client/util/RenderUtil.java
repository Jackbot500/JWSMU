/*     */ package nonamecrackers2.crackerslib.client.util;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import com.mojang.blaze3d.vertex.BufferBuilder;
/*     */ import com.mojang.blaze3d.vertex.BufferUploader;
/*     */ import com.mojang.blaze3d.vertex.DefaultVertexFormat;
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.blaze3d.vertex.Tesselator;
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import com.mojang.blaze3d.vertex.VertexFormat;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.navigation.ScreenRectangle;
/*     */ import net.minecraft.client.renderer.GameRenderer;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ import net.minecraft.util.FormattedCharSequence;
/*     */ import net.minecraft.util.Mth;
/*     */ import nonamecrackers2.crackerslib.mixin.MixinGameRendererAccessor;
/*     */ import org.joml.Matrix3f;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Matrix4fc;
/*     */ import org.joml.Vector2f;
/*     */ import org.joml.Vector2fc;
/*     */ import org.joml.Vector3f;
/*     */ import org.joml.Vector4f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderUtil
/*     */ {
/*     */   private static boolean extendFarPlane;
/*     */   private static Matrix4f previousProjMat;
/*     */   
/*     */   public static void setClipPlanes(Matrix4f mat, float near, float far) {
/*  40 */     mat.set(2, 2, -((far + near) / (far - near))).set(3, 2, -(2.0F * far * near / (far - near)));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderCenteredWordWrap(GuiGraphics stack, Font font, FormattedText text, int x, int y, int width, int color) {
/*  45 */     List<FormattedCharSequence> texts = font.m_92923_(text, width);
/*  46 */     Objects.requireNonNull(font); int totalHeight = texts.size() * (9 + 2);
/*  47 */     for (int i = 0; i < texts.size(); i++) {
/*  48 */       Objects.requireNonNull(font); stack.m_280364_(font, texts.get(i), x, y + i * 9 + 2 - totalHeight / 2, color);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void renderHorizontallyCenteredWordWrap(GuiGraphics stack, Font font, FormattedText text, int x, int y, int width, int color) {
/*  53 */     List<FormattedCharSequence> texts = font.m_92923_(text, width);
/*  54 */     for (int i = 0; i < texts.size(); i++) {
/*  55 */       Objects.requireNonNull(font); stack.m_280364_(font, texts.get(i), x, y + i * 9 + 2, color);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void line(GuiGraphics stack, Vector2f start, Vector2f end, int blitOffset, float lineWidth, float r, float g, float b, float a) {
/*  60 */     Vector2f normal = start.sub((Vector2fc)end, new Vector2f()).normalize();
/*  61 */     Matrix4f matrix4f = stack.m_280168_().m_85850_().m_252922_();
/*  62 */     Matrix3f matrix3f = stack.m_280168_().m_85850_().m_252943_();
/*  63 */     BufferBuilder bufferbuilder = Tesselator.m_85913_().m_85915_();
/*  64 */     RenderSystem.enableBlend();
/*  65 */     RenderSystem.setShader(GameRenderer::m_172757_);
/*  66 */     RenderSystem.lineWidth(lineWidth);
/*  67 */     bufferbuilder.m_166779_(VertexFormat.Mode.LINES, DefaultVertexFormat.f_166851_);
/*  68 */     if (normal.y < -0.008F) {
/*     */       
/*  70 */       bufferbuilder.m_252986_(matrix4f, start.x, start.y, blitOffset).m_85950_(r, g, b, a).m_252939_(matrix3f, normal.x, normal.y, 0.0F).m_5752_();
/*  71 */       bufferbuilder.m_252986_(matrix4f, end.x, end.y, blitOffset).m_85950_(r, g, b, a).m_252939_(matrix3f, normal.x, normal.y, 0.0F).m_5752_();
/*     */     }
/*     */     else {
/*     */       
/*  75 */       bufferbuilder.m_252986_(matrix4f, end.x, end.y, blitOffset).m_85950_(r, g, b, a).m_252939_(matrix3f, normal.x, normal.y, 0.0F).m_5752_();
/*  76 */       bufferbuilder.m_252986_(matrix4f, start.x, start.y, blitOffset).m_85950_(r, g, b, a).m_252939_(matrix3f, normal.x, normal.y, 0.0F).m_5752_();
/*     */     } 
/*  78 */     BufferUploader.m_231202_(bufferbuilder.m_231175_());
/*  79 */     RenderSystem.disableBlend();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vector3f getWorldPosFromScreenPos(Matrix4f mat, int screenX, int screenY, float z) {
/*  84 */     Matrix4f inverse = (new Matrix4f((Matrix4fc)mat)).invert();
/*  85 */     Vector4f vec4 = (new Vector4f(screenX, screenY, z, 1.0F)).mul((Matrix4fc)inverse);
/*  86 */     float w = 1.0F / vec4.w;
/*  87 */     return new Vector3f(vec4.x * w, vec4.y * w, vec4.z * w);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vector2f getScreenCoordinatesFromWorldPos(Matrix4f mat, Vector3f pos) {
/*  92 */     Vector4f vector4f = mat.transform(new Vector4f(pos.x, pos.y, pos.z, 1.0F));
/*  93 */     return new Vector2f(vector4f.x, vector4f.y);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vector3f getScreenCoordinatesFromWorldPosWithZDist(Matrix4f mat, Vector3f pos) {
/*  98 */     Vector4f vector4f = mat.transform(new Vector4f(pos.x, pos.y, pos.z, 1.0F));
/*  99 */     return new Vector3f(vector4f.x, vector4f.y, vector4f.z);
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getScreenZCoord(Matrix4f mat, Vector3f pos) {
/* 104 */     return mat.transform(new Vector4f(pos.x, pos.y, pos.z, 1.0F)).z();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderCubeSphere(int subdivision, float radius, PoseStack stack, VertexConsumer consumer, int packedLight, int overlayTexture, boolean useNormals) {
/* 124 */     int pointsPerRow = (int)(Math.pow(2.0D, subdivision) + 1.0D);
/* 125 */     List<Vector3f> unitVertices = generateCubeSpherePosXVertices(pointsPerRow);
/*     */     
/* 127 */     List<Vector3f> vertices = Lists.newArrayList();
/* 128 */     List<Vector3f> normals = Lists.newArrayList();
/* 129 */     List<Vector2f> texCoords = Lists.newArrayList();
/* 130 */     List<Integer> indices = Lists.newArrayList();
/*     */ 
/*     */     
/* 133 */     int k = 0;
/* 134 */     for (int i = 0; i < pointsPerRow; i++) {
/*     */       
/* 136 */       int k1 = i * pointsPerRow;
/* 137 */       int k2 = k1 + pointsPerRow;
/* 138 */       float t = i / (pointsPerRow - 1.0F);
/* 139 */       for (int n = 0; n < pointsPerRow; n++, k1++, k2++) {
/*     */         
/* 141 */         Vector3f vertex = unitVertices.get(k);
/* 142 */         float x = vertex.x;
/* 143 */         float y = vertex.y;
/* 144 */         float z = vertex.z;
/* 145 */         float s = n / (pointsPerRow - 1.0F);
/* 146 */         vertices.add(new Vector3f(x * radius, y * radius, z * radius));
/* 147 */         normals.add(new Vector3f(x, y, z));
/* 148 */         texCoords.add(new Vector2f(1.0F - s / 2.0F, t / 3.0F + 0.33333334F));
/* 149 */         if (i < pointsPerRow - 1 && n < pointsPerRow - 1) {
/*     */           
/* 151 */           indices.add(Integer.valueOf(k1));
/* 152 */           indices.add(Integer.valueOf(k2));
/* 153 */           indices.add(Integer.valueOf(k1 + 1));
/* 154 */           indices.add(Integer.valueOf(k1 + 1));
/* 155 */           indices.add(Integer.valueOf(k2));
/* 156 */           indices.add(Integer.valueOf(k2 + 1));
/*     */         } 
/* 158 */         k++;
/*     */       } 
/*     */     } 
/*     */     
/* 162 */     int vertexSize = pointsPerRow * pointsPerRow;
/* 163 */     int indexSize = 6 * (int)Math.pow(4.0D, subdivision);
/*     */     
/*     */     int j;
/*     */     
/* 167 */     for (j = 0; j < vertexSize; j++) {
/*     */       
/* 169 */       Vector3f vertex = vertices.get(j);
/* 170 */       Vector3f normal = normals.get(j);
/* 171 */       Vector2f texCoord = texCoords.get(j);
/* 172 */       vertices.add(new Vector3f(-vertex.x, vertex.y, -vertex.z));
/* 173 */       normals.add(new Vector3f(-normal.x, normal.y, -normal.z));
/* 174 */       texCoords.add(new Vector2f(texCoord.x + 0.5F, texCoord.y));
/*     */     } 
/* 176 */     int startIndex = vertexSize;
/* 177 */     for (j = 0; j < indexSize; j++) {
/* 178 */       indices.add(Integer.valueOf(startIndex + ((Integer)indices.get(j)).intValue()));
/*     */     }
/*     */     
/* 181 */     for (j = 0; j < vertexSize; j++) {
/*     */       
/* 183 */       Vector3f vertex = vertices.get(j);
/* 184 */       Vector3f normal = normals.get(j);
/* 185 */       Vector2f texCoord = texCoords.get(j);
/* 186 */       vertices.add(new Vector3f(-vertex.z, vertex.x, -vertex.y));
/* 187 */       normals.add(new Vector3f(-normal.z, normal.x, -normal.y));
/* 188 */       texCoords.add(new Vector2f(texCoord.x - 0.5F, texCoord.y - 0.33333334F));
/*     */     } 
/* 190 */     startIndex = vertexSize * 2;
/* 191 */     for (j = 0; j < indexSize; j++) {
/* 192 */       indices.add(Integer.valueOf(startIndex + ((Integer)indices.get(j)).intValue()));
/*     */     }
/*     */     
/* 195 */     for (j = 0; j < vertexSize; j++) {
/*     */       
/* 197 */       Vector3f vertex = vertices.get(j);
/* 198 */       Vector3f normal = normals.get(j);
/* 199 */       Vector2f texCoord = texCoords.get(j);
/* 200 */       vertices.add(new Vector3f(-vertex.z, -vertex.x, vertex.y));
/* 201 */       normals.add(new Vector3f(-normal.z, -normal.x, normal.y));
/* 202 */       texCoords.add(new Vector2f(texCoord.x, texCoord.y - 0.33333334F));
/*     */     } 
/* 204 */     startIndex = vertexSize * 3;
/* 205 */     for (j = 0; j < indexSize; j++) {
/* 206 */       indices.add(Integer.valueOf(startIndex + ((Integer)indices.get(j)).intValue()));
/*     */     }
/*     */     
/* 209 */     for (j = 0; j < vertexSize; j++) {
/*     */       
/* 211 */       Vector3f vertex = vertices.get(j);
/* 212 */       Vector3f normal = normals.get(j);
/* 213 */       Vector2f texCoord = texCoords.get(j);
/* 214 */       vertices.add(new Vector3f(-vertex.z, vertex.y, vertex.x));
/* 215 */       normals.add(new Vector3f(-normal.z, normal.y, normal.x));
/* 216 */       texCoords.add(new Vector2f(texCoord.x, texCoord.y + 0.33333334F));
/*     */     } 
/* 218 */     startIndex = vertexSize * 4;
/* 219 */     for (j = 0; j < indexSize; j++) {
/* 220 */       indices.add(Integer.valueOf(startIndex + ((Integer)indices.get(j)).intValue()));
/*     */     }
/*     */     
/* 223 */     for (j = 0; j < vertexSize; j++) {
/*     */       
/* 225 */       Vector3f vertex = vertices.get(j);
/* 226 */       Vector3f normal = normals.get(j);
/* 227 */       Vector2f texCoord = texCoords.get(j);
/* 228 */       vertices.add(new Vector3f(vertex.z, vertex.y, -vertex.x));
/* 229 */       normals.add(new Vector3f(normal.z, normal.y, -normal.x));
/* 230 */       texCoords.add(new Vector2f(texCoord.x + 0.5F, texCoord.y + 0.33333334F));
/*     */     } 
/* 232 */     startIndex = vertexSize * 5;
/* 233 */     for (j = 0; j < indexSize; j++) {
/* 234 */       indices.add(Integer.valueOf(startIndex + ((Integer)indices.get(j)).intValue()));
/*     */     }
/* 236 */     Matrix4f matrix4f = stack.m_85850_().m_252922_();
/* 237 */     Matrix3f matrix3f = stack.m_85850_().m_252943_();
/* 238 */     for (int m = 0; m < indices.size(); m++) {
/*     */       
/* 240 */       int index = ((Integer)indices.get(m)).intValue();
/* 241 */       Vector3f vertex = vertices.get(index);
/* 242 */       Vector3f normal = normals.get(index);
/* 243 */       Vector2f uv = texCoords.get(index);
/* 244 */       consumer.m_252986_(matrix4f, vertex.x, vertex.y, vertex.z).m_85950_(1.0F, 1.0F, 1.0F, 1.0F).m_7421_(uv.x, uv.y).m_86008_(overlayTexture).m_85969_(packedLight);
/* 245 */       if (useNormals) {
/* 246 */         consumer.m_252939_(matrix3f, normal.x, normal.y, normal.z).m_5752_();
/*     */       } else {
/* 248 */         consumer.m_5601_(0.0F, -1.0F, 0.0F).m_5752_();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static List<Vector3f> generateCubeSpherePosXVertices(int pointsPerRow) {
/* 254 */     float D2R = (float)Math.acos(-1.0D) / 180.0F;
/* 255 */     List<Vector3f> vertices = Lists.newArrayList();
/*     */     
/* 257 */     for (int i = 0; i < pointsPerRow; i++) {
/*     */       
/* 259 */       float a2 = D2R * (45.0F - 90.0F * i / (pointsPerRow - 1.0F));
/* 260 */       Vector3f n2 = new Vector3f((float)-Math.sin(a2), (float)Math.cos(a2), 0.0F);
/* 261 */       for (int j = 0; j < pointsPerRow; j++) {
/*     */         
/* 263 */         float a1 = D2R * (-45.0F + 90.0F * j / (pointsPerRow - 1.0F));
/* 264 */         Vector3f n1 = new Vector3f((float)-Math.sin(a1), 0.0F, (float)-Math.cos(a1));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 269 */         Vector3f v = (new Vector3f(n1.y * n2.z - n1.z * n2.y, n1.z * n2.x - n1.x * n2.z, n1.x * n2.y - n1.y * n2.x)).normalize();
/* 270 */         vertices.add(v);
/*     */       } 
/*     */     } 
/*     */     
/* 274 */     return vertices;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderSectorStackSphere(float radius, int sectorCount, int stackCount, PoseStack stack, VertexConsumer consumer, int packedLight, int overlayTexture) {
/* 294 */     List<Vector3f> vertices = Lists.newArrayList();
/* 295 */     List<Vector3f> normals = Lists.newArrayList();
/* 296 */     List<Vector2f> texCoords = Lists.newArrayList();
/*     */     
/* 298 */     List<Integer> indices = Lists.newArrayList();
/*     */     
/* 300 */     float lengthInv = 1.0F / radius;
/*     */     
/* 302 */     float sectorStep = 6.2831855F / sectorCount;
/* 303 */     float stackStep = 3.1415927F / stackCount;
/*     */     int i;
/* 305 */     for (i = 0; i <= stackCount; i++) {
/*     */       
/* 307 */       float stackAngle = 1.5707964F - i * stackStep;
/* 308 */       float xy = radius * Mth.m_14089_(stackAngle);
/* 309 */       float z = radius * Mth.m_14031_(stackAngle);
/*     */       
/* 311 */       for (int k = 0; k <= sectorCount; k++) {
/*     */         
/* 313 */         float sectorAngle = k * sectorStep;
/*     */         
/* 315 */         float x = xy * Mth.m_14089_(sectorAngle);
/* 316 */         float y = xy * Mth.m_14031_(sectorAngle);
/* 317 */         vertices.add(new Vector3f(x, y, z));
/*     */         
/* 319 */         float nx = x * lengthInv;
/* 320 */         float ny = y * lengthInv;
/* 321 */         float nz = z * lengthInv;
/* 322 */         normals.add(new Vector3f(nx, ny, nz));
/*     */         
/* 324 */         float u = k / sectorCount;
/* 325 */         float v = i / stackCount;
/* 326 */         texCoords.add(new Vector2f(u, v));
/*     */       } 
/*     */     } 
/*     */     
/* 330 */     for (i = 0; i < stackCount; i++) {
/*     */       
/* 332 */       int k1 = i * (sectorCount + 1);
/* 333 */       int k2 = k1 + sectorCount + 1;
/*     */       
/* 335 */       for (int k = 0; k < sectorCount; k++, k1++, k2++) {
/*     */         
/* 337 */         if (i != 0) {
/*     */           
/* 339 */           indices.add(Integer.valueOf(k1));
/* 340 */           indices.add(Integer.valueOf(k2));
/* 341 */           indices.add(Integer.valueOf(k1 + 1));
/*     */         } 
/*     */         
/* 344 */         if (i != stackCount - 1) {
/*     */           
/* 346 */           indices.add(Integer.valueOf(k1 + 1));
/* 347 */           indices.add(Integer.valueOf(k2));
/* 348 */           indices.add(Integer.valueOf(k2 + 1));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 353 */     Matrix4f matrix4f = stack.m_85850_().m_252922_();
/* 354 */     Matrix3f matrix3f = stack.m_85850_().m_252943_();
/* 355 */     for (int j = 0; j < indices.size(); j++) {
/*     */       
/* 357 */       int index = ((Integer)indices.get(j)).intValue();
/* 358 */       Vector3f vertex = vertices.get(index);
/* 359 */       Vector3f normal = normals.get(index);
/* 360 */       Vector2f uv = texCoords.get(index);
/* 361 */       consumer.m_252986_(matrix4f, vertex.x, vertex.y, vertex.z).m_85950_(1.0F, 1.0F, 1.0F, 1.0F).m_7421_(uv.x, uv.y).m_86008_(overlayTexture).m_85969_(packedLight).m_252939_(matrix3f, normal.x, normal.y, normal.z).m_5752_();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isMouseInBounds(int mouseX, int mouseY, int x, int y, int width, int height) {
/* 367 */     return (mouseX > x && mouseY > y && mouseX < x + width && mouseY < y + height);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isMouseInBounds(int mouseX, int mouseY, ScreenRectangle rectangle) {
/* 372 */     return isMouseInBounds(mouseX, mouseY, rectangle.f_263846_().f_263719_(), rectangle.f_263846_().f_263694_(), rectangle.f_263770_(), rectangle.f_263800_());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void adjustProjectionMatrix(float partialTicks, float near, float far) {
/* 377 */     extendFarPlane = true;
/* 378 */     previousProjMat = RenderSystem.getProjectionMatrix();
/* 379 */     Minecraft mc = Minecraft.m_91087_();
/* 380 */     GameRenderer renderer = mc.f_91063_;
/* 381 */     MixinGameRendererAccessor accessor = (MixinGameRendererAccessor)renderer;
/* 382 */     double fov = accessor.crackerslib$getFov(renderer.m_109153_(), partialTicks, true);
/* 383 */     PoseStack stack = new PoseStack();
/* 384 */     stack.m_85850_().m_252922_().identity();
/* 385 */     float zoom = accessor.crackerslib$getZoom();
/* 386 */     if (zoom != 1.0F) {
/*     */       
/* 388 */       stack.m_252880_(accessor.crackerslib$getZoomX(), -accessor.crackerslib$getZoomY(), 0.0F);
/* 389 */       stack.m_85841_(zoom, zoom, 1.0F);
/*     */     } 
/* 391 */     stack.m_85850_().m_252922_().mul((Matrix4fc)(new Matrix4f()).setPerspective((float)(fov * 0.01745329238474369D), mc.m_91268_().m_85441_() / mc.m_91268_().m_85442_(), near, far));
/* 392 */     renderer.m_252879_(stack.m_85850_().m_252922_());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void popAdjustedProjectionMatrix() {
/* 397 */     if (previousProjMat == null)
/* 398 */       throw new NullPointerException("Previous projection matrix is null!"); 
/* 399 */     if (!extendFarPlane)
/* 400 */       throw new IllegalStateException("Not extending far plane!"); 
/* 401 */     extendFarPlane = false;
/* 402 */     (Minecraft.m_91087_()).f_91063_.m_252879_(previousProjMat);
/* 403 */     previousProjMat = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\clien\\util\RenderUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */