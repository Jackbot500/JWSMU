/*    */ package nonamecrackers2.crackerslib.client.util;
/*    */ 
/*    */ import net.minecraft.Util;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.screens.ConfirmLinkScreen;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ 
/*    */ 
/*    */ public class GUIUtils
/*    */ {
/*    */   public static void openLink(String link) {
/* 12 */     Minecraft mc = Minecraft.m_91087_();
/* 13 */     Screen current = mc.f_91080_;
/* 14 */     mc.m_91152_((Screen)new ConfirmLinkScreen(b -> { if (b) Util.m_137581_().m_137646_(link);  mc.m_91152_(current); }link, true));
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\clien\\util\GUIUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */