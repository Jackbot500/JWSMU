package nonamecrackers2.crackerslib.client.config;

import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.client.gui.screens.Screen;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.config.ModConfig;
import nonamecrackers2.crackerslib.client.gui.ConfigHomeScreen;

@FunctionalInterface
public interface ConfigHomeScreenFactory {
  ConfigHomeScreen build(String paramString, Map<ModConfig.Type, ForgeConfigSpec> paramMap, boolean paramBoolean1, boolean paramBoolean2, @Nullable Screen paramScreen);
}


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\client\config\ConfigHomeScreenFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */