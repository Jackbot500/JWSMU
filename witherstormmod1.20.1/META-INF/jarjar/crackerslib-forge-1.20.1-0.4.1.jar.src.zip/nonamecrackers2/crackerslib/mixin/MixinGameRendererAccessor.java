package nonamecrackers2.crackerslib.mixin;

import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({GameRenderer.class})
public interface MixinGameRendererAccessor {
  @Invoker("getFov")
  double crackerslib$getFov(Camera paramCamera, float paramFloat, boolean paramBoolean);
  
  @Accessor("zoom")
  float crackerslib$getZoom();
  
  @Accessor("zoomX")
  float crackerslib$getZoomX();
  
  @Accessor("zoomY")
  float crackerslib$getZoomY();
}


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\mixin\MixinGameRendererAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */