/*    */ package nonamecrackers2.crackerslib.example.common.event;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraftforge.event.RegisterCommandsEvent;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import nonamecrackers2.crackerslib.common.command.ConfigCommandBuilder;
/*    */ import nonamecrackers2.crackerslib.common.config.preset.ConfigPreset;
/*    */ import nonamecrackers2.crackerslib.common.config.preset.RegisterConfigPresetsEvent;
/*    */ import nonamecrackers2.crackerslib.example.client.event.common.config.ExampleConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExampleEvents
/*    */ {
/*    */   public static void registerPresetsEvent(RegisterConfigPresetsEvent event) {
/* 17 */     event.exclude(ExampleConfig.CLIENT.exampleListInteger);
/* 18 */     event.registerPreset(ModConfig.Type.SERVER, ConfigPreset.builder((Component)Component.m_237113_("Another Example"))
/* 19 */         .setDescription((Component)Component.m_237113_("Just another epic example preset"))
/* 20 */         .setPreset(ExampleConfig.CLIENT.exampleEnum, ExampleConfig.ExampleEnum.GOING)
/* 21 */         .build());
/*    */     
/* 23 */     event.registerPreset(ModConfig.Type.SERVER, ConfigPreset.builder((Component)Component.m_237113_("Example"))
/* 24 */         .setDescription((Component)Component.m_237113_("Just an example preset"))
/* 25 */         .setPreset(ExampleConfig.CLIENT.exampleBoolean, Boolean.valueOf(false))
/* 26 */         .setPreset(ExampleConfig.CLIENT.exampleDouble, Double.valueOf(0.5D))
/* 27 */         .setPreset(ExampleConfig.CLIENT.exampleInteger, Integer.valueOf(90))
/* 28 */         .setPreset(ExampleConfig.CLIENT.exampleString, "Test preset FTW!")
/* 29 */         .setPreset(ExampleConfig.CLIENT.exampleListDouble, Lists.newArrayList((Object[])new Double[] { Double.valueOf(100.0D), Double.valueOf(110.0D), Double.valueOf(120.0D)
/* 30 */             })).build());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void registerCommands(RegisterCommandsEvent event) {
/* 36 */     ConfigCommandBuilder.builder(event.getDispatcher(), "crackerslib").addSpec(ModConfig.Type.SERVER, ExampleConfig.CLIENT_SPEC).register();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\example\common\event\ExampleEvents.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */