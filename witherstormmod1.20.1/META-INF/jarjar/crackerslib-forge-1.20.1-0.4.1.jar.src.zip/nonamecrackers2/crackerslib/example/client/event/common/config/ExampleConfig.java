/*    */ package nonamecrackers2.crackerslib.example.client.event.common.config;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.List;
/*    */ import java.util.function.Function;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import nonamecrackers2.crackerslib.common.config.ConfigHelper;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.apache.commons.lang3.tuple.Pair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExampleConfig
/*    */ {
/*    */   public static final ClientConfig CLIENT;
/*    */   public static final ForgeConfigSpec CLIENT_SPEC;
/*    */   
/*    */   static {
/* 20 */     Pair<ClientConfig, ForgeConfigSpec> clientPair = (new ForgeConfigSpec.Builder()).configure(ClientConfig::new);
/* 21 */     CLIENT = (ClientConfig)clientPair.getLeft();
/* 22 */     CLIENT_SPEC = (ForgeConfigSpec)clientPair.getRight();
/*    */   }
/*    */   
/*    */   public static class ClientConfig
/*    */     extends ConfigHelper
/*    */   {
/*    */     public final ForgeConfigSpec.ConfigValue<Boolean> exampleBoolean;
/*    */     public final ForgeConfigSpec.ConfigValue<Integer> exampleInteger;
/*    */     public final ForgeConfigSpec.ConfigValue<Double> exampleDouble;
/*    */     public final ForgeConfigSpec.ConfigValue<String> exampleString;
/*    */     public final ForgeConfigSpec.ConfigValue<ExampleConfig.ExampleEnum> exampleEnum;
/*    */     public final ForgeConfigSpec.ConfigValue<List<? extends String>> exampleListString;
/*    */     public final ForgeConfigSpec.ConfigValue<List<? extends Integer>> exampleListInteger;
/*    */     public final ForgeConfigSpec.ConfigValue<List<? extends Double>> exampleListDouble;
/*    */     
/*    */     public ClientConfig(ForgeConfigSpec.Builder builder) {
/* 38 */       super(builder, "crackerslib");
/*    */       
/* 40 */       this.exampleBoolean = createValue(Boolean.valueOf(true), "exampleBoolean", false, "A simple boolean config value");
/*    */       
/* 42 */       builder.comment("Numbers").push("numbers");
/*    */       
/* 44 */       this.exampleInteger = createRangedIntValue(10, 0, 100, "exampleInteger", true, "A simple ranged integer value");
/*    */       
/* 46 */       this.exampleDouble = createRangedDoubleValue(0.5D, 0.0D, 1.0D, "exampleDouble", true, "A simple ranged value with decimals");
/*    */       
/* 48 */       builder.pop();
/*    */       
/* 50 */       builder.comment("Extra").push("extra");
/*    */       
/* 52 */       this.exampleString = createValue("hello!", "exampleString", false, "A simple string value");
/*    */       
/* 54 */       builder.pop();
/*    */       
/* 56 */       this.exampleEnum = createEnumValue(ExampleConfig.ExampleEnum.HEY, "exampleEnum", false, "A simple enum config value");
/*    */       
/* 58 */       builder.comment("Lists").push("list");
/*    */       
/* 60 */       this.exampleListString = createListValue(String.class, () -> Lists.newArrayList((Object[])new String[] { "heres", "some", "default", "values" }, ), val -> StringUtils.isAllLowerCase(val), "exampleListString", false, "An example list of strings that must all be lowercase");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 66 */       this.exampleListInteger = createListValue(Integer.class, () -> Lists.newArrayList((Object[])new Integer[] { Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5) }, ), val -> (val.intValue() >= 2), "exampleListInteger", false, "An example list of integers that must be greater than or equal to 2");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 72 */       builder.comment("Category Example").push("category_example");
/*    */       
/* 74 */       this.exampleListDouble = createListValue(Double.class, () -> Lists.newArrayList((Object[])new Double[] { Double.valueOf(0.0D), Double.valueOf(1.0D), Double.valueOf(2.0D), Double.valueOf(3.0D) }, ), val -> true, "exampleListDouble", false, "An example list of doubles");
/*    */ 
/*    */ 
/*    */       
/* 78 */       builder.pop();
/*    */       
/* 80 */       builder.pop();
/*    */     }
/*    */   }
/*    */   
/*    */   public enum ExampleEnum
/*    */   {
/* 86 */     HEY,
/* 87 */     HOWS,
/* 88 */     IT,
/* 89 */     GOING;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\example\client\event\common\config\ExampleConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */