/*    */ package nonamecrackers2.crackerslib.example.client.event;
/*    */ 
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import nonamecrackers2.crackerslib.client.event.impl.AddConfigEntryToMenuEvent;
/*    */ import nonamecrackers2.crackerslib.client.event.impl.ConfigMenuButtonEvent;
/*    */ import nonamecrackers2.crackerslib.client.event.impl.OnConfigScreenOpened;
/*    */ import nonamecrackers2.crackerslib.client.event.impl.RegisterConfigScreensEvent;
/*    */ import nonamecrackers2.crackerslib.client.gui.ConfigHomeScreen;
/*    */ import nonamecrackers2.crackerslib.client.gui.title.TextTitle;
/*    */ import nonamecrackers2.crackerslib.client.gui.title.TitleLogo;
/*    */ import nonamecrackers2.crackerslib.example.client.event.common.config.ExampleConfig;
/*    */ 
/*    */ 
/*    */ public class ExampleClientEvents
/*    */ {
/*    */   public static void registerConfigScreen(RegisterConfigScreensEvent event) {
/* 18 */     event.builder(ConfigHomeScreen.builder((TitleLogo)TextTitle.ofModDisplayName("crackerslib"))
/* 19 */         .crackersDefault("https://github.com/nonamecrackers2/crackerslib/issues").build())
/* 20 */       .addSpec(ModConfig.Type.CLIENT, ExampleConfig.CLIENT_SPEC).register();
/*    */   }
/*    */ 
/*    */   
/*    */   public static void registerConfigMenuButton(ConfigMenuButtonEvent event) {
/* 25 */     event.defaultButtonWithSingleCharacter('C', -666558);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void onConfigScreenOpened(OnConfigScreenOpened event) {
/* 31 */     if (event.getModId().equals("crackerslib") && event.getType() == ModConfig.Type.CLIENT) {
/* 32 */       event.setInitialPath("list.category_example");
/*    */     }
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void onConfigEntryAddedToMenu(AddConfigEntryToMenuEvent event) {
/* 38 */     if (event.getModId().equals("crackerslib") && event.getType() == ModConfig.Type.CLIENT)
/*    */     {
/* 40 */       if (event.isValue(ExampleConfig.CLIENT.exampleString)) {
/* 41 */         event.setCanceled(true);
/* 42 */       } else if (event.isValue(ExampleConfig.CLIENT.exampleDouble)) {
/* 43 */         event.setCanceled(true);
/* 44 */       } else if (event.isValue(ExampleConfig.CLIENT.exampleEnum)) {
/* 45 */         event.setCanceled(true);
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jackbot\Desktop\Jacks Crackers Wither Storm Update\witherstormmod-1.20.1-4.2.1-all.jar!\META-INF\jarjar\crackerslib-forge-1.20.1-0.4.1.jar!\nonamecrackers2\crackerslib\example\client\event\ExampleClientEvents.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */